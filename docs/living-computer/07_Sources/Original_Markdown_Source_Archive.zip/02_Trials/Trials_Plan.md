# CE-TRIAL-001: staged experimental plan

## Objective and trial unit

Determine whether a qualified human-derived neuronal–astrocytic core acquires retained context-dependent capability; whether a separate observer learns useful monitoring; and whether joining trained child modules improves the core without unacceptable loss. Test the affect-inspired arbitration policy first in software, then as a host-side control comparison. A later biological mechanism study is a separate claim.

The biological unit is an independently prepared culture. An experimental dyad contains two independent cultures. A triad contains three. Trials, electrodes, sorted units, imaging regions and repeated days are nested observations. Source line, preparation batch, operator, platform configuration and day are recorded. Shared medium preparation or source pools are blocking factors, not hidden independent replication.

The `trials.json` file is the machine-readable trial register. No row is marked run or passed. Enrollment counts are planning proposals or null; confirmation sizes require pilot variance and the selected estimand. Every trial has prerequisites, arms, outcomes, exclusions, stopping rules and a decision.

## Sequential program

| Stage | Primary question | Required comparison | Unit and decision |
|---|---|---|---|
| T00 | Are data, targets and commands separated? | Correct routes, leakage attempts, stale events, replay | Software episodes; pass invariant checks |
| T01 | Does the permit circuit suppress output on faults? | Normal arm, host loss, watchdog, open loop, reset | Bench assemblies and repeated faults; measured electrical release |
| T02 | Is the chosen culture/interface usable? | Reference preparations and blank chip/material observations | Proposed 6 independent preparations over at least 2 batches; feasibility only |
| T03 | Does contingent feedback improve the core? | Contingent, yoked/exposure-matched, no-teaching | Proposed pilot 6 preparations/arm; estimate effect and variation |
| T04 | Does capability persist after rest? | Immediate and delayed cue-only evaluation; probe-history control | Separate or balanced cohorts at 45 min, 24 h, 7 d |
| T05 | Does spaced experience improve retention? | Spaced vs massed at equal approved exposure and information | Independent preparations; delayed outcome |
| T06 | Does O learn state discrimination? | Trained O, untrained O, feature-matched digital monitor | Independent O and source episodes |
| T07 | Can O predict before the core fails? | Pre-cutoff O vs digital predictor and shuffled labels | Held-out episodes and later preparations |
| T08 | Does joining O help C? | C alone, trained O, untrained O, replayed O, digital O as feasible | Independent dyads; protected-core retention |
| T09 | Does S improve support selection? | Learned S vs fixed coordinator and action-matched schedule | Independent triads; marginal contribution |
| T10 | Do affect-inspired weights help? | No weighting, reliability-only, full policy, shuffled history | Software first; then matched biological-module deployments |
| T11 | Does B retain independently taught capability? | B self-training, trained A, untrained A, replay, software teacher | Independent A/B dyads; B-only delayed tests |
| T12 | Do astrocyte features add information? | Neuronal+environment model vs model adding astrocytic features | Held-out preparations; predictive increment |
| T13 | Is a selected astrocyte mechanism causal? | Targeted qualified comparison plus general-state and unrelated-task controls | New experiment after T12/behavioral evidence |
| T14 | Does diversity or renewal add value? | One added subtype/module vs unchanged and retrained controls | New independent preparations; contribution and cost |
| T15 | Does a physical bridge add value? | Physical vs electronic and matched unjoined arrangements | Separate build version; communication and independence |
| T16 | Do chain depth and redundancy help? | Depth 1/2/3, missing-link and duplicate-input cases | Software first; biological chain only after dyads work |
| T17 | Can another batch/site reproduce the candidate? | Frozen candidate and prespecified controls | Independent confirmation, ideally another operator/site |

Do not run all arms at once. T03/T04 form the first biological campaign. T05 is justified if acquisition is credible but retention is inadequate. T06 may use recorded or simulated source histories before C is mature enough for joint trials. T13–T16 are later research, not prerequisites for beginning the company.

## Core curriculum

The starting task uses contexts C0 and C1 and token sequences AB, BA, AA and BB. C0: AB→X and BA→Y. C1 reverses these responses. Repeated symbols require HOLD in either context. Missing context or an unknown token is UNRESOLVED at the interface; invalid recordings are INVALID, not a correct HOLD. This produces eight valid context/sequence combinations.

Start with cue separability and sequence discrimination, then add context reversal, repeated-symbol controls, delayed retrieval and protected old relations. Human-defined meaning comes from the declared task and its counterexamples; words alone do not give cultured neurons human semantics. Later curricula may introduce multi-step conditional choices only after simpler retained capability is established.

One development block proposes 64 balanced valid opportunities. Up to four blocks before a development probe is a bookkeeping default, subject to the preparation's lower qualified exposure/session limit. The package contains no live stimulation amplitudes or timings. Each task event refers to an approved profile ID whose actual delivered waveform is recorded. Blank profile entries block operation.

Feedback follows response closure, uses approved distinguishable conditions and remains within the same exposure envelope. A yoked control matches exposure without using its own outcome to select feedback. Randomize or counterbalance replay alignment: replay can accidentally correlate with a structured task. Verify actual feedback/outcome contingency rather than asserting mutual information equals zero by construction. No condition withholds basic support.

## Train, check and improve

1. Check G1–G3, support state, sensor freshness, configuration hash, storage, bridge state and allowed profiles. Record baseline.
2. Train using only the training oracle. Record requested and delivered events and all invalid opportunities.
3. Freeze encoder mappings, preprocessing and readout; disable teaching feedback for the development probe.
4. Enter the assigned quiet or replay condition, then perform the scheduled delayed probe. Rest is not assumed to be sleep.
5. Test protected old relations and classify failure: invalid interface, insufficient acquisition, loss after delay, context interference, state change or unresolved cause.
6. Revise one principal factor or a preregistered factorial combination. Preserve the predecessor and its failures. Cap a campaign at three candidate revisions before a task/interface review.
7. Freeze the selected candidate and evaluate once on sealed confirmation data and fresh preparations. A failed confirmation cannot be converted to success by tuning on its outcomes.

Probes are experience. Compare repeated-probe schedules with a single delayed-probe cohort where retention is the claim. Delay measurements begin from a defined last teaching event and account for recovery from stimulation artifacts and service. A better score after service does not identify a restored memory mechanism.

## Observer and support curricula

O1 receives encoded telemetry and distinguishes nominal state, route-review need, support-review need and unknown/missing observations. Begin with simulated or recorded operational faults, not tissue damage. Include quiet-but-valid cultures, missing recordings, slow-but-correct responses, novel contexts and benign large activity events.

O2 predicts an outcome at a declared cutoff before the core's scored response. Exclude the correct target, future response, retrospective normalization and post-response error flag. Hold out complete episodes and later days. A classifier given both a target and completed answer is an external checker, not an early-warning predictor.

S receives permitted histories and proposes NO_CHANGE, REQUEST_REVIEW, DEFER_TASK or TRY_APPROVED_ROUTE. Rest scheduling can be added after timing is qualified. The coordinator decides whether to implement a proposal. Learning credit uses an independently measured effect on C and protected capabilities, with randomized permissible actions or action-matched controls. S does not change medium or generate new cells directly.

## Outcomes and acceptance

The proposed primary core outcome is macro-averaged recall over X/Y/HOLD at 24 hours. Report 45-minute retention separately because transient improvement may disappear early. Report all contexts, raw accuracy, invalid/late/missing opportunities and absolute scores. Initial project targets remain 0.80 acquisition, 0.75 at 24 hours and 0.70 at seven days, with a proposed learning contrast of at least 0.10 versus the strongest relevant biological control. These are project targets, not measured expectations.

Protected capability has a proposed noninferiority margin of 0.05. For change = new − old performance, the prespecified lower confidence bound must exceed −0.05. A nonsignificant difference is not preservation. Joined benefit proposes 0.05 improvement or a preregistered resource benefit at noninferior performance. Choose one primary objective before data collection.

O1 targets 0.80 macro recall with false alerts on at most 5% of nominal episodes; also report false alerts/hour, alert duration and UNKNOWN use. O2 requires positive useful lead time and precision/recall beyond a feature-matched digital model at a frozen threshold. Evaluate calibration using held-out probabilities; a spike-count softmax is not automatically calibrated confidence.

The Understanding report is a vector: acquisition, retention at each delay, generalization, interference, calibration, latency, availability and cost. Do not collapse it into a single metaphysical quantity. A biological learning result may be worthwhile even if a truth-table program solves the toy task more efficiently.

## Allocation, analysis and missingness

Randomize preparation assignment within batch after eligibility is determined without looking at outcome. Balance positions and operators where feasible. Keep analyst-facing arm codes concealed until the primary analysis is frozen. The preparation, not the trial, determines the biological sample count. Use a hierarchical model or preparation-level summaries with uncertainty appropriate to the design.

Pilot counts above estimate feasibility and variance. An illustrative two-arm normal approximation with SD 0.08 and a target difference 0.10, two-sided alpha .05 and power .80 gives about 11 analyzable preparations per arm, or 14 enrolled allowing 20% attrition. This is not the final size for multiple arms, bounded outcomes, batch effects, noninferiority or dyads. Recalculate prospectively from the pilot and freeze the result before confirmation.

Retain every enrolled preparation. Separate receiving failure, pretraining exclusion, technical invalidity and post-training biological attrition. Report both scheduled-opportunity availability and valid-trial performance; do not improve the score by removing failed service periods. Dropout associated with training is an outcome, not just missing data. Provide conservative sensitivity analyses and the reason for every exclusion.

A retention ratio `(P_delay − P_reference)/(P_immediate − P_reference)` is secondary. It is undefined or unstable near a zero denominator, can exceed one or be negative, and needs interval uncertainty. Predefine the reference performance for the chosen metric. For class-balanced macro recall the chance baseline differs from the raw prevalence baseline. Absolute delayed scores and between-arm contrasts remain primary.

Use one frozen primary contrast per campaign; identify secondary and exploratory analyses. Preserve raw timestamps, delivered profiles, channel map, calibration, artifact masks, preparation history and preprocessing versions. Confirmation data are never used to choose a region, threshold or astrocyte ensemble before testing that same hypothesis on them.

## Stopping and promotion

Pause task stimulation for invalid support, stale required sensors, invalid command/profile, lost time synchronization, exceeded exposure, unanticipated biological deterioration or failed suppression. Continue qualified culture care. Resume only with documented restoration and requalification appropriate to the fault. Scientific futility, candidate-budget exhaustion and lack of retention are separate stop reasons.

Promote only the measured capability: O1 does not imply O2; 24-hour retention does not imply seven-day persistence; assisted performance does not imply B-only learning; astrocytic prediction does not imply causal storage. T17 closes the selected claim within its declared preparation and task scope. It does not establish a perfect or unrestricted human-understanding system.
