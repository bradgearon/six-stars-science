# Curriculum and Knowledge-space expansion

The first core is intended to build human-defined relational capability in human-derived cells. Its task record can grow into a set of retained relations, while each child develops its own learned scope. This curriculum specifies what progress would mean without claiming that a dish has acquired ordinary human language, a person's autobiographical memory or general human understanding.

| Level | Training content | Required counterexample | Promotion evidence |
|---|---|---|---|
| K0 Interface | Distinguishable cue families and response classes | Sham, invalid and indistinguishable inputs | G3; usable fixed input/output map |
| K1 Sequence | AB versus BA, repeated symbols | Same counts with different order | Held-out sequence discrimination |
| K2 Context | C0/C1 changes the sequence-response relation | Context-blind and final-symbol baselines | Retained reversal with fixed decoder |
| K3 Delayed relation | Cue a learned relation after quiet intervals | Untrained relation and probe-history control | Scoped retention at declared delays |
| K4 Conditional composition | Two previously learned relations select a response | Familiar cues with an invalid combination | New combinations; old skills remain |
| K5 Uncertainty | Unknown context, missing evidence and ambiguous input | Quiet-but-valid and slow-but-correct episodes | Calibrated abstention without trivial silence |
| K6 Observer exchange | Child report changes a permitted core decision | Replayed, shuffled and stale reports | Benefit of relevant fresh information |
| K7 Independent expertise | Different children learn different relation families | Identical-source children with different histories | Independent child skill and useful arbitration |
| K8 Transfer | New cue arrangement or context within the released interface | Superficial similarity without the learned relation | Prespecified generalization beyond shortcuts |
| K9 Continual expansion | New relation or admitted child | Retraining and unchanged-system controls | New contribution with old-task noninferiority |

K4 onward are candidate curricula. The availability of software truth tables does not establish that the preparation can learn them. At every level, define the observation, target, meaning assigned by the human designer, counterexamples, readout and acceptance criterion before training.

## A relation record

A Knowledge relation record contains a stable relation ID, source examples, context family, cue/output codebook, teaching history, candidate neuronal ensemble observations, associated astrocyte observations, delayed outcomes, counterexamples and the current claim level. It links to the relevant structure/function/intervention/task graph without collapsing them into one edge. The label is an index to evidence, not an address that directly reads a biological fact.

An engram candidate is nominated on discovery data, then tested selectively on new data and delayed cues. Associated astrocytic participation is registered independently. Both can contribute to the same acquired relation. An axonal projection is a physical communication route, not sufficient evidence that it carries the full content of the relation.

## Independent child ownership

Each child's training data, readout, chronology, source lot, calibration, retained relation set and resource needs are separate. A parent can request a typed answer or review, but cannot overwrite the child's history by changing a software label. A child can decline an unknown request. Parents and children both undergo isolated reevaluation after joining.

Weights are contextual and revisable. A child reliable in monitoring a route can be unreliable in predicting retention. Its growth stage limits which tasks it may attempt. Anxiety-inspired vigilance can request more observations; anger-inspired protective priority can flag repeated independently verified conflicts. Neither supplies missing biological evidence or grants authority over life support.

## Training records and progress

Record a mastery vector for each relation: acquisition, 45-minute/24-hour/seven-day outcomes where tested, context generalization, interference, calibration, response latency and availability. A relation remains unconfirmed if it was only tested during active teaching. Mark failed and unknown relations explicitly; do not remove them from the history to make the Tree appear complete.

Expansion occurs when a missing relation remains after route, support and curriculum checks and a proposed addition has a testable benefit. Prefer an independently raised module with a reversible electronic route. Only later investigate whether a physical bridge or a new cell lineage improves the same declared outcome.
