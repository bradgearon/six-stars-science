# CE-ENG-001: system and circuitry specification

## Drawing set and release state

The six-sheet set covers system interconnection, one cartridge and its service path, the complete cell-free permit-board reference circuit, power/connectors/net assignments, child-mesh information routing, and commissioning. SVGs are editable vector drawings; the PDF is the review copy. `permit_board_netlist.json` is the authoritative point-to-point wiring list for the prototype. It is not a KiCad PCB, Gerber release or an electrical-rule-check certificate.

The commercial HD-MEA supplies its own sensing and electrode-drive electronics. Their proprietary internal schematic is not recreated. The custom circuitry below only grants or denies a low-voltage logical permit. J1 is initially connected to a test load and logic analyzer. A separately confirmed vendor interface must enforce that permit on every source of stimulation before live operation. A trigger input is not assumed to be a global inhibit.

## System connections

| Interface | Source → destination | Physical route | Contract |
|---|---|---|---|
| IF-01 | C/O/S/B headstage ↔ acquisition hub | Vendor cable | Raw data, selected channels, actual stimulation and errors |
| IF-02 | Hub ↔ host H | Vendor-supported data link | Ordered events, acquisition clock and measured latency |
| IF-03 | E → training scorer | Protected process interface | Training targets only after response closure; confirmation targets isolated |
| IF-04 | H ↔ L | Dedicated USB serial link | Fresh sequence-numbered status, profile authorization and acknowledgements |
| IF-05 | Permit board J1 → adapter/test load | Short 3.3 V logic lead | Prototype high=permit; low/open/unpowered must suppress at the receiving interface |
| IF-06 | Camera/sensor timestamps → H | Supported digital capture | Clock identity, exposure time and uncertainty |
| IF-07 | Sensor service → L/H | Calibrated instrument interface | Value, units, location, age and validity |
| IF-08 | Each service reservoir ↔ its cartridge/waste | Independent identified fluid path | No shared liquid in initial A/B or C/O experiments |

Reference MEA selection is MaxOne-class or a demonstrably equivalent system. Current manufacturer documentation provides raw-data/API access and external synchronization integration; its MaxLab interface separates Python setup/recording from C++ closed-loop streaming. This does not confirm a global hardware inhibit or guarantee the latency required by a future task. Obtain those answers in writing. [EXT-01, EXT-02]

## Permit-board reference circuit

Use a Raspberry Pi Pico H as the independent microcontroller, powered through its normal USB connector. Its 3V3 output powers the local logic; do not feed an external supply into that output. Use a common local digital ground. The Pico is separate from H and boots with MCU_READY and MCU_PERMIT low. All vendor equipment retains its own approved power supply.

U2 is TPL5010DDCR. Pin 1 is 3V3, pin 2 ground, pin 3 goes through R1=1.00 kΩ 1% to ground, pin 4 receives DONE, pin 5 supplies WAKE and pin 6 is open-drain RESET_N. The 1 kΩ selection corresponds to a nominal 200 ms watchdog interval; measure actual behavior. Pull RESET_N up with R2=100 kΩ, connect it to Pico RUN and the first gate. A valid DONE edge follows a successful complete control cycle, not an unconditional timer interrupt. The data sheet requires margin before the next WAKE; target a response within 50 ms in the bench firmware. [EXT-04]

U3 and U7 are SN74LVC1G08DBVR AND gates. U3 combines LOOP_OK with RESET_N. U7 combines U3's output with MCU_READY. U7's output is CLEAR_N for U5. U4, another 1G08, combines U5.Q with MCU_PERMIT to create PERMIT_RAW. For this DBV package, pins 1/2 are inputs, 3 ground, 4 output and 5 supply. [EXT-05]

U5 is SN74HC74N. Use its first flip-flop: /CLR1=pin 1, D1=2 tied high, CLK1=3 from ARM_CLK, /PRE1=4 tied high, Q1=5, /Q1=6 unconnected, ground=7 and VCC=14. Hold the unused half inactive with /CLR2 pin 13 low, D2 pin 12 low, CLK2 pin 11 low and /PRE2 pin 10 high; pins 8/9 are unconnected. CLEAR_N low resets the latch asynchronously. A new rising ARM edge is required after any clear. [EXT-09]

U6 is SN74LVC1G17DBVR: pin 2 input ARM_FILTER, pin 4 ARM_CLK, pin 3 ground, pin 5 3V3, pin 1 unconnected. S_ARM is a normally open button connecting 3V3 through R3=1 kΩ to ARM_FILTER; R4=100 kΩ and C7=100 nF connect ARM_FILTER to ground. This RC/Schmitt arrangement is an initial button-conditioning design, not a certified debounce interval; test bounce, held-button recovery and power cycling. [EXT-10]

S_STOP and S_COVER are normally closed contacts in series from 3V3 to LOOP_OK; R5=10 kΩ pulls LOOP_OK down. Opening either contact, breaking that lead or losing RESET_N drives CLEAR_N low. MCU_READY has R6=10 kΩ to ground; MCU_PERMIT has R7=10 kΩ to ground. R8=100 Ω connects PERMIT_RAW to J1.1, and R9=10 kΩ pulls J1.1 down. J1.2 is ground. Place C1–C6=100 nF at U2–U7 supplies and C8=10 µF at local power entry.

Pico assignments: GP0/pin 1 MCU_PERMIT; GP1/pin 2 DONE; GP2/pin 4 WAKE; GP3/pin 5 LATCH_Q sense; GP4/pin 6 LOOP_OK sense; GP5/pin 7 MCU_READY; GP6/pin 9 J1 permit sense; pin 30 RUN; pin 36 3V3; pin 38 ground. Other GPIOs are unused in this revision. Verify physical pin numbering against the exact board before assembly. [EXT-03]

Boolean behavior: `clear_n = loop_ok AND reset_n AND mcu_ready`; the latch becomes zero whenever clear_n is zero, becomes one only on a new ARM rising edge with clear_n high, and otherwise retains state. `permit = latch_q AND mcu_permit`. Firmware holds ready low while booting, paused or faulted, so a repaired host connection does not automatically rearm. A button held down through a fault cannot create a new rising edge after recovery.

The design detects several ordinary failures but is not a certified single-fault-tolerant safety controller. A short to 3V3, welded contact, stuck gate, common supply fault or incorrect receiving adapter can defeat it. Live deployment requires a reviewed suppression architecture, including the vendor's bounded stimulation and independent fault behavior. A faster required fault-response time may require a different watchdog or receiving inhibit. The 200 ms supervisor is not a biological exposure limit.

## Controller protocol and firmware requirements

Proposed cell-free defaults: host status every 50 ms, stale timeout 150 ms, sequence numbers strictly increasing, unique session nonce, configuration digest match, one pending test command and manual rearm after any fault. These are software prototype values only. The MCU accepts a signed-off profile identifier and bounded event permission, not arbitrary raw voltage requests. Live profile limits remain null until released.

A complete control cycle checks timebase, sensor validity, configuration, host heartbeat, interlock loop, allowed command and cumulative exposure. Only then may it pulse DONE. Status sampling is not enough if the output worker is hung. The internal MCU watchdog and external supervisor are complementary; the hardware latch provides manual rearm. Record the last fault and the actual J1 state before reset where technically possible.

Do not rely on a blanket stop-pump command. The biological service controller has its own qualified response to each fault. Stimulation permit loss must preserve ordinary culture care. Do not use the permit board to switch a reservoir heater or life-support supply.

## Mechanical and fluid schematic

Use the vendor's chip, ring, lid and headstage unmodified for the first build. The carrier locates a datum outside the active surface, provides strain relief and leaves optical access above the well. Return to the same registered electrode map after service. Exact chassis dimensions, objective clearance, seal geometry and connector offsets come from selected parts and a measured tolerance stack; sheet 02 is a functional section, not a machining drawing.

Keep C, O, S and B fluid identities separate. The first release can use supported manual exchange with complete records. Optional perfusion requires a separate validated supply, bubble handling, delivery measurement, sample access, waste route and containment. Pump flow is not inferred from its commanded speed. Thermal and gas recovery are measured at the relevant location. Do not place an arbitrary valve or absorber in a signaling study and assume it is chemically neutral.

Local sensors initially come from calibrated laboratory instruments, not an uncharacterized custom pH electrode amplifier. Record their electrical outputs before designing any adapter. A neural observer can supplement these measurements but cannot certify its own culture temperature or missing sensor data.

## Acquisition and storage

At 1,020 channels × 20 ksample/s × an assumed 2 bytes/sample, one raw electrical stream is 40.8 MB/s, 146.88 GB/hour or 3.52512 TB/day in decimal units. Three streams require 122.4 MB/s before metadata and optics. Confirm the actual stored sample format and channel availability. Optical storage is width×height×bytes/pixel×frame rate×recorded duration, plus metadata and compression policy.

Benchmark sustained writing, burst load, file rotation, disk full and restart with synthetic data. A quoted SSD transfer speed is not an end-to-end result. Preserve raw evidence sufficient for the stated claim and document discarded data. Use common captured timing events where supported and measure offset, jitter and drift; browser display time is not the acquisition clock.

## Commissioning acceptance

Bench inspection checks component identity, polarity, continuity, shorts, every pin assignment and unconnected outputs. Verify supply and current before connecting the Pico. Then use a logic analyzer to test boot, manual arm, STOP, COVER, READY loss, missing DONE, stuck-high DONE, host loss, held ARM, cable removal, restart and receiving load disconnection. Record worst observed response, not just the nominal value.

The package's software tests validate state logic and netlist completeness only. They do not execute the board, establish EMI performance, verify analog levels or qualify suppression at the MEA. Live release requires the same tests at the final receiving interface, with evidence that no queued, autonomous, alternate-client or replayed stimulation bypasses permission.

The first electrical build can therefore begin after peer review of this reference circuit. Final instrument integration depends on IF-05 being resolved. If the selected platform cannot provide the required independent suppression, change the interface or platform rather than labeling a software stop as hardware protection.
