# Company launch and execution plan

## The first product of the project

Build a research instrument that can demonstrate retained, context-sensitive learning in one human-derived neuronal–astrocytic culture, then show whether a separately trained observer improves its operation. A third support-policy learner, independent teaching recipient and physical axon bridge follow only when their predecessors work. General human understanding is a long-range aspiration, not the first acceptance endpoint.

The core C owns its task history. Observer O learns to distinguish measured states and optionally predict an upcoming unreliable response. Support learner S proposes a permitted response. Recipient B tests independent acquisition after teaching. Production P supplies characterized lots; it is separate from the active mesh. Each cartridge contains its own local astrocytic support G. The host H handles timing, encoding, logging and the electronic bridge; evaluator E holds protected targets; limit controller L controls permission independently of learned policy.

There are three different milestones: a working instrument, acquired and retained capability, and useful multi-module contribution. Fund and review them separately. A useful research finding does not require a computing advantage, while a product claim about efficiency does require a matched whole-device comparison.

## Starting organization

The initial working model is a company-led program with a qualified laboratory partner. This avoids making a custom cell-production facility a prerequisite for the first experiment. The company owns the task specification, integration, records and software; the laboratory owns the controlled biological methods and culture release. The contracts must settle data ownership, raw-data access, publication rights, background intellectual property, assay failure reporting, shipping responsibility and usable-lot replacement before ordering.

| Responsibility | Initial staffing assumption | Concrete output |
|---|---|---|
| Program and product lead | Founder plus fractional project support | Scope, stage budget, decisions and version control |
| Neural culture lead | 1.0 FTE or named partner lead | Regional lot selection, controlled methods, viability and maturity release |
| Electrophysiology and integration | 1.0 FTE | MEA qualification, codebook, delivered-output evidence |
| Software and embedded systems | 1.0 FTE | Host, isolated evaluator, bridge, records, permit-board firmware |
| Statistics and assay analysis | 0.5 FTE | Estimands, allocation, power update, blinded analysis |
| Lab operations and quality | 0.5 FTE | Inventory, calibration, records and maintenance coverage |
| External specialists | Scoped contracts | Electrical design review, microscopy, stem-cell oversight and counsel |

These are responsibility allocations, not hiring requirements for seven different people. A lead may cover several roles, but the person who optimizes the candidate should not be the only person adjudicating its sealed confirmation result. The founder does not need to become the cell-culture operator to start the company.

## Facility and service requirements

Use a site already capable of human-cell research, aseptic culture handling, qualified environmental support, appropriate source storage, waste handling, contamination testing and incident response. Secure microscopy and MEA access during both maturation and evaluation. Reserve independent support and observation for simultaneous modules; a single headstage used sequentially cannot establish real-time coupling between two cartridges.

The engineering bench needs an oscilloscope or logic analyzer, a current-limited low-voltage supply, a multimeter, digital test loads and labeled harnesses. Keep wet culture, dry electronics and service materials partitioned. Use supplier power supplies and approved mains distribution. The reference permit circuit is low voltage; it does not switch building power or drive culture electrodes.

Separate task-control machines from general internet browsing. Preserve full configuration hashes, access roles and a second copy of critical records. Facility continuity planning must distinguish losing task processing from losing life support. A host reboot should not interrupt the culture's independently qualified support.

The laboratory determines the oversight route for the selected cells and assays, including provenance and consent permissions. ISSCR guidance supports documented quality, provenance and reproducibility; it is guidance, not a substitute for the applicable local review. This program contains no clinical administration, transplantation or whole-embryo production. A later change in scope requires a new project decision. [EXT-08]

## Planning budget

The figures in `startup_budget.json` are company planning allowances in USD, not supplier quotes, salaries surveyed today or commitments to spend. The base scenario assumes six months, four FTE equivalents across the roles above, access through a partner facility and procurement or contracted access to the first instrument configuration. Taxes, international shipping and facility construction are excluded unless added to a quote.

| Cost group | Base allowance |
|---|---:|
| People, loaded six-month allowance | $360,000 |
| Lab space and partner services | $90,000 |
| MEA and optical hardware/access | $180,000 |
| Cells, chips and analytical services | $100,000 |
| Host, storage, engineering and calibration | $30,000 |
| Contracts, quality and insurance | $40,000 |
| Subtotal | $800,000 |
| Contingency at 25% | $200,000 |
| Planning total | $1,000,000 |

The illustrative low/base/high totals are $550,000/$1,000,000/$1,625,000, obtained from the explicit assumptions in the JSON. They are runway scenarios, not forecasts of success. Reduce capital through contracted access before reducing independent replication or raw-data retention. Obtain itemized quotes and a phase-specific purchase order before authorizing the next stage.

## Day-one work orders

1. Appoint the culture, electrical and analysis owners; approve the narrow C0/C1 task and the human-cell sourcing requirement.
2. Open the controlled record set. Preserve v0.4 and this package as immutable baselines. Assign one owner to every launch blocker.
3. Send the prepared vendor questionnaire through the company's normal process after choosing recipients. No messages have been sent by this package.
4. Request a joint MEA/cell-supplier compatibility discussion: specific chip generation, raw access, two-unit synchronization, optical access, medium and independent stimulation suppression.
5. Start T00 with synthetic events and T01 with the permit-board test load. Do not connect the prototype to an instrument trigger or electrode input before its electrical interface is confirmed.
6. Obtain the proposed source lot certificates, relevant permissions, exact supplied methods and a reference co-culture quote. Reserve cells only after the receiving and support path is identified.
7. Lock the pilot question and exclusions. Set a maximum pilot spend and a decision date based on actual supplier lead times.

## First 90 days as a planning sequence

| Window | Work and decision |
|---|---|
| Days 1–10 | Staff owners, obtain RFIs, inspect data contracts, run software harness and design review |
| Days 11–30 | Freeze bench interfaces, assemble and test the cell-free permit board, measure acquisition/storage timing, establish lab methods |
| Days 31–60 | If receiving gates pass: obtain and characterize reference lots; qualify electrode/optics/medium compatibility. Otherwise continue bench work and resolve the blocker |
| Days 61–90 | If G1–G3 pass: run a limited acquisition/retention pilot and estimate preparation-level variation. Do not promise joining by a calendar date |
| After the pilot | Freeze a candidate and fund confirmation only if instrument validity and feasibility support it. Add O, then S/B in separate campaigns |

Human neuronal maturity and vendor lead times may extend these windows. Dates are scheduling assumptions; biological gates are binding. The program may require multiple maturation cycles. Do not allocate all funding to hardware before the pilot proves usable preparations can be obtained consistently.

## Decision and change records

Every promotion names the data, protocol version, independent reviewer, unresolved limits and scope of the claim. A failed candidate remains in the record. A supplier substitution, new medium, new cell subtype, stimulation revision or changed readout creates a successor configuration and triggers the relevant requalification.

Ready today: planning, contract drafting, vendor RFIs, offline software and a reviewed cell-free prototype. Not yet released: living stimulation, final chassis manufacture, proprietary MEA internal circuitry, biological affect mechanisms and a broad human-understanding claim. The release register gives a concrete closure test for each item rather than leaving a general warning.
