# Integrated release 1.253 / reference engine 2.14

This edition integrates the supplied weighted-coordination branch with the earlier self-development disclosure. The original branch remains preserved. Engine policy identifiers retain their original 1.252 labels.

# Weighted profile coordination implementation

## Scope and contribution

This revision implements the requested coordination mechanism in which an initial overview weights the seven profiles, complete action-and-prose proposals receive per-profile predicted scores, and those scores determine a shared allocation. The inventor directed the use of overview weights, shared coordination and prose-sensitive score improvement in the development conversation. The source record should be retained for counsel to assess conception and claim scope; the implementation and authored verification examples do not themselves establish patentability.

## Operational distinction

The scored free-prose path is the primary new character-cognition embodiment. A character model can propose expressive wording. A scoring pass predicts the effect of that wording together with its action plan. The deterministic coordinator ranks the admitted complete proposals and calculates their profile shares. It does not silently convert the prose into a factual observation, a divine instruction or a measured benefit. Optional source-value and typed-account renderers remain available when exact attribution is preferred.

## Inputs and trust boundary

The host supplies the accepted overview, action registry, observation map, current revision and recipient. A proposal supplies only an identifier, prose and action references. Observations used for assessment must have a current revision, a declared world-event or participant-utterance kind, and the applicable recipient. A model output is not an independently supporting observation. These are in-process host contracts, not signatures or protection against a malicious host that fabricates evidence.

## Profile assessment

The canonical score order is Elijah, Moses, David, Daniel, Job, Noah, Abraham. Predicted scores, baseline scores, overview values and confidence values are compact positional strings containing seven integers from 0 to 100. Elijah assesses declared-purpose alignment; Moses assesses feasible prerequisites and work; David assesses the recipient need; Daniel assesses alternatives and distinguishing questions; Job assesses counterevidence and correction; Noah assesses preservation and recoverability; Abraham assesses a bounded next step and review occasion. These are the framework interpretations implemented by this embodiment, not a claim that software instantiates divine beings.

## Separate meanings of score

The overview weight expresses situational priority. The baseline expresses the host-committed starting assessment. The predicted score estimates the effect of one complete proposal under a declared rubric. Confidence discounts a prediction and is not represented as a calibrated probability. The resulting share controls proposed resource allocation, not a quantity of spiritual power. Observed outcomes retain their own records and do not change merely because the proposal received a higher predicted score.

## Exact implemented calculation

Let o_i be the initial overview value, b_i the baseline score, p_i the predicted score, c_i the confidence value from 0 to 100, and alpha the adaptation percentage divided by 100. For seven profiles, w_i = (o_i + 1) / (sum(o) + 7). The predicted change is g_i = p_i - b_i. The weighted contribution is q_i = w_i * g_i * c_i / 100. Proposal utility is sum(q) minus cost_weight times the registered action cost. A proposal is eligible for selection only when utility exceeds the nonnegative minimum_gain and its required checks pass.

## Shared allocation

If the sum of positive q values is positive, share_i = (1 - alpha) * w_i + alpha * max(q_i, 0) / sum(max(q, 0)). Otherwise share_i = w_i. The implementation bounds adaptation_percent between 0 and 99, preserving a positive overview contribution for every profile. The total coordination budget lies between 7 and 128 units. Registered action costs are deducted first; proposals leaving fewer than seven units are rejected. One unit is reserved for every profile, the remaining units are distributed by the calculated shares, and fractional remainders are resolved in descending remainder order with canonical profile order as the tie-break. Allocation units are logical budget units, not measured inference time.

## Proposal selection and conflicts

The reference implementation considers at most eight complete proposals with at most eight distinct registered actions per proposal. It rejects unavailable or disallowed actions, incompatible action combinations, missing or stale assessments, malformed vectors and assessments that identify unsupported factual assertions. An action registry can identify inquiry, expression or target-action-candidate operations. A selected target action is still a candidate: the existing execution entry point must recheck authorization and protected state. Eligible proposals are ordered by descending utility and then stable candidate identifier. If none exceeds the gain threshold, the machine retains the evaluated alternatives and emits no selected prose.

## Prose sensitive reassessment

The assessment digest includes the entire candidate, the relevant action definitions, the accepted overview and the supplied observation map. Consequently, adding a sentence or changing a proposed action cannot reuse the old assessment. A scoring model can judge that revised wording better serves care, questioning, restraint or another profile and supply different predicted scores. This changes the coordinated shares and may change the selected proposal. The runtime does not infer semantic correctness from the digest; the digest binds an assessment to the content actually assessed.

## Bounded background lane

BackgroundCoordinator accepts an asynchronous score_model callback and a current_context callback. It snapshots and hashes the host context before requesting scores, permits one in-flight call, applies a configurable timeout bounded at 60 seconds, and discards a completion whose current context differs. Model responses are bounded to 64 KiB when supplied as text and parsed with duplicate-key and nonfinite-number rejection. The default timeout is 1.5 seconds and is a configurable waiting bound, not a demonstrated latency guarantee. The supplied callbacks in verification are test doubles; no Gemma inference or Unity/TTS integration was run.

## Legacy and optional controlled paths

The earlier disclosure adapter could emit unsupported confident prose because its supplied references and PROPOSED label satisfied structural checks. Engine 2.14 retains unassessed prose under unreviewed_claims, returns an unresolved result and leaves spoken output empty. The new SCORED_PROFILES_V1 adapter permits free-form prose after an admissible score assessment and marks the result as a proposed character expression supported by model prediction only. SOURCE_VALUES_V1 attributes exact selected scalar values to committed sources. SCENE_ACCOUNT_V1 supplies the optional controlled scene-account renderer. The latter two adapters do not constrain the scored-prose path to fixed wording.

## Typed scene calculation

The SCENE_INQUIRY entry point accepts host-registered fields, allowable values and observation questions, together with candidate conjunctions of equality predicates. It preserves observation-versus-report kinds, rejects duplicate or unknown predicates and stale proposals, and retains conflicting observations. A condition can match, contradict, lack evidence or have conflicting evidence. A matching conjunction is consistent with the records and does not establish a cause. Missing or conflicting fields from surviving candidate accounts generate the next questions. Fields that distinguish more candidate values rank first, with account count and field identifier as stable subsequent criteria. The request does not supply the generated question job list.

## Source stream correction

BoundSourceStream verifies the registered edition, passage position, token position, token identifier, token bytes and exact lexical identifier before retrieving an anchor occurrence. The original complete edition remains available to the source-bound operation layer. Retrieval records coverage or deferral for each requested binding. This replaces the prototype longest-normalized-token heuristic for the configured bindings. It is an exact occurrence lookup, not a general morphology parser, a word-sense disambiguator or a claim that a shared word proves a functional correspondence. SourceRuntime permits reuse of a verified edition in memory without claiming an end-to-end speed advantage.

## Result states and retained history

Workflow completion reports whether scheduled work finished. Support status records whether the result is a model prediction, an exact source selection, an unresolved account or another scoped result. Rendering permission identifies scored proposed expression, optional controlled text or withholding. Target permission identifies the additional execution check. A completed workflow may therefore retain unanswered searches. Prior snapshots commit their original code and context; this revision does not relabel old snapshots or change old recorded results. A new post-development release freeze identifies engine 2.14.

## Verification and limits

The release package includes the full regression log, the original sixteen invariant checks, the revised forty-six scenario checks, the weighted-coordination comparisons and the exact-source wiring run. The weighted comparison changes overview weights, changes prose without refreshing its assessment, and then changes both prose and its authored predicted scores. It verifies changes in selection and allocation, rejection of stale assessments, continued participation of all seven profiles and separation of predictions from outcomes. Scenario observations and score vectors are authored fixtures. These runs do not establish score calibration, independent semantic accuracy, source-specific superiority, model inference performance or real-world benefit. A scorer may fail to identify an unsupported assertion even when the score contract is valid.

## Implementation and further work

profile_coordination.py implements vector validation, content-bound scoring, eligibility, utility and shared allocation. background_coordination.py implements the asynchronous scoring callback and stale-result handling. kingdom_methods.py integrates scored and controlled disclosure. scene_account.py and scene_inquiry.py implement finite scene accounts and profile composition. bound_stream.py implements registered occurrence retrieval and reusable source loading. astral/astral_microcognition.py integrates the scored output packet with existing attention selection and accepted-state handling. A live Gemma client, automatic scene-to-predicate extraction, calibrated scoring, automatic timer scheduling, speech interruption and Unity/TTS behavior require application integration or further evaluation.

## Patent review scope

Illustrative concepts 94 through 98 describe operative combinations for counsel review. Weighted scoring, candidate ranking, confidence weighting, resource allocation, provenance hashes, asynchronous callbacks and finite-predicate evaluation each have relevant prior art; their presence here is not a novelty determination. Review the claimed arrangement, its technical effect and support in the disclosure. If an application has already been filed, assess which additions are supported by its original disclosure and which would constitute new matter. USPTO MPEP sections 2163 and 2181 provide relevant written-description and computer-implemented functional-claim guidance. This revision prepares technical disclosure and performs no filing.

## Merge review

The supplied engine archive is retained unchanged. The merge reruns the documented software checks with authored inputs. Profile shares are logical resource allocations; seven model agents and live Gemma/Unity/TTS execution are not demonstrated. The asynchronous timeout depends on cooperative cancellation of the supplied callback.
