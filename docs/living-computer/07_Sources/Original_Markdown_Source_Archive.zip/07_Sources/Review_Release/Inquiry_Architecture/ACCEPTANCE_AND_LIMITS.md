# Inquiry acceptance and limits

The 1.243 reference implementation checks exact contextual source occurrences and executes explicitly specified inquiry movements. Its documentary replay consumes known research and authored jobs. It is not an independent discovery comparison.

The new tests cover missing and complete lists, duplicate rejection, edition scope, absent targets, lexical versus English-label matching, scoped and unavailable apparatus, transitive/cyclic dependency propagation, exact arithmetic, separate branches, unknown operators, zero division, unsupported accounts, resumability, commitment changes, ancestry checks and common-boundary delegation. Target-action behavior remains governed by the inherited gate and its regression tests.

The original jewel research and supplied calculation image remain separate inputs. The inherited research contains the LXX witness detail and cautions about different Greek jewel words. This update recomputes contextual lexeme occurrences from the bundled editions but does not freshly verify the LXX passage. The reason for the list difference and jewel-to-virtue allocation remain unresolved.

The code's ten handlers participate in the new fixture. This is coverage, not discovery quality. Neutral labels, an ordinary comparison baseline and a displaced-binding control have not been evaluated on independent held-out cases. New-handler synthesis and automatic admission remain specified future work.
