# ChristEye Inquiry Architecture v1.243

We Develop Software LLC | Brad Gearon | 11 November 2026

## Architecture and movement

ChristEye generates, evaluates and guides proposed changes through a source-derived inquiry architecture. Bound ancient words and layered expressions shape its structures, operation definitions, context rules, retained state and further development. Knowledge denotes retained information; Understanding denotes encoded capacity to apply relationships in context. Calculate coordinates Word, Search Out, Judge and Move: it assembles a candidate account and performs explicit reckonings while preserving their different source bindings. Dig, Search, Search Out and Deepen are distinct investigative movements. Mystery routes inquiry toward an unresolved explanation; Outside routes retrieval beyond an identified inquiry boundary. Each movement preserves its source interpretation, inputs, scope, alternatives and result. Inquiry-state movement is distinguished from a target intervention, which remains subject to the existing eligibility gate. Later source readings can propose successor operations and structures through recorded review and validation. Target outcomes and voluntary user participation are assessed separately.

These functions are core to the CE60-1.4+INQUIRY-1.243 profile. The legacy CE60 inventory and garden action selector remain compatible. The overlay adds seven distinct main terms and nine bindings, since Dig and Calculate each retain multiple lexical bindings. A word, lexical identity, contextual sense, source occurrence and executable handler remain distinct. A target role does not rename the source term.

A movement is a versioned state transition. INQUIRY movements change a query, selected scope, retrieval frontier, representation, dependency assessment or explicit calculation. TARGET_ACTION_CANDIDATE movements request a change to the ordinary target system and must use the common execution gate. Numeric equality cannot supply a missing observation, authorization, causal mechanism or semantic interpretation. Calculate can be re-entered after a search or judgment; the architecture is not a one-pass pipeline.

## Layered source bindings

The contextual anchors are recomputed by exact lexical identifier against the bundled OSHB Hebrew and TAGNT Greek editions through CombinedEdition. The selected passages are INTERPRETIVE_PASSAGE anchors, not claims of first historical occurrence. All nine anchors are present in the pinned bytes. Token matches and edition closure are preserved in bindings.json. A successful token match establishes the occurrence, not the scientific or theological truth of the operational interpretation.

The hidden-treasure bridge retains separate verbs: Proverbs 2:4 uses H2664 and Job 3:21 uses H2658; both use the hidden-treasure expression H4301. Luke 6:48 separately uses G4626 and G900 before the foundation is laid. These relations motivate different handler functions rather than a claim that every word is a lexical synonym. Job 3 concerns anguish and longing for death; this context is retained rather than turned into an instruction to pursue death.

Calculate H2808 is a noun in Ecclesiastes 7:27 and supplies an account-assembly binding. Calculate G5585 is a verb in Revelation 13:18 and also appears in Luke 14:28 for cost reckoning. Related G5586 occurs for the white stone in Revelation 2:17 and a vote in Acts 26:10. This lexical family supports investigation of reckoning, naming and judgment while each occurrence keeps its contextual sense. Neither the derivation nor the shared noun proves a numerical cipher or a particular identity.

| Entry | Lexical identifier | Contextual anchor | Sense | Operation |
| --- | --- | --- | --- | --- |
| Dig | H2658 | Job 3:21 | Dig or search for | Compare a selected reference arrangement with an observed arrangement. Preserve the anguish context of the anchor. |
| Search | H2664 | Proverbs 2:4 | Search | Look for a specified target within an identified supplied catalog. |
| Search Out | H2713 | Proverbs 25:2 | Examine or search out | Examine competing accounts and scoped apparatus. |
| Dig | G4626 | Luke 6:48 | Dig | Trace foundation dependencies. |
| Deepen | G900 | Luke 6:48 | Deepen | Extend a foundation investigation under an explicit depth bound. |
| Calculate | H2808 | Ecclesiastes 7:27 | Account or reckoning noun | Assemble explicit relations into a candidate explanation. |
| Calculate | G5585 | Revelation 13:18 | Calculate or reckon verb | Execute a declared arithmetic expression graph. |
| Mystery | G3466 | Mark 4:11 | Mystery | Route an unresolved expression toward a proposed explanatory account. |
| Outside | G1854 | Mark 4:11 | Outside | Identify retrieval candidates beyond an explicitly recorded boundary. |

## Mystery outside and deepening routes

Mystery search asks what relationship could explain a recorded expression, arrangement or unresolved pattern. Outside search asks what relevant source, member or alternative lies beyond an explicitly identified boundary: a list, passage, edition, supplied catalog or model. Deepening asks which assumptions and dependencies support an existing account. Mark 4:11 is the source association for Mystery and Outside; computational routing is the framework's operational interpretation of that contextual access distinction. The code does not classify people spiritually.

The implemented router operates on explicit supplied candidates and typed jobs. It does not automatically translate an arbitrary natural-language instruction into a correct semantic graph, and it does not search the full Bible autonomously. Source-to-handler interpretations, job selection, relation assertions, scopes and alternatives in the demonstration were authored during development. The executor performs exact comparison, supplied-catalog lookup, dependency traversal, scoped reassessment, explicit arithmetic and recorded account assembly.

## Absence and apparatus operations

A gap comparison identifies the selected reference, observed arrangement, edition, passage, labels, positions, groups and source references. The implementation rejects duplicate labels until a multiset adapter is supplied. It preserves exact labels and does not silently normalize different mineral names. An absent group is a computed difference relative to that selected reference; it is not proof that the second passage was intended to be complete or that a missing virtue exists.

The search can investigate literal recurrence, alternative naming, displacement, another witness, a proposed functional substitution or deliberate literary selection. A functional match requires an explicit relationship and supporting passage. Absence from a nonexhaustive list, an unavailable source and an apparatus omission are separate gaps. Unsuccessful searches retain their scope and leave the proposed completion unresolved.

An apparatus record identifies VARIANT, TRANSLATION, CROSS_REFERENCE, IDENTIFICATION_UNCERTAINTY or UNAVAILABLE; its source, anchor, nonempty scope, scope rationale and alternatives remain explicit. A substantive alternative creates a branch and propagates a reassessment request through declared dependent relationships. It does not overwrite the original reading or increase evidence permissions. An unavailable note creates APPARATUS_GAP. The handler can reach a whole-section conclusion only when the supplied dependency graph and scope justify that reach; co-occurrence alone does not expand scope.

## Calculate judge and resumable dig

Account assembly accepts explicit relations, source references, alternatives, missing predicates and discriminating tests. Its output remains INTERPRETATION_PROPOSED with QUERY_SEED permission. Reckoning accepts bounded named integer inputs and an ordered expression graph of addition, subtraction, multiplication, division, squaring and equality; values are exact rational numbers. Unknown operators, references to unavailable values, duplicate result names, zero divisors and resource-limit violations are rejected or recorded as unresolved. The rule selecting inputs remains visible alongside the arithmetic result.

An InquirySession binds jobs to a context, operation registry and verified contextual bindings. Each execution event records the job, used binding, route, result, predecessor event and movement kind. A bounded dig call completes only its allocated jobs and retains the remaining job identifiers as the frontier. A serialized snapshot can resume without rerunning completed jobs. It commits bindings, context, registry and implementation bytes. Dependency traversal separately preserves its depth frontier and missing dependencies; a later Deepen job can explore that frontier under a larger declared scope.

Digest checks detect accidental or uncommitted changes within this in-process reference implementation. They are not signatures, access control, independent timestamps or proof that an untrusted operator did not reseal an altered record. Production authentication, durable storage and untrusted input isolation require a deployment adapter. Source bytes are checked when begin_inquiry builds its bindings; callers constructing InquirySession directly are responsible for supplying the verified binding records. Target actions from the session delegate to the existing execute_guarded path.

## Source guided growth

Further readings can motivate proposed successor bindings, structures or operations. A growth proposal preserves predecessor registry, binding, handler, rationale, assessment plan and required contract tests, counterexamples, review and successor registry. Its current implementation is a proposal record for an existing compatible handler; it cannot load arbitrary code or automatically admit a newly invented handler. New-handler synthesis, review authorization and automatic registry promotion remain specified development work. Existing operation admission is separate from empirical promotion of a target claim.

The machine can retain failed, neutral and contradicted candidates as well as successful ones. A source-derived growth proposal does not receive self-confirmation from its own generated account. The user's confidence, an arithmetic equality or a retrieved duplicate cannot replace a missing support predicate. Earlier negative and mixed garden results remain part of the record. This release does not rerun those experiments or claim to repair their efficacy limitations.

## Jewel and calculation demonstration

The authored demonstration compares the twelve ESV Exodus 28 labels with the nine ESV Ezekiel 28 labels. It computes the absent third-row labels jacinth, agate and amethyst and detects changed relative ordering of the shared labels. A supplied Revelation 21 catalog places the three labels at foundations 11, 3 and 12. Equal English labels establish a textual comparison, while mineral identity and symbolic allocation remain unresolved.

The inherited jewel archive records a Greek Ezekiel list of twelve stones and exact-lexeme qualifications: jacinth and agate have different Greek terms across the compared lists; amethyst has closer Greek lemma continuity. An outside candidate requests the additional Greek witness; a supplied variant note reopens the Ezekiel-list comparison and dependent account. The new run does not freshly verify the LXX source or decide the direction of textual change. The inherited archive and its byte digest are retained so documentary replay is not misrepresented as a new independent discovery.

The arithmetic handler factors 666 and 616 and follows the user-declared selection rule: use each input's largest prime for one branch, each other distinct prime base once per input for the second, set repeated exponents aside, add 1 to the first branch and divide the second by 2. It reproduces (37+11)+1=49 and (2+3+2+7)/2=7; squaring the second gives equality. The proposed meanings of 1, 2 and the resulting numbers remain interpretation records. Combining manuscript alternatives and choosing these transformations are not instructions established by Revelation itself.

The supplied fixture queues ten jobs covering all ten implemented handlers and nine bindings. Pass 1 performs two jobs and saves eight pending jobs. Pass 2 resumes and completes the remaining jobs. Contract tests compare resumed and one-shot snapshots. The run is an authored documentary replay, not a blind discovery experiment, an independently measured advantage or an allocation of personal heavenly rewards. No target action is executed. Original jewel-study retrieval and analyst interpretation remain distinguished in its preserved process record.

## Implementation and verification

Engine 2.10 provides christeye/dig.py, christeye/inquiry_bindings.py, begin_inquiry in christeye/inquiry.py, inquiry_demo.py and tests_dig.py. The legacy CE60-1.4 validator remains strict; the separate vocabulary overlay records its predecessor and seven additional main terms. The full interchange schema retains legacy schema_version 1.9 and adds inquiry arrays. Compact inquiry exports are validated against the separate inquiry runtime schema; they do not claim to populate all full-interchange records.

Reproduce with python inquiry_demo.py inquiry_results/pass_01 --budget 2, followed by python inquiry_demo.py inquiry_results/pass_02 --budget 20 --resume inquiry_results/pass_01/snapshot.json. Run python -m unittest tests_dig -q for the new acceptance suite and the documented full unittest command for regression checks. Results are recorded in VALIDATION_v1.243.json after the run rather than presumed from historical logs.

## Source register

- LEX-DIG-H: https://biblehub.com/hebrew/2658.htm — Dig/search lexical reference; contextual occurrence independently recomputed from bundled source bytes.
- LEX-SEARCH-H: https://biblehub.com/text/proverbs/2-4.htm — Search and hidden-treasure terms.
- LEX-SEARCHOUT-H: https://biblehub.com/hebrew/2713.htm — Search out and examine.
- LEX-DIG-G: https://biblehub.com/lexicon/luke/6-48.htm — Separate dig and deepen verbs before foundation.
- LEX-ACCOUNT: https://biblehub.com/text/ecclesiastes/7-27.htm — Account/reckoning noun.
- LEX-RECKON: https://biblehub.com/greek/5585.htm — Calculate verb in Revelation 13:18 and Luke 14:28.
- LEX-STONE: https://biblehub.com/greek/strongs_5586.htm — Stone/vote concordance.
- MYSTERY-OUTSIDE: https://biblehub.com/text/mark/4-11.htm — Mystery and outside contextual anchor.
- ESV-EXO28: https://www.esv.org/Exodus+28/ — Selected ESV jewel labels; supplied and retrieved during planning.
- ESV-EZK28: https://www.esv.org/Ezekiel+28/ — Selected ESV nine-label list.
- ESV-REV21: https://www.esv.org/Revelation+21/ — Selected ESV foundation labels.
- INHERITED-STUDY-LXX: https://www.die-bibel.de/en/bible/LXX/EZK.28 — LXX detail retained from inherited study, not newly retrieved for implementation.
- NET-VARIANT: https://classic.net.bible.org/passage.php?passage=Eze+28%3A13%2C14 — Textual note consulted during planning; inherited witness comparison remains separately labeled.
