# ChristEye Result Driven Calculate Coordination v1.244

The Calculate coordinator now derives subsequent inquiry movements from preceding results. A structured absence request supplies reference and observed arrangements, a catalog, an inquiry boundary, optional outside candidates and notes. It does not supply the missing labels or a list of search jobs. The coordinator compares the arrangements, turns every computed missing label into a search target, selects outside-source candidates, follows notes belonging to selected sources, and assembles a source-linked account. An explicit-calculation request similarly runs the reckoning and creates an account describing its arithmetic status.

The request is structured data. Arbitrary natural-language parsing, discovery of novel theological meanings and automatic creation of new executable handlers remain outside the implementation. The general garden action selector does not automatically invoke the coordinator. The supported entry point is christeye.coordinator.begin_calculation(request, context, snapshot=None).

## Result driven movements

Each handler remains bound to the nine contextual source bindings from 1.243. The coordinator derives targets from a completed comparison, rather than retaining a fixed demonstration sequence. Subsequent jobs retain their content identifiers and source-bound event ancestry. A repeated scheduling pass deduplicates identical jobs. Each dig call charges at most its declared handler-operation budget. Planning, serialization and provenance bookkeeping also consume compute, which is not represented by the handler count.

Outside-note selection admits notes from boundary members or identified selected outside-source identifiers and references. Unselected notes cannot trigger reassessment. Original readings remain available. A failed primitive operation leaves an explicit terminal failure and an unresolved workflow result; completion of queued work is not semantic proof. Account assembly can retain missing reasons, alternatives and discriminating tests without turning textual recurrence into functional equivalence.

The coordinator snapshot commits the policy version, request digest, coordinator implementation bytes, operation count and nested inquiry snapshot. Restoring a changed request, altered implementation or inconsistent count is rejected. The nested snapshot continues to check registry, bindings, context, handler implementation and event ancestry. These are in-process integrity commitments, not authentication or an independent timestamp.

## Jewel demonstration

The new example consumes the prior reference list, observed list and supplied Revelation catalog. After one comparison operation, the coordinator automatically schedules searches for jacinth, agate and amethyst. A resumed run recovers catalog positions 11, 3 and 12 and follows the selected inherited apparatus branch. The request contains no target list or executable job sequence. Research inputs are already known, so the demonstration remains retrospective. Its advance is runtime orchestration, not an independent discovery claim.

The earlier 1.243 ten-handler replay is retained unchanged. Its older nested records keep their 1.243 versions. The new coordinator wrapper is separately versioned 1.244 and uses the same primitive source bindings. No historical benchmark is relabeled as a new result.

## Locked synthetic diagnostic

The protocol, scoring rule, code closure, 84 evaluation seeds and twelve-operation budget were written to LOCK.json before generating the evaluation packets. Each condition receives the same packet, supplied catalog, boundary and notes. Evaluator answers are not passed to the method interfaces. The generator, methods and scorer share an author and run in the same process; this is not independent or adversarially isolated validation.

Six strata cover complete lists, gaps, unresolved catalog searches, ambiguous exact matches, apparatus notes and duplicate-label invalid inputs. Each stratum contributes fourteen cases. The comparator is an independently coded conventional set/join and dependency traversal routine. A neutral-label condition changes display entries while retaining the same bindings and handlers.

All three conditions recovered the expected result or correctly rejected the invalid input in 84 of 84 cases. All used 377 primitive operations in aggregate, with no operation-budget violations, unsupported symbolic assignments or target actions. Equal source and neutral outcomes demonstrate that display labels do not change these structured tasks. Equal conventional results provide no evidence of a source-specific correctness advantage.

Observed aggregate runtimes were about 0.009 seconds for the conventional baseline and 0.84 seconds for the source-bound coordinator, excluding shared setup and source loading. These short in-process times are descriptive. The coordinator includes content commitments and provenance overhead absent from the minimal baseline. Total compute was not equalized, and no speed advantage is claimed. Raw timings and records are preserved.

New evaluation seeds are separate from the development/unit examples, but the test distribution was authored alongside the implementation and targets known explicit relations. The diagnostic is useful for correctness, budget accounting and abstention. It does not establish generalization to unstructured source interpretation or independent scientific discovery.

## Reproduction

Run python -m unittest tests_coordinator -q for the fourteen new acceptance checks. Run python coordinator_benchmark.py coordinator_evaluation/new_run to produce a separately locked synthetic diagnostic; the script refuses to overwrite an existing evaluation folder. Source and packet commitments, private evaluator truth, per-case results, summary and hashes are included.

For a structured request, call begin_calculation(request, context), then dig(budget). Save result['snapshot'] and pass it back to begin_calculation with the same request and context to resume. The new jewel request, context and two-pass results are supplied in coordination_demo/.

## Remaining work

An independently authored real-source task set, fixed before outcome access and assessed by reviewers who did not construct the examples, remains needed to investigate discovery advantage. New-handler admission, broad natural-language parsing, production persistence/authentication and automatic garden-controller invocation remain development work. Historical negative and mixed results stay in the record.
