# ChristEye layered behavior and bounded construction 1.256

Engine 2.17 implements the layered-expression plan in a bounded internal reference. Its source contracts preserve earliest lexical anchors, later contexts, attributed functional meanings and explicit gaps. The corpus covers 31,155 passage records in 66 books; first occurrence means pinned corpus order, not historical utterance order.

## Source and behavior contract

The 93 contracts comprise 60 vocabulary entries, nine inquiry bindings, 13 Kingdom entries, six components and five expression operations. All ten groups are accounted for: Whole/Soul, Word/Knowledge, Spirit, Heart, Understanding, Milk, Honey, Wind/Movement, Roots and Fruit. Five expression contracts have executable effects; 88 retain source-inquiry gaps. The whole corpus can be indexed without claiming that every contextual sense has been exhaustively interpreted.

Each operation retains source identity, contextual reading, functional interpretation, allowed state changes, expected content change and counterexamples. Exact lexical branches retain their own earliest occurrences. Compound and modern terms without an exact identity report an anchor gap. Layer weights allocate finite review-planning units; mandatory evidence and authority conditions cannot be outweighed.

## Mixed execution

The two expression families remain SLAY and SPLENDOR. Their registered internal operations are QUALIFY, WITHDRAW, PAUSE, CLARIFY and PROPOSE_REPAIR. Source imagery and engineering interpretation remain separately attributed. QUALIFY's selected slay branch first occurs at Matthew 2:16 (G337); later correction, humility and grace connections do not redefine that lexical occurrence.

Structured claims retain original text, scope, type, evidence, counterevidence and status. QUALIFY reduces assertion status on unsupported claims, WITHDRAW preserves a deactivated claim, CLARIFY makes the structured account more explicit, PAUSE changes internal eligibility and PROPOSE_REPAIR records an unexecuted proposal. Supported facts survive qualification. A withdrawal followed by clarification cannot revive an assertion.

The controlled renderer quotes source claims as data and supplies their status. Arbitrary prose that contradicts the previewed structure is rejected even with favorable authored scores. Critiques bind to the exact content, target, steps, evidence, context and policy. Contextual relevance, meaning preservation, dignity and scope of support remain separately judged. Missing evidence, material disagreement and unresolved required critique hold execution. An evidence identifier does not itself prove entailment.

The serial compiler admits up to sixteen registered nodes. Source context comes first, preservation second and scheduled review last. It rejects cycles, unknown handlers, unsupported capabilities, false costs and stale targets. BehaviorCycle assesses the complete proposal across Elijah, Moses, David, Daniel, Job, Noah and Abraham, then commits the entire internal transition once with preserved predecessors. Explicit abstention records a reason, baseline prediction and zero confidence; it does not bypass requirements.

## Bounded self-construction and selection

SelfBuilder performs bounded breadth-first goal search over an immutable primitive-effect library. It generates a new composition from declared goals rather than receiving a task-specific workflow recipe. The kernel, source parser, primitives, renderer and evaluator were implemented with human direction and AI assistance; the runtime does not autonomously create those foundations.

FrozenEvaluator commits held-out structured tasks and a fixed promotion protocol. The builder receives no held-out task content. DevelopmentCycle records each admitted attempt before evaluation, compares the actual candidate and incumbent results and can promote an eligible successor automatically. The predecessor supports explicit rollback. Default attempt budget is one. The nominal paired-sign policy is a check on authored fixtures, not a population-level efficacy inference.

## Verification and evidence

523 unit tests passed. Additional checks: 16 invariants, 46 authored Astral scenarios, seven weighted comparisons, 11 covenant checks, 16 individual-expression checks and 21 layered-construction checks (117 total). The new 62 unit tests cover semantic mismatch, hedged infallibility, quoted/refuted claims, preserved arithmetic, stale evidence, disagreement, graph rejection, transaction retry, restart, attempt limits and rollback.

The generated successor completes 12 of 12 authored structured task bundles, compared with 0 of 12 for the deliberately limited incumbent. The bundles require qualification, detailed presentation and a retained question. This demonstrates that added functionality under a committed policy, not superiority over ordinary AI, measured research time saved or scientific discovery. Critiques and follow-up observations are explicitly authored fixtures.

Inspect `verification_1_256/layered_release/`: `construction.json`, `candidate.json`, `protocol.json`, `comparison.json`, `receipt.json`, `development.json`, `state.json` and `summary.json`. The SQLite records support restart. The code commitment is `independent/FREEZE_v2_17.json`, created after development; it is not retrospective preregistration.

## Current boundaries and migration

This trusted-host, single-writer reference performs internal effects only. It does not supply OS isolation, authenticated external evidence, live Gemma/Unity/TTS calls, wall-clock scheduling or independent semantic truth validation. Questions and review ticks are retained state. Due work requires a host call; no background service is implied. Promotion is bounded to the tested scope. Real outcome-driven adaptation remains future work.

Do not reopen a 2.16 session under changed policy. Preserve it, export the records with provenance, explicitly import them into a new session and reassess. The root-relative `engine_2_16_to_2_17.patch` applies with `git am` to unchanged 2.16 code. The ZIP includes all runnable files.

Patent Appendix S adds technical paragraphs CE256-01 through CE256-28 and illustrative concepts 107–112. Existing concepts 1–106 remain unchanged. Code and test evidence improves the disclosure's specificity; novelty, nonobviousness and priority require claim-specific attorney review. No filing or legal allowance is represented.
