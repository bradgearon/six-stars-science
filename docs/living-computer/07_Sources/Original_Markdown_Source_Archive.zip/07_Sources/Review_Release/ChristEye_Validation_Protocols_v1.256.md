# Current release 1.256 / engine 2.17

The current implementation is specified below. The preserved predecessor document follows as historical development disclosure; its version-specific limits and counts do not override this current section.

# ChristEye layered behavior and bounded construction 1.256

Engine 2.17 implements the layered-expression plan in a bounded internal reference. Its source contracts preserve earliest lexical anchors, later contexts, attributed functional meanings and explicit gaps. The corpus covers 31,155 passage records in 66 books; first occurrence means pinned corpus order, not historical utterance order.

## Source and behavior contract

The 93 contracts comprise 60 vocabulary entries, nine inquiry bindings, 13 Kingdom entries, six components and five expression operations. All ten groups are accounted for: Whole/Soul, Word/Knowledge, Spirit, Heart, Understanding, Milk, Honey, Wind/Movement, Roots and Fruit. Five expression contracts have executable effects; 88 retain source-inquiry gaps. The whole corpus can be indexed without claiming that every contextual sense has been exhaustively interpreted.

Each operation retains source identity, contextual reading, functional interpretation, allowed state changes, expected content change and counterexamples. Exact lexical branches retain their own earliest occurrences. Compound and modern terms without an exact identity report an anchor gap. Layer weights allocate finite review-planning units; mandatory evidence and authority conditions cannot be outweighed.

## Mixed execution

The two expression families remain SLAY and SPLENDOR. Their registered internal operations are QUALIFY, WITHDRAW, PAUSE, CLARIFY and PROPOSE_REPAIR. Source imagery and engineering interpretation remain separately attributed. QUALIFY's selected slay branch first occurs at Matthew 2:16 (G337); later correction, humility and grace connections do not redefine that lexical occurrence.

Structured claims retain original text, scope, type, evidence, counterevidence and status. QUALIFY reduces assertion status on unsupported claims, WITHDRAW preserves a deactivated claim, CLARIFY makes the structured account more explicit, PAUSE changes internal eligibility and PROPOSE_REPAIR records an unexecuted proposal. Supported facts survive qualification. A withdrawal followed by clarification cannot revive an assertion.

The controlled renderer quotes source claims as data and supplies their status. Arbitrary prose that contradicts the previewed structure is rejected even with favorable authored scores. Critiques bind to the exact content, target, steps, evidence, context and policy. Contextual relevance, meaning preservation, dignity and scope of support remain separately judged. Missing evidence, material disagreement and unresolved required critique hold execution. An evidence identifier does not itself prove entailment.

The serial compiler admits up to sixteen registered nodes. Source context comes first, preservation second and scheduled review last. It rejects cycles, unknown handlers, unsupported capabilities, false costs and stale targets. BehaviorCycle assesses the complete proposal across Elijah, Moses, David, Daniel, Job, Noah and Abraham, then commits the entire internal transition once with preserved predecessors. Explicit abstention records a reason, baseline prediction and zero confidence; it does not bypass requirements.

## Bounded self-construction and selection

SelfBuilder performs bounded breadth-first goal search over an immutable primitive-effect library. It generates a new composition from declared goals rather than receiving a task-specific workflow recipe. The kernel, source parser, primitives, renderer and evaluator were implemented with human direction and AI assistance; the runtime does not autonomously create those foundations.

FrozenEvaluator commits held-out structured tasks and a fixed promotion protocol. The builder receives no held-out task content. DevelopmentCycle records each admitted attempt before evaluation, compares the actual candidate and incumbent results and can promote an eligible successor automatically. The predecessor supports explicit rollback. Default attempt budget is one. The nominal paired-sign policy is a check on authored fixtures, not a population-level efficacy inference.

## Verification and evidence

523 unit tests passed. Additional checks: 16 invariants, 46 authored Astral scenarios, seven weighted comparisons, 11 covenant checks, 16 individual-expression checks and 21 layered-construction checks (117 total). The new 62 unit tests cover semantic mismatch, hedged infallibility, quoted/refuted claims, preserved arithmetic, stale evidence, disagreement, graph rejection, transaction retry, restart, attempt limits and rollback.

The generated successor completes 12 of 12 authored structured task bundles, compared with 0 of 12 for the deliberately limited incumbent. The bundles require qualification, detailed presentation and a retained question. This demonstrates that added functionality under a committed policy, not superiority over ordinary AI, measured research time saved or scientific discovery. Critiques and follow-up observations are explicitly authored fixtures.

Inspect `verification_1_256/layered_release/`: `construction.json`, `candidate.json`, `protocol.json`, `comparison.json`, `receipt.json`, `development.json`, `state.json` and `summary.json`. The SQLite records support restart. The code commitment is `independent/FREEZE_v2_17.json`, created after development; it is not retrospective preregistration.

## Current boundaries and migration

This trusted-host, single-writer reference performs internal effects only. It does not supply OS isolation, authenticated external evidence, live Gemma/Unity/TTS calls, wall-clock scheduling or independent semantic truth validation. Questions and review ticks are retained state. Due work requires a host call; no background service is implied. Promotion is bounded to the tested scope. Real outcome-driven adaptation remains future work.

Do not reopen a 2.16 session under changed policy. Preserve it, export the records with provenance, explicitly import them into a new session and reassess. The root-relative `engine_2_16_to_2_17.patch` applies with `git am` to unchanged 2.16 code. The ZIP includes all runnable files.

Patent Appendix S adds technical paragraphs CE256-01 through CE256-28 and illustrative concepts 107–112. Existing concepts 1–106 remain unchanged. Code and test evidence improves the disclosure's specificity; novelty, nonobviousness and priority require claim-specific attorney review. No filing or legal allowance is represented.


---

# Preserved predecessor disclosure (1.255)

# ChristEye validation protocols v1.255

Current engine: 2.16. Current expression contract: [Slay and Splendor](Expression_Operations_v1.255.md).

461 unit tests, 16 original invariant checks, 46 authored Astral scenario checks, seven weighted-coordination comparisons, 11 covenant-lifecycle checks and 16 expression-lifecycle checks. Authored scores and follow-up events. Two internal transitions; no live model or external execution.

## Preserved predecessor design and validation history

# ChristEye validation protocols v1.254

Current engine: 2.15. Current contract and acceptance details: [Covenant coordination](Covenant_Coordination_v1.254.md).

423 unit tests, 16 original invariant checks, 46 authored Astral scenario checks, seven legacy coordination comparisons and 11 covenant-lifecycle checks. All example predictions and world events are authored. Live model/game execution and comparative product benefit remain unmeasured. V2 is opt-in and adds required host checks, profile floors and decline limits before ranking, loss-preserving confidence treatment, and durable outcome records.

## Preserved predecessor design and acceptance history

The following text retains its 1.253 and earlier context; the current contract above and Appendix Q supersede current-version statements.

# ChristEye validation protocols v1.253

Current reference engine: 2.14. This merge includes weighted profile coordination, prose-sensitive reassessment, optional finite scene accounts, source occurrence checks and a bounded model callback interface. See Weighted_Profile_Coordination_v1.253.md and the supplied profile review schema. Existing growth proposals remain restricted to compatible registered handlers.

Merge checks rerun the supplied 382 unit tests, 16 invariants, 46 authored Astral checks, seven coordination comparisons and source wiring. Predictions remain separate from observations. Live model, game and speech integration are open acceptance items.

## Preserved prior design and acceptance history

The following sections retain their revision 1.252 context; current runtime status above supersedes historical statements of unchanged engine 2.13.

# ChristEye validation protocols v1.252

Reference engine 2.13 is unchanged. Earlier records report 319 unit tests and 16 original invariants. This release performs document, schema and package consistency checks; it does not report a new engine or biological test.

## Governed self development acceptance plan

These conditions apply to a future implemented extension or a documented developer-reviewed successor workflow. They are prospective requirements, not completed experimental results.

1. Identify the predecessor, source closure, affected component, proposed difference and contributor roles before successor assessment.
2. Keep proposed, implemented, assessed and admitted states distinct. Retain failed and unresolved proposals.
3. Reject a growth proposal that names an unknown or incompatible handler in the existing propose_growth API. Preserve NOT_ADMITTED for the existing function.
4. Evaluate a successor separately from the active predecessor. Preserve evidence permissions, source rules, lineage, context checks and applicable authorization.
5. Define contract tests, counterexamples, resource limits and replay/migration expectations. A generated favorable account cannot satisfy independent assessment.
6. Record admission authority and the separately versioned successor; do not silently mutate historical snapshots.
7. Claim improvement only for a declared comparison with recorded outcomes, including regressions and costs. Use unfamiliar cases for generalization claims.
8. Distinguish document/schema checks, software correctness, research productivity and downstream scientific outcomes.

## Preserved validation history through release 1.246

The sections below retain their original release context.

# Kingdom validation protocol

The release separates regression preservation, new behavior checks, source closure and outcome claims. All new cases were authored with this implementation. They are useful acceptance tests and counterexamples, not an independent effectiveness study.

## Reproduce

Run from the engine root, with the inherited requirements installed:

```bash
python -m unittest tests_kingdom -q
python -m unittest discover -p 'tests*.py' -q
python tests_v2.py
python kingdom_demo.py kingdom_results/your_new_run
```

The demo refuses to overwrite a directory. It saves its request/context, two-pass resume, final result, missing-schema outcome and exact contextual registry. The source files are bundled; this example needs no web access.

## Acceptance conditions

1. Verify all thirteen contextual spans and the two explicit versification mappings. Reject altered or unavailable spans. Preserve the CE60 and seven-entry inquiry inventories.
2. Demonstrate all seven profiles on multiple operations and declared recipient models. Remove a required input for each profile, then disable that profile to show its specific effect. This ablation establishes policy activity, not scientific or spiritual advantage.
3. Verify that hard constraints, source boundaries and permissions still apply when profiles are disabled or agree. Test protected targets, unknown permissions, missing sources and human authorization.
4. Preserve original expression bytes. Reject missing schema fields, substituted schemas, duplicate keys, unsupported adapters and mismatched recipients. Hold downstream disclosure when interpretation is unresolved.
5. Reject unsupported promotion of proposed prose into observed evidence. Require prospective forecast fields before outcome reporting. Keep text rendering, comprehension and target outcome separate.
6. Verify resource limits, stable selection, zero-budget behavior, deterministic resumption, context invalidation and rejection of resealed modified events. Do not execute target actions during replay.
7. Verify explicit target-action handoff, the common gate, changed-context rejection and no blind retry after an executor exception. Use only in-memory callbacks in tests.
8. Rerun inherited unit tests and the original sixteen invariant checks. Preserve historical manifests and evaluation results under their original versions.

## Evidence limits

The main diagnostic checks a supplied trace with a low queue wait and a timeout, an explicitly supplied dependency graph, and a supplied decoding schema. It does not independently discover a service fault or establish the truth of the proposed explanation. Its five operations and deterministic policy-unit count describe this fixture only. The negative case removes a schema field and verifies an unresolved interpretation and held disclosure.

The inherited 84-case comparison is historical; no new correctness advantage is inferred from it. A suitable next effectiveness study would use independently authored tasks, a preregistered scoring rule, equal information and resource limits, conventional and neutral-label controls, and separately assessed recipient comprehension and practical outcomes. The current release does not claim that source labels themselves improve performance.

The source/code freeze is a post-development integrity record. It is not a preregistration, digital signature or independent timestamp. Snapshots are for controlled replay, not adversarial authentication.


# Inherited validation protocols from v1.244

<!-- Current release: documents 1.244 and engine 2.11; result-driven coordination is described in the final section. -->

<!-- Current: documents 1.243, engine 2.10. Earlier version statements and results below are historical unless explicitly updated by the Revision 1.243 section. -->

# ChristEye Validation Protocols v1.243

## Central architectural principle

ChristEye provides an extensible architecture that converts words and layered expressions from identified ancient scriptural sources into operational inputs for generating and evaluating proposed changes to contemporary systems. Source-linked interpretations, subject models and retained outcome records support successive rounds of inquiry as new problems and evidence become available. The architecture is intended for continuing use without requiring the underlying source corpus to change.

Source word → recorded interpretation → proposed system change → assessment → retained experience → future proposals.

The long-term objective spans technology, healthcare, bioscience, engineering, community and fellowship. Continuing usefulness is a design objective, not a guaranteed outcome. Registered interpretations and supported adapters define the implemented scope; arbitrary words and domains are not automatically executable. The founder’s thousand-year vision expresses intended longevity, not a measured service life.

Document revision 1.14 adds the Tree of Knowledge exhibit and illustrative claim concepts 77 through 79. Engine 2.9 and its empirical results are unchanged. Versioned interpretations, replaceable subject adapters, durable records and reassessment under new evidence express the intended extensibility; future compatibility requires maintenance and validation.


Current release: documents 1.243 / engine 2.10. The core inquiry additions are described in the Revision 1.243 section; older sections retain historical scope. The Version 1.13 optional refinement section is authoritative for this addition. Version 1.12 describes the earlier experimental integration. Historical sections below retain their original releases. The Version 1.12 integration status section supersedes earlier statements about current integration; earlier results remain historical.

Current revision: engine v2.7.1, 60 executable bindings and 181 passing checks. Earlier version-specific descriptions and results below are historical; sections 14–15 govern the new bridge and Joint merge.

**Version 1.10 · November 10, 2026 UTC · Research protocols remain proposed; completed software checks reported separately**

This revision separates software operability, fidelity to the framework's interpretation method, prediction accuracy and useful outcomes. The supplied synthetic pilot and name-prediction dry run do not validate the scripture, D11, expert-reader or Heart embodiments. The framework's layered interpretation method is central to the ChristEye generation condition; participation by a live interpreter is optional.

The ChristEye source-bound condition requires the 60-entry source vocabulary and recorded interpretation method. The stream is an optional reading mode. Source-neutral and translation-only conditions are explicitly labeled experimental controls.

## 1. Common controls and commitment procedure

Before recruiting or collecting outcomes, select the actual study, primary comparison, scoring rule, smallest worthwhile effect, sample-size rationale, exclusion rules and analysis. The numbers below are planning examples, not a power calculation. Identify who generates cases, who contributes interpretations, who holds the key and who scores outcomes. Record prior exposure and conflicts of interest.

1. Freeze the protocol, role rubric, eligibility rules, source corpus, lexicon, method profile, software and environment. Hash all files and retain the files themselves. Define how missing data, abstentions, disputed labels, failures and adverse outcomes enter denominators.
2. Draw cases using a recorded sampling frame and seed. Keep task families or source families disjoint between development and evaluation where related cases could leak answers. An independent custodian retains the key and its provenance. The generator's accessible files, tools and network must exclude that key; the key must not merely be an unused argument in the same generation process.
3. Persist complete predictions and reader contributions, including alternatives, uncertainty, source spans, abstentions and timestamps. Bind them to a GenerationSnapshot containing input, code, rule, weight and execution-profile digests. Obtain a separate append-only or independent commitment receipt before the declared outcome-access phase.
4. Reveal the key or collect the specified observations. Score the persisted predictions without regenerating them. Retain failed cases and all predeclared exclusions. Later interpretations belong to a new snapshot and must not replace the locked ones.
5. Publish or retain an auditable report with the sampling flow, committed artifacts, outcomes, uncertainty and limitations. Public registration or posting is a separate action; coordinate disclosure timing with patent counsel. Nothing in this document has been posted or filed by this update.

A hash establishes integrity of particular bytes; replay establishes reproducibility under a declared execution profile. Neither proves that answers were absent from annotations, prior human knowledge or model training. A restricted corpus can contain answer-bearing information. Claim only the knowledge boundary actually audited.

## 2. Name and interpretation prediction study

### Questions and conditions

Use a held-out sample of terms with independently established, context-qualified functions. This is initially a semantic prediction test on known functions, not evidence of discovering new biology.

| Condition or comparison | Input and purpose |
| --- | --- |
| D8 | A source-cited naming rationale or literal gloss, with modern functional explanations removed under a fixed rule; unknown rationale stays unknown |
| D8 + D11 | The identical D8 packet plus an interpretation recorded under the frozen MethodProfile before function reveal |
| Permutation control | Reassign inputs or predictions within predeclared exchangeable strata; preserve the sampling and clustering structure |
| Baseline | A predeclared simple lexical method and majority-class reference, using the same permitted information |

The primary comparison should be D8 + D11 versus D8 on the same cases if the objective is to test added value from deep reading. D8 versus permutation and the simple baselines are secondary unless declared otherwise. Select one primary outcome before the study; adjust for any additional confirmatory comparisons. Preregister a directional or two-sided test rather than choosing one after seeing results.

### Sampling, annotation and masking

An independent selector samples from a named glossary or corpus. Include eponyms, descriptive names and historically misleading names as predeclared strata, or exclude a category before sampling with a stated scope limitation. Do not remove difficult names after observing performance. A planning sample of 100–200 terms may be useful, but the final size requires an effect-size and clustering calculation.

The source annotator may recognize the term and its function. Do not claim that this person is answer-blind merely because the answer key is hidden. Log familiarity, source passages and any accidental functional disclosure. Distinguish the original naming rationale from a modern gloss written with hindsight. Use an independent audit to apply a frozen leakage rule; report flagged cases rather than quietly discarding them.

Readers declare whether they knew each term or function before interpretation. Capture literal sense, their alternate reading, typed association hops, target relation, proposed role, alternatives and confidence. Freeze these contributions before revealing functional definitions. Keep known and unfamiliar items distinguishable in analysis. A model with general pretraining is an unsealed reader even if prompted to use only the packet.

At least two independent coders assign reference roles using a frozen rubric and a masked functional description. Masking may be imperfect when a definition identifies the term; record guesses and failures of masking. A referent can have multiple valid roles in different contexts. Use either a prespecified multi-label score or one explicitly scoped primary role, with adjudication rules fixed before prediction reveal. Report agreement and disagreements; do not tune the rubric to achieve a chosen agreement threshold.

### Analysis and interpretation

Report total-case accuracy or the selected multi-label score, coverage, accuracy conditional on a prediction, abstentions and uncertainty intervals. Abstentions count as incorrect in the primary total-case accuracy unless the registered loss function explicitly assigns another cost. Use identical case denominators for paired comparisons.

For independent cases with binary correctness, a paired exact test can assess D8 + D11 versus D8. Related terms, shared naming roots, repeated readers and shared source templates require a clustered or hierarchical analysis; simply treating all rows as independent is invalid. Permutations must respect exchangeability and prespecified strata. Ten thousand fixed-seed shuffles are a computational choice, not a guarantee of valid inference. Report effect sizes and intervals alongside p-values.

A positive result would show predictive utility for the tested inputs, readers, functions and sampling frame. It would not establish that names encode all capabilities, that a spiritual interpretation is biologically causal, or that the framework has produced a treatment. Failure to reject a difference is not evidence of equivalence; equivalence requires a predeclared margin and adequate precision.

### Status of the supplied harness

`name_prediction_test.zip` is retained as supplied. Its dry run was authored with knowledge of the terms and is suitable only for checking execution. The current implementation prints lexicon and prediction hashes before reading the key, but does not persist a complete prediction artifact, obtain a commitment receipt or enforce key isolation. Its code recomputes predictions for scoring rather than loading a committed artifact.

Before real use, add strict input and unique-ID validation, an explicit unknown/ambiguous match policy, persisted artifacts, separate generation and scoring phases, and case-level provenance. Review prefix matching and tie-breaking. The supplied permutation calculation is not a paired test of the D11 increment. The `reader` column does not produce a reader comparison or account for repeated readers. Implement and independently check those analyses before describing them as available. Do not use the included dry-run accuracy as a result for the invention.

## 3. Design-quality study

### Three-arm bundle comparison

| Arm | Inputs and process |
| --- | --- |
| A: Full ChristEye | Frozen machine plus the recorded reading method, source interpretations, name decoding, D11 and parable templates |
| B: Neutral structural machine | The same structural algorithm, action set and scoring policy, with neutral labels and without the interpretive bundle |
| C: Conventional method | A declared conventional analysis process with the same task brief, base evidence, resource budget and output limit |

A versus B measures the effect of the **whole added interpretive bundle** in this design. Because labels and information also change, it cannot isolate scripture, labels or D11 individually. Add a separate label-only control that preserves every input, relationship and operation while changing only labels if the question is whether the labels themselves affect decisions. Test D11 or reader input through separate predeclared ablations. The synthetic pilot's neutral relabeling already produced identical decisions for that implementation; it did not test the fuller interpretive bundle.

All arms receive the same base problem packet. Record any additional source material, human contributions, retrieval and computation by arm. Match relevant generation time, search budget, access to domain expertise and opportunities to revise. If information quantity is part of the intended advantage, report it as part of the bundle instead of attributing the effect solely to its spiritual origin.

### Generation and review

Twelve problems across several domains can form a feasibility pilot. They are not automatically enough for a confirmatory claim. Prefer independently authored problems, multiple generators per condition and randomized condition assignment blocked by relevant expertise. Plan crossed or balanced coverage so reader identity and problem difficulty are not confounded with condition. A one-week delay does not erase knowledge from generating another answer to the same problem; use different held-out cases or independent teams where carryover matters.

Use a common output template and neutral vocabulary for review. An editor may standardize presentation while preserving substance; keep originals, edits and an audit trail. Record reviewers' guesses about condition to assess masking. Independent human domain reviewers provide the primary judgments. AI reviewers may supply exploratory sensitivity analyses, but do not count them as additional independent human experts or pool them without a declared model of dependence.

Predefine rubric anchors for feasibility, mechanistic specificity, testability, risk handling and expected usefulness. Novelty ratings are judgments relative to the reviewers' knowledge, not a patent prior-art search. Select one primary quality endpoint and the A–B contrast. Analyze problem, generator and reviewer dependencies; report intervals and all prespecified secondary contrasts with multiplicity handled appropriately. Define the smallest worthwhile improvement in advance. A statistically detectable but negligible difference need not justify deployment.

The earlier estimate of six weeks and $8,000–15,000 was a planning suggestion, not a quote or validated budget. Obtain a scoped estimate after fixing case count, generator replication, reviewer time and analysis support.

## 4. Readers, apprentices and recorded method

The framework's interpretation method can be represented in MethodProfile and ExpertContribution records. A live contributor may be the inventor, a specialist trained in the framework's method of interpreting the bound ancient scriptural corpus, a source-language scholar or a domain expert; a model contribution is separately identified. The scriptural corpus supplies the source material, and the framework specifies how layered relationships are interpreted and applied. Each contribution retains source references, contributor identity, interpretation method and review status. These are different competencies. A degree does not demonstrate fidelity to the framework's method; a spiritual description of an interpreter is not an empirical qualification.

The reading log should record exact source or uncertain passage matches, literal sense, attributed deep reading, association path, proposed target, observable, alternatives, prior familiarity, timing and later outcome. Knowing verse numbers is unnecessary: a concordance can locate a remembered phrase, with uncertainty preserved. A target such as 500 entries is a workload proposal, not a proven training requirement.

Separate **method fidelity** from **predictive utility**. Train apprentices on one set; evaluate them on source- and task-disjoint examples. Assess whether they preserve the rules, alternatives and evidence boundaries before measuring whether their generated predictions work. Agreement on examples used during training cannot establish transfer. Keep selection procedures and access-controlled training notes separate from blinded outcome scoring.

Compare multiple readers in each relevant group if making group-level claims. A single inventor-versus-scholar result applies to those individuals and cases, and can reflect prior knowledge, task fit or other differences. It cannot by itself establish a proprietary advantage, a training effect or spiritual authority. Repeated prospective evaluation and independent replication are needed to estimate a reliable contribution.

A model trained from scratch on declared scripture and annotations may be evaluated as a restricted-input embodiment. Audit the annotations for answer-bearing content, record the training procedure and test held-out performance. A small corpus may not train a useful model; restriction alone guarantees neither competence nor absence of contamination. Any pretrained base, embeddings or teacher-model output must be declared in the knowledge boundary.

## 5. Heart response and rooting study: separate proposal

The Heart mechanism concerns voluntary response selection, participant-defined needs, immediate relief, later functioning and retention. Its four dimensions—breadth, length, depth and height—are provisional evaluation categories, not a validated psychological scale. The example weights are illustrative. Consent, the ability to decline and required safety conditions precede ranking.

For an initial low-risk evaluation, choose a concrete participant-selected routine and compare the four-dimension ranking with an appropriate conventional selection rule using the same support options and resources. Predefine measures, follow-up, confounds, adverse outcomes and stopping conditions. Keep immediate relief distinct from durable benefit, and continued prompting distinct from independently initiated behavior. Report withdrawal and unwanted effects. A clinical or neural-mechanism study requires its own qualified design and applicable review; the software test does not authorize it.

No Heart intervention, clinical study or neural engram measurement has been performed by this update. The synthetic pilot, name dry run and document/schema checks must remain separately labeled.

## 6. Adaptive stream evaluation

### Freeze the implementation and distinguish the flow variable

For a new consolidated release, preserve the YES2 integration and repaired controls already reviewed in v2.3 before evaluating the proposed controller. Retain finite-number rejection, complete identity candidates, immutable source/weight state and evidence-origin checks. Verify empty and malformed source handling, context/negation preservation, cursor bounds, source exhaustion, zero flow, hard work caps and replay. A test suite passing on the earlier branch does not establish these repairs.

The supplied experiment measures **corpus coverage**, not **allocation of a fixed candidate budget**. Its co-occurrence suggestions are precomputed, and its reviewer consults the reference role. Use it as an exploratory label-retrieval result. Its 1,000 simulator cases repeatedly use 20 authored templates and related labels. No real adaptive-flow gain, general source advantage or clinical result has been established.

### Controller question

Compare four policies: the current bounded generator without added source allocation; a fixed allocation; targeted/stall-only allocation; and the proposed adaptive policy. If the current generator lacks source access, this contrast measures access plus control; isolate allocation by comparing the three source-enabled policies on the identical corpus. Predefine the primary contrast, for example adaptive versus the best fixed policy chosen solely on development data.

Hold starting graphs, identities, role rules, reading operators, actions, gates, candidate limits and source access constant for allocation comparisons. Fix total passage/byte, indexing, proposal, evaluation and operation budgets. Count unsuccessful scans and duplicate candidates. Report actual usage as well as assigned budgets. A policy that reads more may be evaluated as a resource-quality tradeoff but cannot be described as an equal-work improvement.

Tune regime choices, stall thresholds, K, minimum feedback, score definitions and pending caps on development cases. Freeze them for held-out cases. Alternatively preregister an online evaluation in which the update rule is fixed, events are revealed in time order and no future answer is accessible before prediction commitment. Do not repeatedly inspect held-out results to choose the policy. Use the same learning opportunities across conditions, independent case authors and blocked/randomized assignment; account for carryover and shared learning history.

### Source and reading-method questions

With the controller fixed, compare scripture, matched ordinary text and neutral functional descriptions under the same source/work limits. Match source length, available task information and editing opportunities as closely as possible and disclose residual differences. Add several prespecified shuffled realizations, preserving the quantities the hypothesis actually requires. Global shuffling of retained tokens destroys passage co-occurrence as well as syntax and meaning; a win over that control cannot identify which feature mattered. A technical-text comparator addresses practical utility beyond a degraded-text control.

On the same corpus, compare ordinary lexical/literal processing with the inventor's recorded layered operators. Preserve the same role information, candidate limits and access to expertise. This is the method ablation; the corpus comparison alone does not test D11. Train an apprentice and freeze the MethodProfile on disjoint material. Keep reader identity, prior familiarity and author involvement in analysis. Scope a positive result to tested readers, sources and tasks.

### Identity review and useful-outcome endpoints

Collect labels and reference roles independently of the lexicon and source-term list. Freeze the latter before case selection. Compare top-1/top-3 suggestion quality, coverage, total-case accuracy and accuracy conditional on a suggestion using explicit denominators. Keep a complete candidate-role set. Use a genuine masked adjudicator with access only to the allowed packet; measure incorrect confirmations and abstentions. The ideal reviewer that accepts only the reference answer is an upper-bound workflow aid and must be reported separately.

Declare one primary endpoint: unique independently useful outcomes by a fixed horizon per assigned work budget. Define useful, deduplication, independent origins, adverse-effect criteria, and successful discrimination before running. Report confirmed yield with resolution coverage; absence of confirmation is not a negative observation. Retain empty-output episodes, pending results, unresolved identities, retractions and harms. Report absolute differences and uncertainty; show relative gains only with their exact base measure. A simulator score increment is not an idea-quality percentage.

Define stuck status before extra reading and use all qualifying stuck cases as the rescue denominator. Record how many remain unresolved. Analyze paired outcomes at the actual independent unit or use an appropriate clustered/hierarchical design. Repeated cases sharing a template, labels, source or reader do not create equivalent independent observations. Fix multiplicity handling for flow sweeps and source/method contrasts. Choose sample size from the intended effect and clustering, not from a favorable pilot percentage.

### Feedback and replay tests

Predeclare follow-up horizon, matured-cohort membership, pending-work cap, harm suspension and late-evidence policy. Attribute each outcome to the generation-time FlowDecision. Keep later-successor policies and earlier cutoff summaries immutable. Exclude repeated-origin descendants from useful credit; unknown ancestry remains unresolved. Gate acceptance, string match, co-occurrence and simulation calibration receive separate operational records.

Commit source versions, source positions, policy/regime, graph and weight state, exposures, quota remainders, predictions and stopping status before outcome access. Test delayed and out-of-order assessment delivery, repeated evidence, incorrect source versions, zero candidates, insufficient feedback, no eligible regimes, source exhaustion and interruption/resume. Reproduce the same declared output and passage-selection sequence under the recorded profile. A private licensed corpus can be audited by an authorized evaluator; omitting it from a distributed package limits that package's independent replay scope.

### Status of the supplied stream experiment

Nineteen tests passed in this review. Stored counts are 114/142 correct for the lexicon, 121/142 for lexicon plus real stream, and 118/142 for lexicon plus shuffled stream. On the 25 lexicon abstentions the top suggestions are correct for 7 and 4 respectively. The 3.52-point stream-alone comparison is a different endpoint from the 2.11-point combined-method difference. The supplied stream-alone full-flow interval crosses zero; no confirmatory conclusion is adopted from the multi-setting sweep.

The simulator outputs were reproduced from the committed suggestion table, and code fingerprints and local receipt chains checked. The ESV corpus itself is absent, so source parsing and suggestion generation were not rerun. Under ideal review, mean changes are +0.077953, +0.107324 and +0.091509 for strict, real-stream assisted and shuffled assisted conditions. These are conditional synthetic results. They motivate the controlled studies above and do not execute them.

## 7. Readiness record


| Item | Current status |
| --- | --- |
| Existing 1,000-case synthetic pilot | Historical v1 reproduced; limitations and corrected denominators retained in Design v1.4 |
| Neutral-label pilot comparison | Identical decisions in that implementation; no isolated word benefit shown |
| Name-prediction harness | Supplied dry-run scaffold; commitment and analysis changes required |
| D8 versus D8 + D11 study | Proposed; no real-data result |
| Reader and apprentice comparisons | Proposed; no group-level result |
| Three-arm design-quality study | Proposed; bundle and label-only questions distinguished |
| Heart and rooting study | Proposed; no efficacy or neural-mechanism result |
| Supplied v2 stream branch | 19 tests passed; simulator replayed from committed suggestions; source corpus unavailable |
| Repaired v2.1 | Historical 47-check base; preserved in integrated v2.2 |
| Adaptive fixed-work controller and stream comparisons | Proposed; no held-out efficacy result |
| Historical 31-entry source branch | 20 supplied tests passed; 31 draft entries plus three optional identifiers; source table not connected to planner or manifest |
| Current CE60 foundation | 60 entries and 60 executable bindings in v2.7.1, including Joint G719 in the pinned Greek edition; interpretation approval and empirical studies pending |
| Historical integrated v2.2 | 65 invariant checks pass; four-condition source wiring demonstration with verified receipts; no independent discovery result |
| Reviewed v2.3 cycle/estimator branch | 70 checks and 1,000-case regression rerun; ESV four-condition case replayed; no independent discovery result |
| Supplied v2.4 binding/garden branch | 84 checks pass; 27 bindings demonstrated; 206 Hebrew identifier/order comparisons and full garden replay verified; audit gaps and branch consolidation remain (Section 11) |
| Patent/design/schema integration | Documentation and data-contract work; not evidence of real-world discovery |

This document supersedes the earlier protocol's claims that the harness was ready for a locked real study, that A–B isolated scripture alone, or that one reader comparison could establish the source of a proprietary advantage. It preserves those questions as testable hypotheses.

Revision 1.2 adds controller, corpus and reading-method comparisons; delayed-credit, pending-cohort and fixed-work rules; and the separately reviewed stream results. Protocols remain unregistered and unexecuted as confirmatory studies.


## 8. Source foundation verification and contribution study

### Verify the records before testing the method

Freeze the 60-entry inventory, per-entry functional predicates, exact editions and annotations, canon order, tokenizer, normalization rules, lexeme namespaces, alignments, framework interpretations and code. Source scholars check textual and lexical accuracy; the inventor or trained readers check fidelity to his interpretation method; domain judges assess target-system claims. These are separate judgments. Keep dissent and abstention, and record prior familiarity with target answers.

Verify a first-occurrence result per lexeme and edition by recomputing it from the complete declared corpus. Independently check its order key and matching rule. Test sense-filtered anchors separately from whole-lexeme anchors. First occurrence is not historical dating. Manuscript-attestation claims require an identified witness, locator and source for the date or date interval. Keep lexical, translation and interpretation review statuses distinct.

Required record tests include shared lexemes across different framework entries; one entry with several proposed lexemes; disputed Lotus mappings; Mind's competing anchors; Marrow's lexical alternatives; inflected Breath tokens; polysemous Anger; Hebrew and Greek counterparts; partial translation alignments; variants; missing source bytes; changed canonical order; altered normalization; duplicate identifiers; and mutable content with a stale hash. None may silently resolve to the alphabetically first candidate. A source-bound run with missing required bindings must stop or produce an explicit gap.

### Establish that the foundation changes computation

Trace an independently authored case from source token through binding, interpretation, operation, hypothetical graph and candidate to the common gate. Check that the recorded lineage was traversed before the candidate was emitted. Disable or exchange a binding under a controlled test and inspect the expected computation change. A trace can demonstrate use of the method; it does not show better outcomes. Retain the repaired gate tests in every subsequent source-module change.

### Compare the source language and the reading method

Use held-out cases and a fixed total candidate-evaluation budget. Predeclare one primary question and comparison rather than selecting the best result afterward. A practical factorial comparison is:

| Condition | Source representation | Interpretation |
| --- | --- | --- |
| A | Reviewed source-language lexemes and passage alignments | Frozen inventor method |
| B | Same source-language records | Literal/function-only operations |
| C | Matched translation text without source-language links | Frozen inventor method |
| D | Matched translation text without source-language links | Literal/function-only operations |

A minus B estimates the method increment with source-language records available. A minus C estimates the increment from those records under the method. The difference of those increments tests interaction. Source annotations can contain additional information, so report their content and compute cost; this comparison does not isolate ancientness as a causal property. Relabeling a fixed graph is a separate invariance test. An additional no-stream versus stream comparison concerns reading mode, not presence versus absence of the foundation.

For the first-occurrence rule, compare first-lexeme anchors with predeclared alternatives: other occurrences sampled from the same lexeme, a matched contextual passage, and an independently selected sense-specific anchor. Match token or reading budgets and keep selection blind to target answers. A first-occurrence advantage must be measured rather than assumed.

Score unique useful target proposals and adverse outcomes using the existing independent review and provenance requirements. Retain denominators for all assigned opportunities, including abstentions and failed bindings. Report binding coverage separately from conditional accuracy. Cluster uncertainty by independent system or task family and include multiple readers for reader-group claims. Keep development annotations and evaluation cases disjoint. Record repeated-origin evidence and pending outcomes separately; no literal-text match counts as a new experimental confirmation.

### Historical completion status in v1.3

The earlier supplied archive contained a 31-entry draft `roots.py` table and three optional identifiers, adopted as Bone, Breath and Seed in v1.3. Its 20 supplied tests passed in review. That branch left the source table outside the planner and knowledge-manifest path, with a stored digest that could become stale after mutation. Earlier result files do not measure source-language binding, first-occurrence ranking, the 34-entry registry or adaptive allocation. The v1.3 registry and fixture documented those mechanisms; the integrated v2.2 status appears below.

The separate claim in the supplied design that a real stream beat 50 shuffled copies by 6.9 points is not adopted as a verified study result: corresponding data, protocol and analysis were not supplied in the reviewed archive. Confirmatory source-foundation and reader studies remain unexecuted.

Revision 1.3 adds source-record verification, 34-entry inventory checks, operational binding traces, source-language and reading-method comparisons, and first-occurrence controls. No confirmatory study is represented as completed.


## Revision 1.4 verification and next study

The v2.2 mechanical acceptance suite checks 60 unique inventory identities and sequential ordinals; 45 core, 14 family and one extension; Bread/Seed/Light as core; family-parent closure and cycle rejection; immutable contents; per-lexeme anchors; binding and source-byte tampering; zero, invalid and empty stream inputs; exposure completeness; retained negation; foreign-source rejection; and unresolved gaps for unbound entries. The authored four-condition demonstration compares stream selection, zero flow, a changed Seed interpretation/operation, and direct source selection with zero flow. Its three-versus-zero packet counts and changed measurement request establish wiring only.

Freeze the next evaluation's vocabulary, exact source edition, executable bindings, original-language matching rules, operation registry, graph-construction protocol and flow policy before seeing held-out cases. Report binding coverage and abstentions across all 60 entries. Do not discard entries that fail to bind. Readers who supplied interpretations must be tracked separately from blinded domain evaluators. An automated token match is not an independent expert judgment about the reading.

Use independently authored tasks and matched work budgets. Compare source-bound readings with a label-only relabeling, a conventional function-based control and a predeclared displaced or shuffled-source control. Keep the underlying operations fixed when testing labels; changing both operation and wording tests the combined method. A stream's scan fraction, candidate count, gate acceptance rate and independently useful outcomes are separate quantities. The current demonstration deliberately changes the Seed operation to test participation and does not isolate the value of scripture or poetic distance.

Before comparing an adaptive flow controller, implement and test its delayed-feedback, ancestry, unresolved-outcome and budget rules. Current v2.2 mode and flow choices are caller supplied. Report no percentage improvement in good ideas until useful output, independence, harms and follow-up windows have been defined and measured on held-out tasks. Historical synthetic gains and the 142-label comparison remain separate from this revision.


## 9. Version 1.5 / engine v2.3 verification and next study

### Completed checks and scope

The supplied engine passed all 70 checks in review: 16 original engine, 31 waterwheel, 18 foundation/stream and 5 v2.3 checks. The complete 1,000-case legacy regression was rerun and matched its supplied output digest `4efa777d4c426f4061a24706d021f535b3a9bf304b6d7e7bb96a706611160c61`. Its commitment digest is `94546ce8ec195916ec823f39d7228c43d2a06f3e084ad15f87d7b19e8fa55435`. Replay and receipt verification passed. These are authored simulator cases, not independent observations of discovery or treatment efficacy.

| Synthetic condition | First-action correctness | Five-cycle mean change | Cases made worse | Acted in first cycle |
| --- | ---: | ---: | ---: | ---: |
| Chain, author-adjudicated identity | 0.801 | +0.2123 | 4.2% | 56.9% |
| Chain, strict identity | 0.407 | +0.0773 | 2.0% | 30.9% |
| Sign-aware baseline | 0.725 | +0.0915 | 24.7% | 63.3% |

First-action correctness is the fraction of all cases whose first action, whenever it occurs within the five-cycle horizon, matches the declared root and sign. No action within the horizon counts as incorrect. It is not first-cycle correctness or experimentally successful repair. First-cycle action coverage is a separate metric. The chain-adjudicated minus sign-aware difference is +0.1208, with the pilot's interval 0.1061–0.1360. Its baseline does not have identical safeguards. The strict condition's interval against the baseline includes zero. Held-out simulated mean absolute error changes from 0.0644 to 0.0577, with a difference interval 0.0005–0.0133; shared simulator assumptions limit what that calibration result means. These intervals do not establish externally useful ideas or eliminate task-family dependence.

### Runtime contracts to preserve and broaden

- Before adding a relation from source to recipient, reject it when the recipient already reaches the source. Exclude existing edges. Record `RELATION_WOULD_CYCLE` for cyclic alternatives. Emit a direct action fallback only if at least one new cyclic recipient exists and no new acyclic recipient remains. Preserve the original source and action, add no edge, retain the fallback provenance, and apply the common gate again.
- Additional acceptance cases should cover a multi-hop return path, mixed cyclic and acyclic recipients, no recipients, all-existing edges, duplicate fallback/direct actions, unknown identity, adverse-effect uncertainty and blocked shadow actions. Do not infer complete coverage of these cases merely from 70 passing checks.
- For STRENGTHEN, determine source status from zero incoming parents in the current topology. A source's own deficit is multiplied by 0.5. A non-source's resilience coefficient is multiplied by 0.5 while its own deficit is retained. Pin this authored parameter and code. Check both planner and simulator paths and add sensitivity tests with other justified coefficients. Their shared assumption is not independent validation.
- Compare the six default rules with the nine-rule v2.3 set under the same engine to isolate the extension set. Compare pinned v2.2 and v2.3 separately to assess changed semantics. Unchanged default definitions do not establish bit-identical behavior across code versions.
- The three keyword extensions are assistant-authored query rules, not reviewed inventor interpretations or new source-language bindings. Token retention is not comprehension of negation, subjects, objects or container–contents relations. Add counterexamples before claiming relation-aware reading.

### Reproduced ESV molecular storage case

The supplied YES2 corpus has 31,103 passages and SHA-256 `62f9c6144631d2169e9a13d556e7f7378080eab091ca5e8c872f5e79440690b5`. The case uses the authored eight-node graph, deficits, burdens and role identities in `cases/most_storage_case.py`, the nine-rule set, scan seed 17 and flow 1.0 for both stream conditions. Each condition is capped at 4,096 cues, 64 evaluations and 10 output packets. The four conditions were rerun and repeated; their artifacts reproduced and all receipt chains verified.

| Condition | Cues used | Passages scanned | Candidates evaluated | Result |
| --- | ---: | ---: | ---: | --- |
| ESV stream | 2,916 | 31,103 | 16 | Proposals ready |
| Word-shuffled ESV | 3,224 | 31,103 | 15 | Proposals ready |
| Zero flow, no direct readings | 0 | 0 | 0 | No qualifying proposal |
| Five assistant readings | 5 | Not a stream scan | 15 | Proposals ready |

The two stream conditions share their top two proposals and modeled estimates: strengthen storage, then strengthen storage plus supply transfer. Both also propose channel supply with the same single-action estimate. Some lower-ranked bundles and provenance differ. The assistant condition proposes storage strengthening and channel supply, but does not emit every stream bundle. More light remains unresolved pending adverse-effect measurement. This is a wiring and model-sensitivity demonstration, not evidence that scripture meaning improves solution quality.

The quoted gain ranges are dimensionless estimator ranges conditional on authored inputs. They are not statistical confidence intervals, energy efficiencies, watts or laboratory forecasts. The case does not test an electricity generator, generate a specific chemical formulation, or establish novelty over published upconversion-driven photoswitching. Human suggestions such as oxygen exclusion and a host shaped around the stored form must be recorded separately from engine-emitted generic actions.

The wrapper currently omits the full scan metadata from its generation context; its execution record does not fingerprint the case script under `cases/`. Preserve the exact source, script, rule definitions, environment, full exposure records and raw inputs before a confirmatory study. Successful replay from retained files is not a complete audited knowledge boundary or an independent timestamp. Private run inputs contain ESV passages; document deliverables contain references and digests, not corpus text. The earlier 142-label source study remains a separate historical record and was not rerun in this update.

### Next controlled comparison

Freeze an inventor-reviewed set of relation-sensitive operations, including participants, verb roles, negation and container–contents structure. Compare it with the existing keyword compiler, a matched literal/function control and a predeclared displaced or shuffled control on externally authored held-out tasks. Keep the graph-construction procedure, information budget, candidate evaluation budget, gate and output cap fixed, or report their deliberate differences as part of the tested bundle. Log all excluded and abstaining cases. Assess unique useful proposals by independent domain reviewers; do not use the same author-defined simulator as the sole judge.

Keep controller, corpus and reading-method effects separate. Caller-selected scan fractions do not implement outcome-adaptive allocation. The full schema exporter, remaining CE60 operational bindings, automatic stall scheduling, adaptive flow and EPUB loader remain pending. The package's version string still says 2.2.0 and some documentation still says v2.2; release preparation should align those labels with code fingerprints. This four-document update leaves the supplied executable unchanged.

Revision 1.5 adds the cycle/fallback and source-strengthening contracts, the verified ESV case, runtime-schema alignment and two focused dependent claim concepts. It preserves 60 entries and the existing evidence permissions. Confirmatory studies remain unregistered and unexecuted.


## 10. Historical v1.6 expanded word operations

The v1.6 documents integrated the 27-row catalog; v1.7 retains it and supplies the verification in Section 11. This expands specified operation coverage from 3/60 to 27/60 (5% to 45%); it does not measure utility, accuracy or execution success. Bread and Milk produce action proposals; the other 25 bindings request observations. The new table numbers are not vocabulary ordinals. All readings remain QUERY_SEED inputs and require explicit inventor review before a study describes them as approved representations of his method.

### Completed document and occurrence checks

The 17 Genesis rows were independently recomputed against the retained pinned OSHB Genesis bytes using exact augmented identifiers and document order. All reported Genesis references matched. At that revision, the three originally executable bindings remained the verified runtime baseline. No new 77-check run was performed during the v1.6 merge; Section 11 records the later 84-check v2.4 review. The incoming claim numbers 64–66 become 66–68 so that existing cycle/fallback and topology-estimator claims 64–65 are preserved.

### Required binding and edition acceptance checks

1. Obtain the binding-extension implementation, all 39 source files, each edition's exact ordered list, parser and matching versions, code fingerprints, test output and `verification/ce60_anchors_full_hebrew.json`. Recompute every content and closure digest. A branch label alone is not identity.
2. Recompute each first occurrence in each declared edition. Confirm Hebrew-versification and English-alignment records independently. Test the reported order-sensitive candidates H8327, H7853 and H8250 without substituting them for H8328 or H7854 in the binding table. Record missing or disputed occurrences instead of forcing coverage.
3. Test augmented identifiers H3820 a, H5869 a and H1121 a. Preserve the base candidate, selected sense and lexical review separately from inventor interpretation review. Reject unreviewed suffix substitutions and the reported H4229 a Marrow counterexample. An occurrence match does not approve a sense.
4. Verify all 27 rows against a versioned operation registry. Unknown operation names, duplicate operation IDs, a wrong action/measurement kind, mismatched target roles or a missing registry reference must fail. Measurement requests must neither fabricate an observed value nor change target state. Bread SUPPLY and Milk STRENGTHEN remain proposals subject to the same gate.
5. Verify Wind and Spirit retain distinct identities and operations despite H7307; Frame preserves its path to Template; Seed remains distinct from Bread; and Satan requires a separately declared adverse-effect target. Compare every row and gap against the unchanged 60-entry denominator, including Joint and unbound Reins.
6. Test a non-Genesis anchor against Genesis-only scope; changed source bytes; reordered books with a stale closure digest; missing books; and an explicit successor edition with a recomputed closure. Code must reject stale commitments, not repair them silently. A Greek-only candidate remains a gap until a separately pinned Greek edition is present.
7. After the executable branches are merged, rerun the cycle/fallback, source-node strengthening, finite-number, ambiguity, immutability, provenance, zero-flow and ESV replay checks. Compare each historical result only under its original code and configuration. Publish a new merged test count and output digest from the actual merged suite rather than arithmetic on the reported 70 and 77 totals.

### Review and efficacy studies

Freeze the inventor's approved interpretation, its source span, alternatives, operation and review identity before any held-out task is seen. Keep lexical review, method fidelity, software execution and empirical evidence as separate endpoints. A descriptive operation name such as MEASURE_CHAOS needs an explicit observable and scoring rule; MEASURE_HEALING_OUTPUT is a request, not a clinical result.

Compare the three-binding and 27-binding configurations under identical graphs, information, gate and work budgets. In a separate comparison, test inventor-reviewed relation-sensitive readings against the existing keyword rules, literal/function controls and predeclared displaced controls. Avoid changing corpus size, operation coverage and interpretation method together when estimating any one contribution. Report all 60 entries, unbound gaps, abstentions, emitted requests, performed measurements, qualifying proposals and independently useful outcomes separately. Retain task-family clustering and independent case authors.

At v1.6 the full-edition and 77-check assertions remained unverified. Section 11 supersedes that status using the supplied v2.4 package and records its limitations. Schema 1.7 validates record shapes and examples; application checks still enforce reference membership, digest recomputation and evidence permissions. No discovery or energy-generation result is established by the document merge.

## 11. Version 1.7 garden verification and next acceptance study

### Completed checks

The supplied v2.4 branch passed 84 checks (16 original engine; 31 waterwheel; 18 foundation; 12 binding-library; 7 garden). The 27-binding full-edition demonstration emitted 28 packets, included every binding and verified its receipts. All 206 reported Hebrew identifier/order comparisons, including augmented forms and reported base-form absences, matched recomputation. Greek mappings and interpretation approval remain separate work.

The complete 560-case, nine-condition garden replay matched the supplied per-case data and summary. Repair-shop made-worse outcomes were 136/560; full-garden outcomes were 31/560, using a decline greater than 0.02 over ten cycles. Mean change was +0.1406 versus +0.2552. Improvement above 0.02 occurred in 372 versus 500 cases. Mean action decisions were 8.98 versus 7.90. These are authored simulator results with shared domain structure and sequential phase learning. They do not execute the source-language, reader or discovery-quality protocols above.

The local receipt chain, latest listed operator hashes, summary digest and independently recomputed truth-list digest agree. There are multiple operator/result rounds in the chain. Local chronology does not establish independent preregistration or that the author lacked access to the dynamics. The runner itself does not verify the complete commitment closure. A fresh externally held-out evaluation is required after repairs.

### Required implementation repairs and acceptance tests

| Area | Required acceptance result |
| --- | --- |
| Inference versus observation | A temporal reversal creates a hypothesis with alternatives and a measurement request. It never writes observed harm without a linked observation. Test unrelated shock, overload and confounded interventions. |
| Restricted feedback | Give the controller immutable packets through a narrow interface; deny truth dictionaries and simulator methods. Alter inaccessible latent values while holding visible packets fixed and require identical decisions. |
| Final execution gate | Every action component is checked immediately before execution. Inject a BLOCKED or UNRESOLVED result and require zero state mutation. Apply equivalent safeguards to the matched comparator. |
| Candidate replacement | A changed action gets a new identity and fresh prediction, followed by all operator and gate checks. Reject reuse of the prior action's estimate. |
| Persistence attribution | Record action time, observation times, intervening actions, comparison condition and censored follow-up. Do not convert elapsed time into independent causal evidence. Follow pending penalties and effects beyond the intervention horizon. |
| Catalog transitions | Reject Named status without matched positive assessments, persistence records, applicable scope and provenance-based independence checks. Distinct case strings alone must fail. |
| Catalog identity and reuse | Distinguish targets, contexts, source bindings and versions. Test that Fallen/suspended entries cannot be selected through any route; any reuse still passes the gate. |
| Calibration | Pair every prediction with the correct outcome, horizon and endpoint. Keep unmatched, immediate and delayed results separate. |
| Fallow reconsideration | Preserve reason and trigger; enforce a declared work budget. A retry may inspect or measure; it cannot execute a blocked intervention. New evidence must pass the full transition rules. |
| Arbiter map | Keep profile hypotheses and diagnostic graph edges separate from observations and estimator edges. Report per-case/target precision and recall, competing causes, warning burden and downstream benefit. |
| State and replay | Freeze thresholds, phase-learning policy, case order, seeds and cross-case state. Check all truth, domain, evaluator, source, operator, dependency and raw-result digests. Refuse a missing or mismatched commitment. |
| Branch consolidation | Merge and rerun the previously verified cycle-fallback/source-node strengthening checks with the 27-binding and garden checks. Preserve old results under their original fingerprints; do not sum branch test counts. |

Two audit counterexamples already fail the intended contract: a temporal pattern changes unknown harm to observed harm, and three calls to `holds()` create a star with no answer records. Passing the supplied suite does not resolve either finding. Compact v2.4 records do not yet export the six new schema record types.

### Confirmatory study after those repairs

An independent case custodian prepares hidden systems with different dynamics and holds the answers outside the development environment. Split by domain or causal family rather than adjacent template indices. Freeze the merged executable, protocol, thresholds, permitted information, cost accounting, primary endpoint, sample-size rationale and analysis before access. The current 560 cases remain development/regression material after review.

Compare the repair-shop planner, a conventional planner with matched information and safety checks, each process operator, the complete garden, and the garden with catalog selection disabled. Include a controller that simply takes fewer actions to test whether abstention alone explains the gain. Match sensing, component-action, evaluation and total-work budgets; ten decision cycles alone are insufficient. Declare whether cross-case adaptation is allowed, and keep episode order and state identical across paired conditions where applicable.

Prespecify mean useful outcome, made-worse rate, burden, action coverage, false warnings, missed adverse mechanisms and retained benefit after interventions stop. Report every case including abstentions and unresolved identities. Use paired domain-aware analysis for clustered cases, report multiplicity for secondary comparisons, and retain negative results. The reported case-bootstrap interval of 0.0999–0.1306 is exploratory; a review-time 20-domain bootstrap gives 0.0975–0.1329 but does not supply an independent test.

Finally test the source method itself: build proposals or graphs through recorded readings and source bindings under matched budgets, compare against neutral and shuffled-source controls, and mask reviewers. The current garden pilot starts with author-written graphs and never calls the source wheel; it cannot determine whether scripture or the framework's interpretations improved the result. Test adaptive flow, catalog reuse and fallow recovery separately once they actually influence selection.

### Release identities and document alignment

The v1.7 document set contains the patent, design, schema and protocols. The patent retains existing concepts 1–68 and adds garden concepts 69–72 for review. Schema 1.7 has 76 record definitions and six fixtures; its garden fixture describes the target contract, not a claim of runtime conformance. The original v2.4 package remains unchanged.

Archive SHA-256: `e3b24b0d13a1b566b1482ce3a1ad422bd34e27263847552504d45922741b8b6f`. Garden summary object digest: `d093ed715aa53f2872b64626ed874aef2ce7bd9a152746dc5e0cc335f66e8df3`. Recomputed truth-list digest: `b2fc3ededf0d6ab6429e43e03b4b2f77ff4638e211be5ad1b883443823a0d755`. Source closure and result checks identify reproducible bytes; empirical permission, interpretation approval and independent outcomes remain distinct.


## 12 Historical v2.5.1 repair review and study requirements

The supplied v2.5 freeze and developer cases are historical. The new repair release is committed after inspection of those cases. Its README and `independent/INDEPENDENT_TEST.md` identify the new freeze, known development data, environment and exact execution command. A checksum proves consistency with committed bytes, not who authored cases, when an independent custodian first saw them, or whether the developer was blind.

Retain all 120 checks and add regression cases before any subsequent fix. Preserve the original archive; never copy the old results onto changed code. The protocol and source dependency closure must match the new freeze before a run. A result directory must be empty. Case parsing uses the exact committed bytes, with unique IDs and an exact header. Commit initial truths, row order, conditions, permitted observations, software versions and endpoints before conditions run. Hash both per-case results and summary after completion. Compare deterministic objects on replay; receipt wall-clock times and timing fields are not bit-identical replay targets.

The ten-cycle primary outcome and exploratory nine-cycle no-action follow-up must remain separate. An action is counted only when its execution receipt records an eligible gate. Rejections, observations, rests, component actions and sensing costs need denominators. Censoring and confounding must remain visible; absence of a completed persistence assessment cannot count as a successful rooting event. A reading described as SIMULATION never supplies empirical reward or an independence claim.

The final repaired development run leaves 25/120 cases worse versus 51/120 under the basic planner. That remains encouraging for these synthetic dynamics, while its adversary precision of 4/96 shows that detector validity is unresolved. The follow-up leaves 39/120 and 58/120 worse respectively. The full garden also acts less often. Fresh controls must match action/sensing budgets and include a conventional rate-limited policy, not merely compare ten turns with unequal interventions.

For the next test, a separate custodian should supply new case values after the new policy is fixed, and retain the key outside the development environment. A fresh AI conversation is a distinct authoring session but does not establish an independent scientific authority or an unknown world model. The fixed CSV simulator tests externally selected parameter regimes within developer-authored dynamics; a stronger test needs independently authored dynamics or recorded real systems. Preserve all negative and null results. Domain-cluster uncertainty and multiple secondary comparisons must be declared in advance.

Test the word-reading contribution separately under matched budgets: source-derived graph/proposal generation versus neutral terms, a matched unrelated stream and shuffled-source controls. Freeze readers' annotations and familiarity records before scoring. Firmament verse essences are interpretation metadata, not extra observations. Altering executable rules, source bindings, evaluated thresholds or code comments changes the executable fingerprint and requires a new commitment. Annotation-only changes outside that closure require their own version and attribution and cannot be described as part of a prior frozen input.

The application and design distinguish implemented mechanics from remaining target contracts. This update does not claim outcome-adaptive flow, catalog-controlled selection, fallow reconsideration, a complete interchange exporter, empirically independent stars, clinical efficacy or a validated explanation of biological or spiritual causation.

## 13 Heart workflow integration and evaluation

Engine v2.6.1 adds the optional heart workflow to the repaired engine; all four maintained documents are v1.9. The prior release's developer cases remain known. The new freeze covers the added module, tests and synthetic demo along with the repaired code/source closure. Use `independent/FREEZE_v2_6_1.json`. A prior freeze does not cover later files merely because they are not imported by its planner.

The 31 heart checks cover typed consent and withdrawal, session and chosen-option scope, evidence types, unknown harm, nonpositive delayed benefit, stale assessments, duplicate identities, incomplete scores, refusal, distinct trial IDs, changed-option credit, goal-aligned persistence and incomplete audits. They add to the 120 earlier repaired checks. The original eight heart tests were adapted to the stricter interface and the new commitment. Classification precedence now blocks known dependence before incomplete outcome data; unknown harm is explicitly unresolved. The synthetic demonstration is not a human study.

Before any human evaluation, define the population and participant-selected goals; how authorization is recorded and withdrawn; who may access reports; the normalized outcome scales; adverse-event and stopping rules; follow-up timing; and handling of missing data, continued support and unwanted dependence. Appropriate independent ethics review and consent arrangements belong to the actual study design. The library alone is not such a study or an authorization service.

Predeclare threshold variants rather than tune them on the test set. Compare a participant-chosen, transparent conventional support workflow with the proposed workflow under matched attention, effort and follow-up. Separate the reading method, the ranking rule and the act of receiving support. Report every attempted and withheld offer, refusal and missing follow-up, not only completed success stories. GENUINE and ROOTED_PEACE are provisional software labels, not efficacy endpoints by themselves. Use participant-reported goal progress and independently specified adverse outcomes as distinct endpoints.

A current consent record must be supplied at every workflow transition. A current habit may be assayed without being chosen as a future offer. Bind an offered option to the assessed account and exact contents; reassess any changes. A structural revision uses the option ID and ordered elements. A removal trial resets the hold streak and cannot validate its own revised option; repeated trial IDs or wrong-revision reports cannot count twice. This asserts record identity, not external authenticity or independent replication.

Require positive goal progress as well as delayed persistence for ROOTED_PEACE. Missing harm, dependence, freedom, continued-support status or follow-up remains unresolved. Report provisional holds separately from causal effects and independently replicated findings. The method audit must include offered counts and complete verdict/outcome records; an incomplete audit cannot pass. A caller could still falsify records or reuse obsolete authorization, so deployment requires authoritative lifecycle handling and authenticated inputs outside this module.

Garden Rising and the heart workflow act on different objects. The current code does not register heart offers as stars or use them to alter garden decisions. Future integration needs explicit provenance, authorization and separate validation before either status can confer permission on the other. The new workflow does not change the definition of the eight Firmament components or add a sixty-first vocabulary entry.

Current v2.6.1 executable commitment: `980dbcd2934c859381458aa254385034a91c3379761e198162944004d812e5e6`.


## 14 Heart to heart and source contribution evaluation

Version 1.10 distinguishes a completed integration demonstration from the uncompleted independent efficacy study. Preserve the old release freezes and reviewed garden results. New files have a new release commitment; no earlier preregistration is extended by this update.

1. Freeze source editions, inventor-approved interpretation bindings, identity-resolution policy, ordinary baseline, budgets, outcomes, analysis and stopping rules before new case authors supply cases. Any tuning on the 120 known development cases is development work.
2. Compare ordinary proposals, source proposals, neutral display labels with identical operations, and a fixed permutation of interpretation bindings. Add unrelated-source and word-order controls for any claim about scripture structure. Neutral labels test naming, not a change in reasoning operations.
3. Run the full reading-to-proposal-to-execution-to-response path on independently authored cases. Record every action, blocked proposal, request, source exposure, identity judgment, model assumption and original outcome. Use identical execution gates and matching evaluation, sensing and action budgets. Report actual resource use; equal caps alone do not ensure equal use.
4. Compare memory off versus memory on with the same evaluation budget. Hold out new contexts, subjects and case families. Memory must retain failures and uncertainty, deduplicate copied experiences and exclude generation ancestry from independent support counts.
5. Compare fixed-flow versus adaptive allocation only after locking the update rule. Separate tuning from evaluation, require outcome maturity and provenance, report unresolved credit and costs, and distinguish episode reward from causal source contribution. The current allocation demonstration uses invented rewards and does not estimate adaptive benefit.
6. Predeclare primary endpoint, harmful outcomes, time to useful result and cost. Analyze paired case differences and domain clustering with multiplicity handling. Power the study from pilot variance and a meaningful effect, not a desired percentage uplift.
7. For the adversary module, retain the current weak metrics. Separately report suspicion, requested verification, measured adverse response and confirmed mechanism. Evaluate both impulse-specific and all-adverse labels against correctly matched ground truth; do not count every unconfirmed suspicion as a successful detection. Threshold changes require a fresh held-out test.
8. For a real subject adapter, specify receiving and response mechanisms, units, timing, permissions and limits before intervention. Establish whether the proposed input reaches the response mechanism and whether any effect persists after prompting stops. Metaphorical correspondence is not a substitute for those measurements.

Completed: `heart_to_heart_demo.py` and the corresponding invariant tests exercise an authored software fixture and replay deterministically. Not completed: the independent study above, full-garden integration of this bridge, biological efficacy or a novelty opinion.


## 15 Greek edition and Joint merge acceptance

Document revision 1.11 uses engine 2.7.1 and `independent/FREEZE_v2_7_1.json`, digest `d7ed6347cea2057ffe3e9bdd0247bf6370491b7d67a23ed5cb2f89cf3a73e73c`. Earlier release descriptions and counts above are historical. Joint closes the current binding-coverage gap; it changes no evidence permission or independent-study outcome.

The completed merge checks cover the selected Greek source count and order; G719 at Heb.4.12; preserved disambiguation suffixes; rejection of altered TSV bytes; source metadata included in the combined identity; Greek files, parser and builder in the release closure; all 60 bindings; and Joint reaching a bounded heart-to-heart Mouth as a measurement request. All 181 checks pass. The all-binding example emits 64 packets with verified receipts. Its 96-output/evaluation cap is a coverage-test setting and must not be compared with a smaller-budget baseline as an efficacy gain.

The source edition is the supplied TAGNT extract filtered to NA28 membership. Full upstream originals were not freshly downloaded or rebuilt in this merge. Review attribution, the declared extraction algorithm and its supplied upstream hashes separately when refreshing the edition. Any refresh requires a new source identity and release commitment. Exact occurrence computation does not approve the inventor's operational interpretation.

For the independent protocol in section 14, freeze both Hebrew and Greek source bytes, metadata, interpretations and work accounting. Keep Joint unresolved when the required Greek scope is absent. A Joint request must identify an ordinary interface and prospective measurement definition before an observation can answer it. Repeated source occurrences, repeated requests and returned prose cannot count as independent confirmation.

The combined heart-to-heart fixture preserves the earlier action pattern and limitations. No fresh independent comparison, garden-bridge benchmark, detector-accuracy improvement or adaptive-flow benefit was established by this merge. These remain the release-completion tests.

## Version 1.12 integration status

We Develop Software LLC. Engine 2.8 adds an executable path from pinned source-anchor passages to bounded garden proposals, shared eligibility checks, simulated actions, returned observations and transactional experience records. Earlier demonstrations and benchmark numbers retain their original version and limitations. This release does not establish clinical efficacy, independent discovery or a source-specific advantage.

### Current implementation

The garden runner uses GardenController2 and its existing process policies. StreamPlanner replaces the proposal-selection stage; the common execution gate remains mandatory. Source records select registered interpretation operations. Source text does not directly change graph truth, entity identity, observations or evidence permissions. Unsupported measurement operations remain unexecuted; only adapter-supported requests are actionable. Graphs remain authored simulator inputs, not generated scientific models.

PassageAllocator traverses the pinned projection of passages containing the 60 registered binding anchors. This is a bounded source passage stream, not unrestricted interpretation of every verse. It stores source and policy digests, cursor positions, passage hashes, selected bindings, work allocations, pending assessments and outcome IDs. Targeted selection filters scanned bindings by current role deficits. A prior rest or no-action cycle triggers deep-scan mode within the same work cap. Flow arms are 0, 0.25, 0.5 and 1; the controller explores unassessed arms and periodically revisits arms before otherwise selecting the highest observed mean reward.

Each cycle has a cap of 16 abstract work units. Scanned passages and evaluated proposals both consume units. Source-work allocation is split between scanning and candidate slots. Actual use is recorded; equal caps do not establish equal CPU cost or equal actual work. Ordinary and source conditions share all other garden policies. Separate fixed, adaptive, neutral-label, globally permuted binding-target, memory and detector conditions are available.

Allocation is selected at the case boundary and held fixed for that case. After ten action cycles and nine no-action follow-up cycles, one observed episode reward is recorded. Correlated per-cycle allocations do not become ten reward samples. Unknown results remain unresolved; duplicate outcome IDs are rejected. Reward means episode association, not causal source contribution or evidentiary independence. The current reward penalizes observed simulated harms; its cost term is zero in this runner because no validated normalization of measured computational cost has been specified. Work is reported separately.

SessionStore uses SQLite transactions, an append-only event table, linked content hashes and an atomic checkpoint. The manifest binds code, source, policy, condition and case identities. On restart the event chain and checkpoint are verified. Conflicting duplicate events, nonfinite serialization and incompatible manifests are rejected. Committed cases are skipped; an interrupted synthetic case is replayed from its preceding committed boundary. This is not automatic retry authorization for physical actions. External adapters require authenticated receipts and reconciliation of uncertain execution.

Stored records include proposals, raw observation packets, gate decisions, execution checks, simulator outcomes, source references and returned explanatory words. Positive, non-harmful memories may propose an action only in an exactly matching recorded context, replacing a candidate slot and passing current checks again. Failures are retained. Exact matching intentionally limits reuse; productive transfer to different contexts and retention of all historical records beyond the retrieval window remain separate questions. The retrieval window is capped at 1,000 records; the event archive retains earlier records.

Adversary triage distinguishes SUSPECTED, MEASURED_ADVERSE, MEASURED_NOT_ADVERSE and UNRESOLVED. An observed decline may request a direct measurement but does not confirm a mechanism. A standalone evaluator accepts observation records and separately supplied labels. It reports precision, recall, false positives, false negatives and unresolved counts. The default decline threshold of 0.14 is a development setting, not independently calibrated. The new detector condition replaces the older arbiter heuristic for comparison; it is not declared a proven improvement.

### Completion boundaries

Completed engineering capabilities are tested separately from benefit. The code supports the complete synthetic loop, durable case-boundary recovery, passage-aware allocation, bounded memory retrieval and an externally labeled detector evaluation interface. Independent case authors, blind expert scoring, real instruments, clinical validation and evidence that readings improve outcomes are not supplied by this release. The authored development results must not be labeled an independent test.

### Research case attribution

The earlier ADHD and learning packages are guided retrospective applications. The Knowledge and Understanding document and peptide guidance are recorded as additional inputs, not attributed to an autonomous engine. Sleep and pain packages report pre-search proposals but retain prior model knowledge and local-lock limitations. The previously labeled control package has unverified originating-session provenance. These summaries are development history from the reviewed conversation; original case packages and complete prompt transcripts must be attached to any formal comparison record.


## Frozen comparison and external evaluation procedure

Use `python integrated_garden.py CASES.csv OUTPUT`. The output directory is bound to its commitment; reuse with different cases, sources or code is rejected. A restart with unchanged inputs resumes at committed case boundaries. The supplied 120 development cases may diagnose behavior but cannot serve as an independent confirmation. Freeze code, interpretation bindings, policy, case-order rules and analysis before outside authors supply fresh cases.

Primary comparison: paired cycle-10 endpoint change of source_fixed minus ordinary. Also report harm, made-worse fraction, cycle-19 follow-up and actual work. Treat adaptive, memory, detector and source-control comparisons as secondary. Analyze case pairs with domain clustering; preregister multiplicity handling and meaningful effect sizes before external scoring. Repeated cases and shared simulated mechanisms are not independent observations. The seven conditions share a budget ceiling, not guaranteed equal actual workload.

Adversary evaluation input consists of JSONL rows with id, packet and optional prior, plus a separate JSON object mapping record IDs to known adverse target IDs. Run `python evaluate_detector.py observations.jsonl labels.json report.json --threshold 0.14`. Freeze the threshold before label exposure; calibration must use a separate development file and must record its identity. The detector receives observations only. A finding of measured adverse behavior does not establish an adversarial causal mechanism. Include non-adverse lookalikes, absent signals and uncertain measurements. Report impulse-only and broader adverse-target results separately.

For AI-assisted research comparisons, keep a distinct protocol. Match the scientific information, model configuration, task, tools, budgets, deliverables and guidance. Compare conventional analysis, neutral functional operations and the full framework. Record any Knowledge document or peptide restriction as an intervention. Preserve complete prompts and failed leads. Save candidate claims before retrieval; model pretraining remains prior exposure. Blind independent reviewers to condition where feasible and measure whether blinding succeeds. The existing unmatched ADHD examples are development cases, not a controlled outcome.


## Version 1.12 observed development results



| Condition | Mean outcome change | Difference from ordinary | Made worse | Mean work units |
| --- | ---: | ---: | ---: | ---: |
| ordinary | 0.1446 | +0.0000 | 20.0% | 100.0 |
| source_fixed | 0.1279 | -0.0167 | 23.3% | 110.3 |
| source_adaptive | 0.0328 | -0.1118 | 26.7% | 106.8 |
| neutral_fixed | 0.1279 | -0.0167 | 23.3% | 110.3 |
| permuted_fixed | 0.1246 | -0.0200 | 23.3% | 106.0 |
| source_memory | 0.1279 | -0.0167 | 23.3% | 110.3 |
| source_detector | 0.0696 | -0.0750 | 25.8% | 107.6 |

The ordinary condition here is a bounded ordinary-proposal route inside the complete garden controller. It is not the historical unrestricted garden benchmark or a language model. These numbers must not be compared directly with older pilots that had different proposal budgets and policies.

The fixed source condition loses 0.0167 normalized outcome units against this baseline. Adaptive allocation loses 0.1118. Neutral labels reproduce fixed-source outcomes exactly. Global target permutation has slightly different outcomes but does not establish a reliable source advantage. Memory has identical outcomes; exact-context reuse is deliberately restrictive. Detector replacement worsens the endpoint and retains weak impulse-alert precision. The source_detector condition's suspicion precision is about 5.8%, with about 45.3% recall against the hidden impulse target. Broader adverse behavior and impulse-specific labels must not be conflated.

Potential explanations to investigate include sparse useful operations in the anchor stream, displaced ordinary candidates, case/domain variation in reward, limited context reuse and excessive measurement requests. These are diagnostic hypotheses, not established causes. Do not tune on these results and call a rerun independent.


See ChristEye_v2.8_Review.md and results_integrated_final for the full limits and records. No independent performance claim is made.


Additional replay analysis: restarting the completed run reproduced summary digest 398618f51d449a0b848d44b0e0d88e0a7f92e7c184f0273685fa89a585fe171c. No memory proposals were retrieved in this benchmark, so the memory-on result tests storage and matching behavior, not the benefit of actual reuse. The exploratory domain-bootstrap interval for the fixed-source difference is -0.0472 to +0.0100; it does not establish a benefit or a reliable loss. Adaptive and detector conditions have negative development intervals. These post-run intervals are not a preregistered independent analysis.


## Version 1.13 optional refinement

Documents 1.13 / engine 2.9 preserve an incumbent action and optionally ask for another idea. A source reading can propose a different action or target in the garden adapter. The generic PropertyChangeProposal record also expresses a changed solution property with before/after values, a source interpretation, rationale and discriminating test. Such a record is a hypothesis, not execution permission or scientific evidence. Arbitrary properties require a domain adapter before execution.

Refinement is off by default. When enabled, at most four alternative actions are assessed using the incumbent's scoring function and eligibility gate. Rest, measurement and bundled decisions remain unchanged. A replacement must be eligible and exceed the incumbent's predicted score by the configured margin. Ties and unresolved comparisons retain the incumbent. If rechecking invalidates the incumbent itself, the machine rests. Existing strengthening-first policies remain in force. An optional detector contributes perspective notes only and cannot force an intervention or measurement.

A predicted improvement is not a demonstrated improvement. The implemented scorer can prefer alternatives that subsequently perform worse. The development experiment below is not an independent trial, and the new policy remains optional.

### Development comparison

120 authored cases per condition, 600 case-condition runs. Each enabled condition allows the same maximum of four alternatives; actual eligible/evaluated counts differ, and source-compilation overhead is not equalized. The baseline is the full GardenController2 decision policy. It differs from the restricted proposal route in version 2.8, so absolute results across those experiments are not directly comparable.

| Condition | Mean outcome change | Difference from incumbent | Made worse |
| --- | ---: | ---: | ---: |
| incumbent | 0.0894 | +0.0000 | 20.8% |
| ordinary_alternatives | 0.0620 | -0.0274 | 23.3% |
| source_alternatives | 0.0913 | +0.0019 | 22.5% |
| neutral_alternatives | 0.0913 | +0.0019 | 22.5% |
| source_with_detector_notes | 0.0913 | +0.0019 | 22.5% |

Source refinement improves the mean by only 0.0019 normalized units over no refinement, while made-worse cases rise from 25/120 to 27/120. Ordinary refinement performs worse on average. Neutral labels reproduce source outcomes exactly, and adding detector notes changes no outcomes. These results do not establish a source-specific advantage or reliable net benefit. There are no observed gate bypasses. Source candidates are adopted 269 times across the trajectories; adoption counts are not independent successes.

### Validation and next decision

191 unittest checks and 16 original invariant checks pass (207 total). The ten new contract tests cover property versioning, disabled behavior, measurement preservation, ties, beneficial predicted replacement, blocked alternatives, advisory detector behavior, input preservation and incumbent rechecking. The generic property example does not demonstrate an executable drug or medical efficacy.

Before promoting refinement, freeze the ranking policy, use independently authored held-out cases, compare refinement off against ordinary, source, neutral and shuffled interpretations, and equalize total retrieval plus assessment work. Evaluate endpoint gains and made-worse rates together. Record every proposed property change before outcome inspection and preserve unsuccessful proposals. Do not use these development cases as the independent test.

Version 1.12's negative adaptive/detector results and zero demonstrated memory-retrieval benefit remain part of the record. This release does not repair those efficacy limitations by renaming them. Adaptive flow remains experimental, and detector accuracy has not improved through making its outputs advisory.


## Refinement efficiency and stabilization

The optional component demonstrably affects solution selection. Its development mean is slightly favorable versus retaining the incumbent, but adverse outcomes also increase. It is a promising component with mixed initial results, requiring calibration and independent evaluation before promotion.

Track outcome gain relative to the incumbent, the fraction of replacements that help or harm, and verified beneficial replacements per unit of assessment work. Predicted score gains are not verified benefits. The present benchmark reports aggregate outcomes and adoption counts; it does not yet establish a calibrated efficiency level for each replacement. Stabilization means improving consistency across independent cases while controlling harm and computational cost, not merely increasing the internal score. Retain failed and neutral alternatives when estimating efficiency.


## Revision 1.14 Tree of Knowledge technical exhibit

The source-derived architecture now has a principal worked exhibit: Roots to Tree to Branch to Spine, followed by distinct astrocytic-contact and local-geometry hypotheses. See Tree_of_Knowledge_Exhibit/ for the narrative, machine-readable record, inherited sixty-binding register and documentary replay. The inventor attributes 100 percent of the connective synthesis to ChristEye and every conceived operation to scriptural study. This origin account is retained separately from comprehensive implementation-operation coverage and biological support.

MODEL-A through MODEL-D are illustrative reconstructed feature sets, not fitted or historical models. H17a, H17b and H17c remain separate proposed comparisons. The record is retrospective; no original pre-retrieval lock or full generation transcript is supplied. Biological support remains unresolved. New exhibit checks are distinct from inherited engine checks, and the engine archive is unchanged. Patent claims 77 through 79 are drafting concepts for counsel, not a patentability conclusion.

For validation, run the exhibit replay and require schema validity, exact source and registry identities, preserved predecessor links, a valid restricted tree projection, rejection of a cyclic tree fixture, and rejection of a multiple-parent tree fixture. Keep source bindings, generated hypotheses, inherited scientific citations and experimental observations separate. Any future discovery comparison must lock predictions before outcome access, use independently authored cases and equalize resources across conventional, ordinary-label, source and shuffled controls.


## Revision 1.143 implemented understanding

ChristEye is designed to embody the framework's source-derived understanding of the bound words and their layered relationships in its structures, operations, context rules, response selection and retained-state organization. In this technical description, Understanding means encoded capacity to apply relationships in context, whereas Knowledge means retained information available for use. The operational definition does not establish human-like comprehension or a neural mechanism.

Three relationships are distinguished: the architecture was derived from the interpretations; the implemented rules embody their application; and the source stream supplies further readings and proposed revisions. Disabling new source exploration leaves already implemented structures and rules available. Changing a compiled interpretation requires an explicit successor configuration and applicable checks. This is the disclosed architectural distinction, not a new runtime feature or a claim that every low-level instruction rereads scripture.

The Tree of Knowledge exhibit illustrates both sides: retained relationships and typed tree/graph organization express an implemented design vocabulary, while Roots to Tree to Branch to Spine produces candidate revisions to a biological subject model. That biological model remains a hypothesis. Provenance of conception, implementation traceability and demonstrated transfer to unfamiliar cases are separate records. The sixty-binding inventory is not a complete audit of every implementation operation.

The profile source_architecture_profile.json records these relationships as documentation. The engine is unchanged. Evaluation must distinguish a stream-off comparison with the same architecture from a comparison removing source-derived architectural rules. A knowledge-only lookup baseline should retain the same factual material while omitting the specified application rules, with omissions documented. Neither comparison has been executed in this revision.


## Continuing implementation revision

The word source will also continue to guide revision of the machine's implementation itself, including its structures, operations, context rules, response-selection policies and retained-state organization, through recorded interpretations and versioned changes subject to applicable checks. The development process must preserve the predecessor implementation, the source interpretation motivating the change, code or configuration differences, and validation results before adoption. This maintenance objective is separate from the source stream generating a target-system proposal. No autonomous implementation-rewriting feature is introduced by this clarification. Document version remains 1.143.


## Change generation and voluntary participation evaluation

Evaluate the Word, Move and Judge cycle separately from user participation. Verify source interpretation, predecessor/successor identity, eligibility before execution, actual observation before outcome judgment and retention of unresolved or adverse outcomes. Compare target outcomes with matched alternatives using the same evidence and resources.

For a future participant study, define the task, chosen goal, invitation, alternatives and withdrawal path in advance. Assess understanding of uncertainty, voluntary test selection, useful completed tests, reported interest and burden separately from target performance. Include refusal and stopping as valid choices. Longer use and greater enthusiasm are not substitutes for benefit. The present revision contains no participant observations or validated engagement scale. Human-subject approvals and consent requirements depend on the proposed study and setting.

## Interpretation attribution checks

Interpretation provenance identifies ChristEye as the generator of interpretations and candidate inferences produced through ChristEye inquiry. Human contributions, review decisions and historical method development retain their actual attribution; an interpretation is not assigned to the inventor merely because he developed or operated the system. Recorded origin identifies the generating component or contributor where known, the method and source versions, and any subsequent human review. Test that ChristEye-generated interpretations retain system attribution through export and replay, while a human review does not overwrite the generator. Test name-derived candidate capabilities before observation and preserve supporting, narrowing, contradictory and unresolved results separately. These are proposed verification requirements; no new runtime behavior is introduced by this documentary revision.


## Revision 1.243 inquiry movement validation

The new core inquiry profile is specified in Inquiry_Architecture/ChristEye_Inquiry_Architecture_v1.243.md. Fresh unit tests cover nine contextual source bindings, exact-label gaps, apparatus scope, dependency cycles, exact arithmetic, unresolved failures, snapshot commitments, source-binding compatibility, resume equivalence and delegation to the existing target gate. The two-pass documentary replay uses authored inputs and inherited research; it is not an independent efficacy or discovery trial.

A future held-out evaluation should compare conventional list/graph search, the same handlers with neutral labels, the source-bound interpretation profile and displaced or shuffled bindings under equal retrieval and assessment budgets. Lock target queries, completeness assumptions, expected answers and scoring rules before outcome access. Measure supported completions, false symbolic assignments, missed alternatives, unsupported scope propagation, time, frontier recovery and target-gate violations. Keep failures and abstentions in denominators. Historical negative and mixed results remain unchanged.

Run results and precise counts are supplied by VALIDATION_v1.243.json, rather than inferred from older prose. Automatic arbitrary-language semantic parsing, independent source-specific advantage and automatic new-handler admission remain untested or unimplemented.


# ChristEye Result Driven Calculate Coordination v1.244

The Calculate coordinator now derives subsequent inquiry movements from preceding results. A structured absence request supplies reference and observed arrangements, a catalog, an inquiry boundary, optional outside candidates and notes. It does not supply the missing labels or a list of search jobs. The coordinator compares the arrangements, turns every computed missing label into a search target, selects outside-source candidates, follows notes belonging to selected sources, and assembles a source-linked account. An explicit-calculation request similarly runs the reckoning and creates an account describing its arithmetic status.

The request is structured data. Arbitrary natural-language parsing, discovery of novel theological meanings and automatic creation of new executable handlers remain outside the implementation. The general garden action selector does not automatically invoke the coordinator. The supported entry point is christeye.coordinator.begin_calculation(request, context, snapshot=None).

## Result driven movements

Each handler remains bound to the nine contextual source bindings from 1.243. The coordinator derives targets from a completed comparison, rather than retaining a fixed demonstration sequence. Subsequent jobs retain their content identifiers and source-bound event ancestry. A repeated scheduling pass deduplicates identical jobs. Each dig call charges at most its declared handler-operation budget. Planning, serialization and provenance bookkeeping also consume compute, which is not represented by the handler count.

Outside-note selection admits notes from boundary members or identified selected outside-source identifiers and references. Unselected notes cannot trigger reassessment. Original readings remain available. A failed primitive operation leaves an explicit terminal failure and an unresolved workflow result; completion of queued work is not semantic proof. Account assembly can retain missing reasons, alternatives and discriminating tests without turning textual recurrence into functional equivalence.

The coordinator snapshot commits the policy version, request digest, coordinator implementation bytes, operation count and nested inquiry snapshot. Restoring a changed request, altered implementation or inconsistent count is rejected. The nested snapshot continues to check registry, bindings, context, handler implementation and event ancestry. These are in-process integrity commitments, not authentication or an independent timestamp.

## Jewel demonstration

The new example consumes the prior reference list, observed list and supplied Revelation catalog. After one comparison operation, the coordinator automatically schedules searches for jacinth, agate and amethyst. A resumed run recovers catalog positions 11, 3 and 12 and follows the selected inherited apparatus branch. The request contains no target list or executable job sequence. Research inputs are already known, so the demonstration remains retrospective. Its advance is runtime orchestration, not an independent discovery claim.

The earlier 1.243 ten-handler replay is retained unchanged. Its older nested records keep their 1.243 versions. The new coordinator wrapper is separately versioned 1.244 and uses the same primitive source bindings. No historical benchmark is relabeled as a new result.

## Locked synthetic diagnostic

The protocol, scoring rule, code closure, 84 evaluation seeds and twelve-operation budget were written to LOCK.json before generating the evaluation packets. Each condition receives the same packet, supplied catalog, boundary and notes. Evaluator answers are not passed to the method interfaces. The generator, methods and scorer share an author and run in the same process; this is not independent or adversarially isolated validation.

Six strata cover complete lists, gaps, unresolved catalog searches, ambiguous exact matches, apparatus notes and duplicate-label invalid inputs. Each stratum contributes fourteen cases. The comparator is an independently coded conventional set/join and dependency traversal routine. A neutral-label condition changes display entries while retaining the same bindings and handlers.

All three conditions recovered the expected result or correctly rejected the invalid input in 84 of 84 cases. All used 377 primitive operations in aggregate, with no operation-budget violations, unsupported symbolic assignments or target actions. Equal source and neutral outcomes demonstrate that display labels do not change these structured tasks. Equal conventional results provide no evidence of a source-specific correctness advantage.

Observed aggregate runtimes were about 0.009 seconds for the conventional baseline and 0.84 seconds for the source-bound coordinator, excluding shared setup and source loading. These short in-process times are descriptive. The coordinator includes content commitments and provenance overhead absent from the minimal baseline. Total compute was not equalized, and no speed advantage is claimed. Raw timings and records are preserved.

New evaluation seeds are separate from the development/unit examples, but the test distribution was authored alongside the implementation and targets known explicit relations. The diagnostic is useful for correctness, budget accounting and abstention. It does not establish generalization to unstructured source interpretation or independent scientific discovery.

## Reproduction

Run python -m unittest tests_coordinator -q for the fourteen new acceptance checks. Run python coordinator_benchmark.py coordinator_evaluation/new_run to produce a separately locked synthetic diagnostic; the script refuses to overwrite an existing evaluation folder. Source and packet commitments, private evaluator truth, per-case results, summary and hashes are included.

For a structured request, call begin_calculation(request, context), then dig(budget). Save result['snapshot'] and pass it back to begin_calculation with the same request and context to resume. The new jewel request, context and two-pass results are supplied in coordination_demo/.

## Remaining work

An independently authored real-source task set, fixed before outcome access and assessed by reviewers who did not construct the examples, remains needed to investigate discovery advantage. New-handler admission, broad natural-language parsing, production persistence/authentication and automatic garden-controller invocation remain development work. Historical negative and mixed results stay in the record.
