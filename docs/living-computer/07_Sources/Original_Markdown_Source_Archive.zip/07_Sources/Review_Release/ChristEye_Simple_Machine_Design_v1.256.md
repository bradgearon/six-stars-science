# Current release 1.256 / engine 2.17

The current implementation is specified below. The preserved predecessor document follows as historical development disclosure; its version-specific limits and counts do not override this current section.

# ChristEye layered behavior and bounded construction 1.256

Engine 2.17 implements the layered-expression plan in a bounded internal reference. Its source contracts preserve earliest lexical anchors, later contexts, attributed functional meanings and explicit gaps. The corpus covers 31,155 passage records in 66 books; first occurrence means pinned corpus order, not historical utterance order.

## Source and behavior contract

The 93 contracts comprise 60 vocabulary entries, nine inquiry bindings, 13 Kingdom entries, six components and five expression operations. All ten groups are accounted for: Whole/Soul, Word/Knowledge, Spirit, Heart, Understanding, Milk, Honey, Wind/Movement, Roots and Fruit. Five expression contracts have executable effects; 88 retain source-inquiry gaps. The whole corpus can be indexed without claiming that every contextual sense has been exhaustively interpreted.

Each operation retains source identity, contextual reading, functional interpretation, allowed state changes, expected content change and counterexamples. Exact lexical branches retain their own earliest occurrences. Compound and modern terms without an exact identity report an anchor gap. Layer weights allocate finite review-planning units; mandatory evidence and authority conditions cannot be outweighed.

## Mixed execution

The two expression families remain SLAY and SPLENDOR. Their registered internal operations are QUALIFY, WITHDRAW, PAUSE, CLARIFY and PROPOSE_REPAIR. Source imagery and engineering interpretation remain separately attributed. QUALIFY's selected slay branch first occurs at Matthew 2:16 (G337); later correction, humility and grace connections do not redefine that lexical occurrence.

Structured claims retain original text, scope, type, evidence, counterevidence and status. QUALIFY reduces assertion status on unsupported claims, WITHDRAW preserves a deactivated claim, CLARIFY makes the structured account more explicit, PAUSE changes internal eligibility and PROPOSE_REPAIR records an unexecuted proposal. Supported facts survive qualification. A withdrawal followed by clarification cannot revive an assertion.

The controlled renderer quotes source claims as data and supplies their status. Arbitrary prose that contradicts the previewed structure is rejected even with favorable authored scores. Critiques bind to the exact content, target, steps, evidence, context and policy. Contextual relevance, meaning preservation, dignity and scope of support remain separately judged. Missing evidence, material disagreement and unresolved required critique hold execution. An evidence identifier does not itself prove entailment.

The serial compiler admits up to sixteen registered nodes. Source context comes first, preservation second and scheduled review last. It rejects cycles, unknown handlers, unsupported capabilities, false costs and stale targets. BehaviorCycle assesses the complete proposal across Elijah, Moses, David, Daniel, Job, Noah and Abraham, then commits the entire internal transition once with preserved predecessors. Explicit abstention records a reason, baseline prediction and zero confidence; it does not bypass requirements.

## Bounded self-construction and selection

SelfBuilder performs bounded breadth-first goal search over an immutable primitive-effect library. It generates a new composition from declared goals rather than receiving a task-specific workflow recipe. The kernel, source parser, primitives, renderer and evaluator were implemented with human direction and AI assistance; the runtime does not autonomously create those foundations.

FrozenEvaluator commits held-out structured tasks and a fixed promotion protocol. The builder receives no held-out task content. DevelopmentCycle records each admitted attempt before evaluation, compares the actual candidate and incumbent results and can promote an eligible successor automatically. The predecessor supports explicit rollback. Default attempt budget is one. The nominal paired-sign policy is a check on authored fixtures, not a population-level efficacy inference.

## Verification and evidence

523 unit tests passed. Additional checks: 16 invariants, 46 authored Astral scenarios, seven weighted comparisons, 11 covenant checks, 16 individual-expression checks and 21 layered-construction checks (117 total). The new 62 unit tests cover semantic mismatch, hedged infallibility, quoted/refuted claims, preserved arithmetic, stale evidence, disagreement, graph rejection, transaction retry, restart, attempt limits and rollback.

The generated successor completes 12 of 12 authored structured task bundles, compared with 0 of 12 for the deliberately limited incumbent. The bundles require qualification, detailed presentation and a retained question. This demonstrates that added functionality under a committed policy, not superiority over ordinary AI, measured research time saved or scientific discovery. Critiques and follow-up observations are explicitly authored fixtures.

Inspect `verification_1_256/layered_release/`: `construction.json`, `candidate.json`, `protocol.json`, `comparison.json`, `receipt.json`, `development.json`, `state.json` and `summary.json`. The SQLite records support restart. The code commitment is `independent/FREEZE_v2_17.json`, created after development; it is not retrospective preregistration.

## Current boundaries and migration

This trusted-host, single-writer reference performs internal effects only. It does not supply OS isolation, authenticated external evidence, live Gemma/Unity/TTS calls, wall-clock scheduling or independent semantic truth validation. Questions and review ticks are retained state. Due work requires a host call; no background service is implied. Promotion is bounded to the tested scope. Real outcome-driven adaptation remains future work.

Do not reopen a 2.16 session under changed policy. Preserve it, export the records with provenance, explicitly import them into a new session and reassess. The root-relative `engine_2_16_to_2_17.patch` applies with `git am` to unchanged 2.16 code. The ZIP includes all runnable files.

Patent Appendix S adds technical paragraphs CE256-01 through CE256-28 and illustrative concepts 107–112. Existing concepts 1–106 remain unchanged. Code and test evidence improves the disclosure's specificity; novelty, nonobviousness and priority require claim-specific attorney review. No filing or legal allowance is represented.


---

# Preserved predecessor disclosure (1.255)

# ChristEye machine design v1.255

Current engine: 2.16. Current expression contract: [Slay and Splendor](Expression_Operations_v1.255.md).

461 unit tests, 16 original invariant checks, 46 authored Astral scenario checks, seven weighted-coordination comparisons, 11 covenant-lifecycle checks and 16 expression-lifecycle checks. Authored scores and follow-up events. Two internal transitions; no live model or external execution.

## Preserved predecessor design and validation history

# ChristEye machine design v1.254

Current engine: 2.15. Current contract and acceptance details: [Covenant coordination](Covenant_Coordination_v1.254.md).

423 unit tests, 16 original invariant checks, 46 authored Astral scenario checks, seven legacy coordination comparisons and 11 covenant-lifecycle checks. All example predictions and world events are authored. Live model/game execution and comparative product benefit remain unmeasured. V2 is opt-in and adds required host checks, profile floors and decline limits before ranking, loss-preserving confidence treatment, and durable outcome records.

## Preserved predecessor design and acceptance history

The following text retains its 1.253 and earlier context; the current contract above and Appendix Q supersede current-version statements.

# ChristEye machine design v1.253

Current reference engine: 2.14. This merge includes weighted profile coordination, prose-sensitive reassessment, optional finite scene accounts, source occurrence checks and a bounded model callback interface. See Weighted_Profile_Coordination_v1.253.md and the supplied profile review schema. Existing growth proposals remain restricted to compatible registered handlers.

Merge checks rerun the supplied 382 unit tests, 16 invariants, 46 authored Astral checks, seven coordination comparisons and source wiring. Predictions remain separate from observations. Live model, game and speech integration are open acceptance items.

## Preserved prior design and acceptance history

The following sections retain their revision 1.252 context; current runtime status above supersedes historical statements of unchanged engine 2.13.

# ChristEye Simple Machine Design v1.252

Current specification 1.252. Reference engine 2.13.

## Current architecture and governed self development

ChristEye uses source-linked words, layered expressions and functional roles to construct and iteratively refine its own machine structures, operation definitions and inquiry behavior; generate questions, relationships and proposed changes; coordinate further inquiry from results; and constrain conclusions to the permissions supported by its evidence.

Source-derived construction describes how recorded interpretations are embodied in the machine. Governed self-development applies the inquiry process to an identified version of the machine itself, preserving a proposed successor, its implementation, its assessment and its admission as separate states. Human or AI assistance is recorded where used. An improvement is established only for the criteria and conditions actually assessed.

Engine 2.13 supports source-bound execution, result-driven inquiry, committed continuation and a proposed-growth record restricted to an existing compatible handler. It does not synthesize or automatically admit arbitrary new executable handlers. Developer-reviewed implementation and a successor registry are required for such changes. This release updates the disclosure and documentation without changing executable engine bytes.

The source-to-structure method is part of the architecture, including when an inventor or developer implements a recorded interpretation. Runtime inquiry can generate further questions and proposed changes. A proposal to the machine itself identifies the predecessor and affected component; a source match does not prove that the proposed change improves performance.

| Stage | Required record | Current status |
| --- | --- | --- |
| Source-derived construction | Source, interpretation, structure or operation, contributor | Documented design and executable bindings |
| Runtime inquiry | Typed inputs, context, operations, results and frontier | Implemented for registered adapters |
| Growth proposal | Predecessor, compatible handler, rationale and assessment | Existing function returns PROPOSED and NOT_ADMITTED |
| Successor implementation | Separate version and implementation record | Developer-reviewed workflow; arbitrary synthesis not implemented |
| Assessment and admission | Contracts, counterexamples, comparison and admission authority | Defined development requirements; no new automatic admission result |
| Measured improvement | Declared endpoint and scoped predecessor comparison | Not established by this documentation revision |

The integrated patent is revision 1.252. Existing concepts 80 and 85, and the composition concepts 88 through 92, are related drafting directions; the mapping is not a patentability conclusion. The v1.252 schema annotations describe this distinction without changing the executable interchange contract.

## Preserved design history through release 1.246

The following versioned material retains its historical dates and implementation status. The current overview above supersedes historical current-release statements.

# ChristEye Simple Machine Design v1.246

The current engine is 2.12. The following implementation supplement is current; the inherited design follows with its original version and historical results. The patent specification baseline remains v1.245.

# Kingdom implementation guide

Release 1.246 implements the Kingdom specification from patent document 1.245 in reference engine 2.12. It adds a typed composition branch to `begin_calculation`, seven executable profile policies, two scope modes, three expression methods and explicit target-action handoff. Angel and Fold are not added. The inherited sixty-entry vocabulary and seven-entry inquiry overlay remain unchanged; thirteen extension entries give eighty named entries in the combined specification.

The seven profiles retain the user's proposed seven-spirits grouping as interpretive provenance. Their implemented meaning is a set of deterministic software rules. A profile name does not identify a person, diagnose a condition, or confer authority. No result here establishes that the seven people literally are the seven spirits of God.

## Execution architecture

`christeye.coordinator.begin_calculation(request, context, snapshot)` dispatches `KINGDOM_INQUIRY` to `KingdomCoordinator`. It validates the governing context, builds a source-bound registry, selects ready tasks using explicit priority and stable request order, evaluates applicable profile contributions, checks permissions and resources, and invokes the shared `InquirySession` or a registered method adapter. Other typed requests retain their earlier coordinator behavior.

The new path consumes a bounded, caller-supplied task graph. It does not infer tasks, goals, permissions, hidden needs or causal explanations from unrestricted prose. The existing absence and arithmetic paths are preserved; their generated jobs do not automatically acquire these profiles. The caller must use the composed request type for profile-governed work. This is an implemented reference adapter for the patent's compositional design, not every possible embodiment of it.

A task can address a declared Heart or Soul model. The recipient's needs, feedback, target identifier and assessment endpoint travel with each profile application. The machine records those declarations; it does not infer a biological or supernatural identity from a label. Several profiles may govern the same operation and the same recipient, including Dig, Search, Search Out, Deepen, Calculate, Judge and Move stages.

## Seven executable profiles

| Profile | Applicability | Executable effect | Missing or conflicting input |
|---|---|---|---|
| Elijah | Every selected task | Compare purpose identifiers; retain competing objectives | Wrong purpose fails; unaccounted competing objectives remain unresolved |
| Moses | Every selected task | Evaluate the explicit prerequisite list | A failed prerequisite fails; an omitted list remains unresolved |
| David | Every selected task | Require a declared need and recipient-specific endpoint; retain feedback | Missing or mismatched need/endpoint remains unresolved |
| Daniel | Semantic work or expression methods | Require at least two distinct alternatives and a discriminating observation | Missing alternatives or distinguishing observations remain unresolved |
| Job | Context contains counterevidence | Copy contrary observations into the application; prevent premature resolution | An unaddressed counterexample holds a claimed resolved conclusion |
| Noah | Protected state, interpretation or target Move | Check preservation references; require a recovery reference before Move | Missing preservation or recovery remains unresolved |
| Abraham | Uncertainty or target Move | Require a positive bounded step and review rule; check its cost | Missing plan remains unresolved; exceeding its bound fails |

Each application records the rule, question, contribution, input digest, target, recipient, source ancestry, checks and result. A name-only tag is not counted as an applied profile. Inactive profiles retain an explicit reason. Agreement between profiles is not counted as independent corroboration.

Profile inputs are declarations checked for structural consistency. A supplied prerequisite marked PASS is not independently verified in the real world by this engine. A recovery reference does not demonstrate a tested recovery procedure. Source-referenced proposed prose is not semantically verified merely because its source exists. These limitations remain visible in the result classes.

## Kingdom contract and decision policy

The governing record requires identity/version, context and observation references, a purpose, participants, targets, recipients and needs, system and inquiry boundaries, a source allowlist, authority references, selected profiles, protected targets, protected constraints, resource limits and endpoints with observation intervals. `policy_ref` identifies the caller's declared policy; it does not load arbitrary code.

The observation context supplies source payloads, current authorities, counterevidence, protected-state references and optional target observations and execution metadata. No permission follows merely from a purpose or biblical label. Each allowed operation and target must occur together in a referenced authority record. Individual target actions require explicit action permission. The inherited participant-consent checks remain active at the execution boundary.

Tasks form an acyclic sequence of backward references. Among tasks whose dependencies have completed, the coordinator selects the highest explicit integer priority and breaks ties in request order. Failed or unresolved prerequisites produce retained decisions without dispatch. Profiles use deterministic applicability predicates; this release has no learned weighting or automatic policy synthesis.

Hard checks cannot be outweighed. Any FAIL makes the composition FAIL; otherwise any UNRESOLVED prevents dispatch. A successful adapter execution does not establish the truth of a proposed explanation or benefit to a target. Completion reports separate operation, interpretation, comprehension and outcome statuses.

## Scope modes and methods

Behemoth is the internal mode. Dependency graph nodes, roots and dependencies must stay within the declared system boundary, with a depth limit. Missing nodes remain unresolved. Leviathan is the cross-boundary mode. It records the current inquiry boundary, candidate source route and permitted source identifiers. Sources must already be supplied and allowlisted; there is no live network connector or delegated external agent in this release. A route is a recorded inquiry movement, not a finding about a person's spiritual state.

Speaking in Tongues uses `PRESERVE_EXPRESSION`. It retains the original UTF-8 content, digest, origin, representation, source context and intended recipient. The content must match the committed origin. An opaque representation remains unresolved for its recipient; it is not generated merely to appear mysterious.

Interpretation uses `INTERPRET_EXPRESSION` with an explicit expression predecessor. `JSON_FIELDS_V1` handles a nonempty JSON object of at most 64 scalar fields. It rejects duplicate keys, non-finite numbers, nested structures, unknown adapters, incomplete field schemas and ambiguous labels. The supplied schema must match the committed source payload. Field names, values and original content are preserved. Structural rendering is recorded separately from the recipient's unmeasured comprehension. Other codecs and general semantic interpretation remain future work.

Prophecy uses `DISCLOSE`. It renders caller-supplied proposed or unresolved statements with allowed, existing evidence references. It does not certify their semantic entailment, generate divine messages, or promote prose into an observation. Forecasts additionally require a variable, issue time matching the committed observation time, a later horizon, expected value and `EXACT_MATCH` assessment rule, without an already-observed outcome. `assess_outcome` can later record a source-linked observation, baseline, uncertainty and confounds. Matching a forecast does not establish causation or healing.

Wind is the output expression; intelligibility is the adapter's structural/text rendering status; immediate response and Fruit remain empty until separately reported. These methods are not hard-wired exclusively to one scope mode or profile. An external decoding schema can combine Interpretation with Leviathan; an internal account can use Prophecy with Behemoth when its references remain internal.

## Target actions

`JUDGE` and `MOVE` pass a supplied candidate through `runtime.evaluate_execution`. MOVE initially returns a target-action candidate with `NOT_EXECUTED`. An eligible decision may be handed to `execute_target` with the current context and an explicit executor callback. The coordinator checks that the context is unchanged, recomputes the composition, and calls the inherited `execute_guarded` immediately before the callback.

The callback receives a copy of the candidate. The controller records an attempt before invocation. An exception leaves its outcome unknown and prevents an automatic retry. Recorded attempts survive snapshot restoration. This is an in-process protocol, not a security sandbox or durable exactly-once transaction service. External adapters must implement their own idempotence, persistence and reconciliation. No external target was changed by the release diagnostic.

## Resource and replay contracts

`dig(n)` limits the number of attempted compositions in that call. The Kingdom's `max_units` separately caps total deterministic policy units: selection, applicable profile evaluations, adapter work and retrieval candidates. `max_candidates`, `max_depth` and `max_retrievals` constrain task count, graph traversal and source routing. These units are accounting rules, not equal wall-clock time or equal total compute across implementations.

`KingdomSnapshot` commits the request, observations, registry, policy, code, unit usage, composition events, target execution receipts and nested `InquirySession`. This reference adapter nests the shared primitive session, rather than serializing a second legacy Calculate coordinator inside it. Restoration reproduces the deterministic prefix and compares it to the snapshot; it never replays external actions. Changing a source, recipient, rule, permission or implementation requires reassessment. The original expression remains in its predecessor record. Digests detect changes relative to a trusted commitment; they do not authenticate authorship or time.

## Source closure and numbering

Thirteen contextual bindings are built from the already bundled, digest-verified OSHB Hebrew and TAGNT Greek extracts. Their records retain edition identity, source token/span identifiers, content digests, proposed interpretation, handler version and permissions. The implementation admits these selected contextual passages; it does not complete a new lexical-sense study of every alternate anchor in the prior specification.

| Entry | English reference | Bundled locator range |
|---|---|---|
| Kingdom | Psalm 103:19–22 | Ps.103.19 through Ps.103.22 |
| Elijah | 1 Kings 18:21–39 | 1Kgs.18.21 through 1Kgs.18.39 |
| Moses | Exodus 18:17–23 | Exod.18.17 through Exod.18.23 |
| David | Psalm 51:1–12 | Ps.51.3 through Ps.51.14 |
| Daniel | Daniel 2:27–30 | Dan.2.27 through Dan.2.30 |
| Job | Job 42:7–8 | Job.42.7 through Job.42.8 |
| Noah | Genesis 6:14–22 | Gen.6.14 through Gen.6.22 |
| Abraham | Genesis 12:1–4 | Gen.12.1 through Gen.12.4 |
| Behemoth | Job 40:15–24 | Job.40.15 through Job.40.24 |
| Leviathan | Job 41:31–32 | Job.41.23 through Job.41.24 |
| Speaking in Tongues | 1 Corinthians 14:2–5 | 1Co.14.2 through 1Co.14.5 |
| Interpretation | 1 Corinthians 14:13–19 | 1Co.14.13 through 1Co.14.19 |
| Prophecy | 1 Corinthians 14:24–29 | 1Co.14.24 through 1Co.14.29 |

The Psalm 51 and Job 41 differences preserve Hebrew/English versification explicitly. An exact span match verifies the source attachment, not that Scripture states the proposed software algorithm or confirms supernatural identities.

## Patent crosswalk and remaining work

| Patent section | Engine 2.12 implementation | Scope still open |
|---|---|---|
| 5.5J | Governing context; seven rules; internal/external modes | Richer interpretation rules, independently evaluated profile selection |
| 5.5K | Expression preservation, JSON field adapter, scoped disclosure and forecast record | General language/codec interpretation, measured recipient comprehension |
| 5.7D | Deterministic composition, dispatch, hard checks and resource accounting | Automatic task generation from unrestricted prose and adaptive ranking |
| 5.10E | Profile applications, composition events, snapshot replay and separate outcome records | Production persistence, authentication and durable executor transactions |
| 6.17 | Executed supplied-data service diagnostic and missing-schema case | Independently authored real service cases |
| 8.15 | Regression, failure cases, profile ablation and reproducible diagnostic | Matched independent comparison, source-specific advantage and empirical benefit |

The v1.245 patent document remains the specification baseline with its original release-date status statements. This guide and the 1.246 manifest provide the current implementation status; historical tests are not relabeled as new results. Illustrative claim concepts 1–93 are unchanged. No patentability or legal conclusion is supplied by the software tests.

## Run and inspect

Extract `christeye_machine_v2_12.zip` and open a terminal in the extracted engine directory. With the inherited requirements installed, run the commands below. Choose a new output directory for each diagnostic run.

```text
python kingdom_demo.py kingdom_results/my_run
python -m unittest tests_kingdom -q
python -m unittest discover -p 'tests*.py' -q
python tests_v2.py
```

Inspect `result.json` for the profile applications and decisions, `missing_schema_result.json` for the held interpretation, and `summary.json` for the compact result. Each output is linked to its supplied context and source registry. The main README provides the Python API example and explicit target-action handoff instructions.


# Inherited design and historical evidence from v1.244

<!-- Current release: documents 1.244 and engine 2.11; result-driven coordination is described in the final section. -->

<!-- Current: documents 1.243, engine 2.10. Earlier version statements and results below are historical unless explicitly updated by the Revision 1.243 section. -->

# ChristEye Simple Machine Design v1.243

## Central architectural principle

ChristEye generates, evaluates and guides proposed changes through a source-derived inquiry architecture. Bound ancient words and layered expressions shape its structures, operation definitions, context rules, retained state and further development. Knowledge denotes retained information; Understanding denotes encoded capacity to apply relationships in context. Calculate coordinates Word, Search Out, Judge and Move: it assembles a candidate account and performs explicit reckonings while preserving their different source bindings. Dig, Search, Search Out and Deepen are distinct investigative movements. Mystery routes inquiry toward an unresolved explanation; Outside routes retrieval beyond an identified inquiry boundary. Each movement preserves its source interpretation, inputs, scope, alternatives and result. Inquiry-state movement is distinguished from a target intervention, which remains subject to the existing eligibility gate. Later source readings can propose successor operations and structures through recorded review and validation. Target outcomes and voluntary user participation are assessed separately. Its architecture implements the framework's source-derived understanding of words and layered expressions from a bound ancient scriptural corpus. These interpreted relationships shape the machine's structures, operations, context rules, response selection and retained-state organization, and will continue to guide revisions to its implementation. Understanding denotes encoded capacity to apply relationships in context; Knowledge denotes retained information available for use. Word, Move and Judge summarize the operating cycle: apply a source interpretation, formulate a change, assess its eligibility, execute where supported, and judge observed consequences. The source stream supplies further readings to this existing architecture. Target outcomes and user participation are assessed separately. Appendix J illustrates the process through the Tree of Knowledge synthesis; its biological proposals remain subject to validation.

Source word → recorded interpretation → proposed system change → assessment → retained experience → future proposals.

The long-term objective spans technology, healthcare, bioscience, engineering, community and fellowship. Continuing usefulness is a design objective, not a guaranteed outcome. Registered interpretations and supported adapters define the implemented scope; arbitrary words and domains are not automatically executable. The founder’s thousand-year vision expresses intended longevity, not a measured service life.

Document revision 1.14 adds the Tree of Knowledge exhibit and illustrative claim concepts 77 through 79. Engine 2.9 and its empirical results are unchanged. Versioned interpretations, replaceable subject adapters, durable records and reassessment under new evidence express the intended extensibility; future compatibility requires maintenance and validation.


Current release: documents 1.243 / engine 2.10. The core inquiry additions are described in the Revision 1.243 section; older sections retain historical scope. The Version 1.13 optional refinement section is authoritative for this addition. Version 1.12 describes the earlier experimental integration. Historical sections below retain their original releases. The Version 1.12 integration status section supersedes earlier statements about current integration; earlier results remain historical.

Current revision merges Joint and the pinned Greek edition in section 21, retaining the heart-to-heart inquiry in section 20. All 60 inventory entries now have executable source bindings. Explicitly dated results retain their original version.


Version 1.11 · November 10, 2026 UTC · Brad Gearon · We Develop Software LLC

Internal design and implementation specification. Aligned with the v1.11 integrated patent draft, schema and validation protocols. Version 2.7.1 merges the Greek source adapter and Joint into the reviewed heart-to-heart extension. It retains Firmament, the unchanged CE60 inventory and all prior repairs, with 60 executable bindings. This revision preserves the framework's source-derived interpretation method and separates proposed mechanisms, implemented pilot behavior and completed verification.

## Purpose and central method

ChristEye generates questions and proposed system changes by applying Brad Gearon's layered reading of words, source passages, relationships and functions. The ChristEye source-bound generation profile requires this reading method and its scriptural source-word foundation. The evidence gate determines which resulting claims have support; it does not supply or replace the reading method.

The framework's depth-of-reading principle is to approach each word as **deep as the ocean**: an expandable family of meanings and relationships whose interpretation may change with the system, recipient, layer and purpose. The current foundational vocabulary has 60 entries; additional words, phrases and dimensions can supply cues or enter a later version of the registry. Each execution has finite search limits so the machine can stop, assess a result and preserve unfinished paths.

A live expert is optional. The method can be recorded in a MethodProfile, curated lexicon, interpretation paths, parable templates and resolution rules and then applied deterministically. An expert can contribute additional interpretations or review fidelity to the method. A large improvement from expert participation remains a testable hypothesis.

The intended software separates three tasks: generate candidate interpretations, anchor proposed relationships to ordinary entities and contexts, and evaluate them under operation-specific evidence rules. A powerful association can be worth investigating while remaining unsupported.

## Scriptural foundation and the 60 entry vocabulary

The ChristEye source-bound profile requires identified scriptural source words and the framework's recorded layered interpretation method. The exploration stream selects material from that foundation; a direct source-bound reading can operate with the stream off. English labels provide lookup and display names. They do not erase source-language alternatives or establish a physical identity.

The frozen **CE60-1.4** inventory contains **45 core entries, 14 family members and one extension, Breath**. Light is entry 60. Bread and Seed are separate core entries: Bread asks about usable provision; Seed asks about an initiating or propagating unit. Light asks how a hidden signal or distinction can become observable. These are framework functions, not a claim that 60 universal physical components have been established.

Family resolution preserves the member and records the path to a core parent. Reins → Heart can guide retrieval without turning Reins into Heart. Mind, Reins, Frame, Formed, Embryo, Book, Knit, Honeycomb, Tablet, Whet, Train, Joint, Refreshment and Fool retain separate identities, candidate lexical identifiers and notes. Unknown entries, missing parents and cycles are rejected.

### Previously verified executable source occurrences

| Entry | Tier | Lexical identifier | Computed first occurrence in the pinned Genesis file | Generation operation |
| --- | --- | --- | --- | --- |
| Bread | Core | H3899 | Genesis 3:19, token 012Ss | Propose SUPPLY for a Bread-role target, subject to the common gate |
| Seed | Core | H2233 | Genesis 1:11, token 01VA9 | Request MEASURE_INITIATION for an initiating input |
| Light | Core | H216 | Genesis 1:3, token 01W26 | Request MAKE_OBSERVABLE for a Wind-role signal |

The package retains the exact Open Scriptures Hebrew Bible Genesis XML bytes, its SHA-256 fingerprint and annotation attribution. These three anchors are computed separately by exact lexical identifier in document order. The scope is **Genesis only**. This is a digital annotated edition, not a manuscript witness or proof of earliest historical usage. Augmented identifiers such as H6213 a are retained instead of silently collapsed into H6213. The English operational readings are authored interpretations; the Hebrew occurrence check does not establish their functional truth.

### Expanded word operations

The current library contains **60 bindings for the unchanged 60-entry inventory**: 59 Hebrew bindings and Joint in the pinned Greek New Testament extract. Bread, Milk, Compassion and Whet propose actions; the other 56 request measurements. A request creates no observation by itself. All 60 emit in the v2.7.1 wiring example (64 packets); this measures coverage and code participation, not discovery success. Source interpretations remain pending the inventor's review and lexical refinements remain subject to scholarly review. The earlier cycle, estimator, execution-gate and heart-to-heart repairs are preserved.

| # | Entry | Lexeme | Anchor | Operation | Target role |
| --- | --- | --- | --- | --- | --- |
| 1 | Bread | H3899 | Gen 3:19 | SUPPLY (action) | Bread |
| 2 | Seed | H2233 | Gen 1:11 | MEASURE_INITIATION | Bread |
| 3 | Light | H216 | Gen 1:3 | MAKE_OBSERVABLE | Wind |
| 4 | Water | H4325 | Gen 1:2 | MEASURE_ACCESS | Water |
| 5 | Milk | H2461 | Gen 18:8 | STRENGTHEN (action) | Milk |
| 6 | Honey | H1706 | Gen 43:11 | MEASURE_SELECTIVITY | Honey |
| 7 | Wind | H7307 | Gen 1:2 | MEASURE_ACTIVITY | Wind |
| 8 | Spirit | H7307 | Gen 1:2 | MEASURE_ORGANIZING_INFLUENCE | Wind |
| 9 | Soil | H127 | Gen 1:25 | MEASURE_RECEIVING_CONTEXT | Soil |
| 10 | Heart | H3820 a | Gen 6:5 | MEASURE_BASELINE_DEPARTURE | Heart |
| 11 | Frame | H3336 | Gen 6:5 | MEASURE_FORMATION | Template |
| 12 | Son | H1121 a | Gen 3:16 | MEASURE_TEMPLATE_CONFORMANCE | Template |
| 13 | Eyes | H5869 a | Gen 3:5 | OBSERVE_UNMEASURED | Wind |
| 14 | Bone | H6106 | Gen 2:23 | MEASURE_STRUCTURAL_LOAD | Template |
| 15 | Knowledge | H1847 | Gen 2:9 | MEASURE_RECORDED_STATE | Roots |
| 16 | Deep | H8415 | Gen 1:2 | MEASURE_CHAOS | Soil |
| 17 | Breath | H5397 | Gen 2:7 | MEASURE_ACTIVATION | Bread |
| 18 | Lotus | H6628 | Job 40:21 | MEASURE_COORDINATION | Lotus |
| 19 | Marrow | H4221 | Job 21:24 | MEASURE_FOUNDATIONAL_INSTRUCTION | Marrow |
| 20 | Engram | H2801 | Exod 32:16 | MEASURE_RETAINED_TRACE | Heart |
| 21 | Template | H8403 | Exod 25:9 | MEASURE_TEMPLATE_CONSTRAINT | Template |
| 22 | Mesh | H7568 | Exod 27:4 | MEASURE_RELATIONSHIPS | Mesh |
| 23 | Roots | H8328 | Deut 29:17 | MEASURE_PERSISTENCE | Roots |
| 24 | Wisdom | H2451 | Exod 28:3 | MEASURE_ACTION_SELECTION | Honey |
| 25 | Satan | H7854 | Num 22:22 | MEASURE_ADVERSE | Water |
| 26 | Understanding | H8394 | Exod 31:3 | MEASURE_DISCRIMINATION | Honey |
| 27 | Medicine | H1456 | Prov 17:22 | MEASURE_HEALING_OUTPUT | Heart |
| 28 | Tree | H6086 | Gen 1:11 | MEASURE_GROWTH_STRUCTURE | Roots |
| 29 | Good | H2896 a | Gen 1:4 | MEASURE_CONFIRMED_BENEFIT | Wind |
| 30 | Evil | H7451 | Deut 17:12 | MEASURE_HARM | Wind |
| 31 | Holy | H6942 | Gen 2:3 | MEASURE_BOUNDARY_INTEGRITY | Template |
| 32 | Fruit | H6529 | Gen 1:11 | MEASURE_OUTPUT_FRUIT | Wind |
| 33 | Peace | H7965 | Gen 15:15 | MEASURE_WHOLENESS | Heart |
| 34 | Anxious | H1674 | Josh 22:24 | MEASURE_OVERLOAD | Milk |
| 35 | Anger | H639 | Gen 2:7 | MEASURE_ESCALATION | Heart |
| 36 | Pride | H7830 | Job 28:8 | MEASURE_FEEDBACK_IGNORED | Honey |
| 37 | Arbiter | H3198 | Gen 20:16 | MEASURE_IMPULSE_PULL | Honey |
| 38 | Compassion | H7358 | Gen 20:18 | SUPPLY (action) | Milk |
| 39 | Whet | H8150 | Deut 6:7 | STRENGTHEN (action) | Roots |
| 40 | Soul | H5315 | Gen 1:20 | MEASURE_LIVING_NEED | Heart |
| 41 | Flesh | H1320 | Gen 2:21 | MEASURE_PHYSICAL_SUBSTRATE | Soil |
| 42 | Blood | H1818 | Gen 4:10 | MEASURE_CIRCULATION | Water |
| 43 | Love | H157 | Gen 22:2 | MEASURE_CARE_ALIGNMENT | Heart |
| 44 | Joy | H8057 | Gen 31:27 | MEASURE_SATISFACTION | Bread |
| 45 | Word | H1697 | Gen 11:1 | MEASURE_MESSAGE_FIDELITY | Marrow |
| 46 | Sinew | H1517 | Gen 32:33 | MEASURE_BOUNDARY_CONNECTIONS | Mesh |
| 47 | Prosody | H6963 a | Gen 3:8 | MEASURE_SIGNAL_PATTERN | Honey |
| 48 | King | H4428 | Gen 14:1 | MEASURE_HEART_RULE | Heart |
| 49 | Mind | H3820 a | Gen 6:5 | MEASURE_ATTENTION | Heart |
| 50 | Reins | H3629 | Exod 29:13 | MEASURE_FILTERING | Water |
| 51 | Formed | H3335 | Gen 2:7 | MEASURE_BUILD_PROCESS | Template |
| 52 | Embryo | H1564 | Ps 139:16 | MEASURE_EARLY_STAGE | Template |
| 53 | Book | H5612 a | Gen 5:1 | MEASURE_LINEAGE | Roots |
| 54 | Knit | H5526 c | Ps 139:13 | MEASURE_ASSEMBLY | Mesh |
| 55 | Honeycomb | H6688 | Ps 19:11 | MEASURE_STRUCTURED_STORAGE | Mesh |
| 56 | Tablet | H3871 | Exod 24:12 | MEASURE_WRITE_CAPACITY | Roots |
| 57 | Train | H2596 | Deut 20:5 | MEASURE_EARLY_TRAINING | Roots |
| 58 | Refreshment | H8250 | Prov 3:8 | MEASURE_REPLENISHMENT | Marrow |
| 59 | Fool | H5036 | Deut 32:6 | MEASURE_EVIDENCE_DENIAL | Honey |
| 60 | Joint | G719 | Heb 4:12 | MEASURE_BOUNDARY_INTEGRITY | Mesh |

### Edition scope and exact lexical senses

The expanded design uses 39 OSHB book files with a digest for each file and a closure digest covering the ordered file list, source-byte digests and matching policy. English Protestant and Hebrew Tanakh book orders are declared as separate editions. Each implementation must preserve the actual ordered list rather than relying on an order name. An anchor belongs to its exact edition and scope; an out-of-scope anchor produces a gap. Genesis bytes can be shared across editions, while edition identities and order-dependent anchors remain distinct. These are annotated digital editions, not manuscript witnesses or proof of earliest historical usage.

The supplied update reports three order-sensitive candidate anchors: Roots H8327 at Job 5:3 under English order and Isaiah 27:6 under Tanakh order; Satan H7853 at Psalm 38:21 and Zechariah 3:1; Refreshment H8250 at Proverbs 3:8 and Hosea 2:7. These are candidate lexemes and must not replace the table's distinct Roots H8328 or Satan H7854 binding identifiers. The full-edition anchor artifact is `verification/ce60_anchors_full_hebrew.json`; its reported Hebrew occurrences and absences were recomputed in this revision and matched. This does not approve the proposed lexical senses. That earlier artifact reports Hebrew candidate coverage only. Joint remains outside the Hebrew-only edition; the v2.7.1 combined edition supplies its separate Greek binding (section 21).

Retain source versification and any English alignment separately: the update gives Sinew H1517 at Genesis 32:33 (English 32:32), and Roots H8328 at Deuteronomy 29:17 (English 29:18). Each claimed first occurrence must be recomputed from the committed bytes, exact identifier, declared order and matching algorithm before receiving COMPUTED_VERIFIED status.

Augmented identifiers remain exact. The update proposes H3820 a for Heart, H5869 a for Eyes and H1121 a for Son as refinements of listed base candidates. Their Genesis occurrences were checked; admitting a refinement additionally requires a recorded lexical review of the intended sense. A base-number match alone is insufficient. The supplied Marrow counterexample is H4229 a (reported as blot out), which must not be accepted merely because its base resembles another proposed marrow sense. Preserve alternatives and disagreement; do not remove a suffix to force a match.

### Registered operations and review boundaries

A versioned operation registry identifies each permitted operation, its kind, target role, prerequisites, code identity where available and review record. The four action families remain SUPPLY, WITHHOLD, REMOVE and STRENGTHEN. A binding names a registered operation; unknown operations, unavailable edition scope, missing review prerequisites or unresolved target identities produce explicit gaps. Draft interpretations may be explored under a declared development profile, but cannot be represented as inventor-reviewed operations in a confirmatory study.

Wind and Spirit can share H7307 while requesting activity and organizing-influence measurements respectively. Frame keeps its own identity and recorded family path to Template. A target role does not rename the original word: Seed targeting Bread remains Seed. Satan's MEASURE_ADVERSE row applies to a separately declared shadow target; the word does not establish that a real entity is harmful. Medicine requests an assessment of a specified healing output; it does not establish treatment efficacy. Names such as chaos, baseline departure and discrimination require a defined observable, units, context and criterion before measurement can occur.

This table describes 60/60 binding coverage (100%), not an execution-success rate or a discovery-quality gain. Joint resolves through Sinew while its operation targets a Mesh-role interface. A Hebrew-only run still reports Joint as an explicit scope gap. Coverage does not approve an interpretation or increase empirical permission.

### Source words translations and manuscripts

A `SourceLexeme` identifies a lexical entry in a named language and versioned lexical resource. A morphological root, lemma, exact written token and English gloss are distinct values. Strong's identifiers are indexing aids, not proof that two entries have one root, one sense or one function. Preserve augmented identifiers and homograph distinctions when the resource supplies them. Keep the exact source bytes; store a derived normalization separately under a named algorithm.

A `TextEdition` identifies the actual text used by a run, including its digest, canon/book order, tokenization, lexical annotations and version. A `ManuscriptWitness` separately identifies a surviving witness, its locator, reading and scholarly dating record where available. A modern critical edition or tagged digital text is not itself an ancient manuscript. A manuscript date interval does not automatically establish that a word was first used then. Uncertain or conflicting readings remain visible.

Three different anchor questions are stored in `OccurrenceAnchor`: **FIRST_IN_EDITION** for the first occurrence of a specific lexeme under a declared order; **INTERPRETIVE_PASSAGE** for a selected passage important to the inventor's reading; and **MANUSCRIPT_ATTESTATION** for an occurrence in an identified witness. First occurrence is a computational selection rule and part of the framework's method; it does not exhaust the lexeme's later senses or make that interpretation scientifically true. A sense-filtered first occurrence must record the sense rule and its annotations. Whole-lexeme and sense-filtered results are not interchangeable.

Compute an anchor for each selected lexeme separately. If several Hebrew, Aramaic or Greek lexemes are proposed for one framework entry, retain all alternatives and their individual anchors. Do not apply the former rule “first of any Hebrew identifier, otherwise Greek,” because it can silently select a different sense or discard a language. For example, Mind's supplied list includes H7307, already associated with Genesis 1:2 under Wind and Spirit; its supplied Genesis 26:35 reference cannot be called the first occurrence of every listed identifier. Marrow's several identifiers likewise require separate records.

A `TranslationAlignment` records a particular edition, passage and token correspondence. It is many-to-many and may be partial, disputed or unresolved. Sharing an English word does not merge two source lexemes. Sharing a source lexeme does not collapse Wind and Spirit into one framework function. A Greek counterpart, including a proposed Septuagint alignment, requires its own textual record; listing Greek and Hebrew identifiers together is not a verified translation lineage. The system links identified translations to identified source readings, without claiming that all translations derive from one recoverable original token.

### Versioned mapping inventory

All candidate lexical mappings remain DRAFT at inventory level. Three executable occurrence bindings were previously reviewed; the historical expansion specified 27 mappings; the current executable library contains 60 bindings, with interpretation review and code verification recorded separately. Supplied notes, cross-links, Heart/Engram/Mesh/Template relationships, Prosody and Compassion ideas, Job 40–41 readings and Marrow-expression hypotheses remain attributed research in `christeye/vocabulary.json` and the unchanged supplied archive in `history/`. Original TEXT or LEXICAL tags in that research are not accepted review statuses. Biological and spiritual correspondences remain interpretations or hypotheses.

| # | Entry | Tier | Family parent | Candidate lexical identifiers | Proposed function |
| --- | --- | --- | --- | --- | --- |
| 1 | Bread | core | — | H3899, G740 | Usable provision consumed or built from. |
| 2 | Milk | core | — | H2461, G1051 | Support that sustains capacity over time. |
| 3 | Honey | core | — | H1706, G3192 | Selection, guidance, attraction or gating. |
| 4 | Water | core | — | H4325, G5204 | Access, channel or transport. |
| 5 | Lotus | core | — | H6628 | Coordination and integration; lexical identification remains disputed. |
| 6 | Marrow | core | — | H4221, H2459, H4229, G3452 | Foundational structure or instruction. |
| 7 | Roots | core | — | H8328, H8327, G4491 | Retained state with later functional availability. |
| 8 | Wind | core | — | H7307, G417, G4151 | Expressed activity or flow. |
| 9 | Soil | core | — | H127, G1093 | Receiving context or environment. |
| 10 | Mesh | core | — | H7568, G1350 | Typed relationships among components. |
| 11 | Template | core | — | H8403, G5179 | Organization constraining possible responses. |
| 12 | Heart | core | — | H3820, H3824, G2588 | Priorities and context-dependent response formation. |
| 13 | Fruit | core | — | H6529, G2590 | Declared outcome and its measured consequences. |
| 14 | Soul | core | — | H5315, G5590 | Specified whole and inquiry boundary. |
| 15 | Spirit | core | — | H7307, G4151 | Inventor-defined disposition or organizing influence, requiring an ordinary target for empirical use. |
| 16 | Mind | family | Heart | H3820, H7307, G3563, G1271 | Interpretation and deliberation, with context-specific referents. |
| 17 | Flesh | core | — | H1320, G4561 | Material realization of a represented system. |
| 18 | Blood | core | — | H1818, G129 | Transport or sustaining exchange, subject to context. |
| 19 | Knowledge | core | — | H1847, H3045, G1108, G1922 | Recorded information and retained state as defined by the framework. |
| 20 | Understanding | core | — | H8394, H998, H995, G4907 | Capacity to interpret or carry out a specified function. |
| 21 | Wisdom | core | — | H2451, G4678 | Context-sensitive selection among possible actions. |
| 22 | Eyes | core | — | H5869, G3788 | Observation and discrimination channels. |
| 23 | Tree | core | — | H6086, G1186, G3586 | Branching organization with declared topology. |
| 24 | Good | core | — | H2896, G18, G2570 | Benefit relative to declared recipients and goals. |
| 25 | Evil | core | — | H7451, G2556, G4190 | Harm or adverse direction relative to declared recipients and goals. |
| 26 | Satan | core | — | H7854, H7853, G4567, G1228 | Attributed adversary or opposition cue; no supernatural identity assignment to a target. |
| 27 | Holy | core | — | H6942, H6944, H6918, G40 | Attributed dedication or boundary of purpose. |
| 28 | Love | core | — | H157, H160, G25, G26 | Care and relationship as an attributed priority. |
| 29 | Joy | core | — | H8057, G5479 | Reported positive experience or an explicitly chosen goal. |
| 30 | Peace | core | — | H7965, G1515 | Reported calm or stability when appropriate to the goal. |
| 31 | Anxious | core | — | H1672, H1674, G3309, G3308 | Reported anticipation or concern; meaning and benefit depend on context. |
| 32 | Anger | core | — | H639, H2734, G3709, G3710 | Reported anger or mobilization; meaning and benefit depend on context. |
| 33 | Word | core | — | H1697, G4487, G3056 | A message or instruction expression. |
| 34 | Sinew | core | — | H1517 | Connections and interfaces between structures. |
| 35 | Medicine | core | — | H1456 | A proposed restorative intervention; benefit requires measurement. |
| 36 | Refreshment | family | Water | H8250 | Renewal or access that restores capacity. |
| 37 | Bone | core | — | H6106, G3747 | Structural support that holds parts together or carries load. |
| 38 | Frame | family | Template | H3336 | Organizing form within the Template family. |
| 39 | Formed | family | Template | H3335, G4111 | Formation process within the Template family. |
| 40 | Embryo | family | Template | H1564 | Developing initial form within the Template family. |
| 41 | Book | family | Template | H5612, G976 | Recorded organization within the Template family. |
| 42 | Prosody | core | — | H6963, H1902, G5456, G136 | Pattern and timing in an expressed signal. |
| 43 | Knit | family | Mesh | H5526 | Interconnection within the Mesh family. |
| 44 | Engram | core | — | H2801, G1449 | A retained trace that can influence later response. |
| 45 | Tablet | family | Engram | H3871, G4109 | Recorded trace within the Engram family. |
| 46 | Whet | family | Engram | H8150 | Repetition or sharpening within the Engram family. |
| 47 | Train | family | Engram | H2596 | Practice and shaping within the Engram family. |
| 48 | Compassion | core | — | H7355, H7358, G4697 | A care-oriented response to perceived need. |
| 49 | Honeycomb | family | Mesh | H6688 | Supporting organization within the Mesh family. |
| 50 | Joint | family | Sinew | G719 | Articulating interface within the Sinew family. |
| 51 | Pride | core | — | H7830, H1347, G5243 | An inventor-defined departure or dominance pattern. |
| 52 | King | core | — | H4428, G935 | An inventor-defined authority and stewardship pattern. |
| 53 | Son | core | — | H1121, G5207 | Relationship and conformity to a declared template. |
| 54 | Fool | family | Pride | H5036, G878 | An inventor-defined departure within the Pride family. |
| 55 | Deep | core | — | H8415, G12 | A context with unresolved depth or complexity. |
| 56 | Reins | family | Heart | H3629, G3510 | Inner regulation within the Heart family. |
| 57 | Arbiter | core | — | H3198 | A recorded adjudication function. |
| 58 | Breath | extension | — | H5397 | Activation or renewal input enabling activity. |
| 59 | Seed | core | — | H2233 | Starting unit that develops or propagates under suitable conditions. |
| 60 | Light | core | — | H216 | Make an otherwise hidden distinction or signal observable. |

### Binding the foundation to generation

`FrameworkVocabulary` fixes the inventory and reading-method version. A `FrameworkBinding` connects one entry to reviewed source lexemes and occurrence anchors, an attributed `InterpretationPath`, and a permitted generation operation. The execution sequence is:

1. Load the vocabulary, exact editions, lexeme records, alignments, interpretation method and operation definitions from the committed manifest; verify current content against every declared digest.
2. Match a problem term to candidate entries through a recorded alias or source alignment. Retain all admissible alternatives. A missing or disputed binding produces an unresolved result or a curation request, not an alphabetic fallback.
3. Apply the binding's interpretation and operation to the ordinary target graph. Record the source span, chosen lexeme, alternatives, interpretation path, target, layer and proposed change. External problem observations retain ordinary identities and units.
4. Rank hypothetical proposals within the fixed work budget. Attach `foundation_binding_refs` to every ChristEye proposal. This lineage must be used during generation, not added retrospectively to unrelated outputs.
5. Apply the common evidence and action gate, then commit the generation state. Source verification authorizes a textual or lexical statement only; it cannot turn an interpretation into experimental support.

A verified lexical mapping is required before a source-bound generation run uses it. Unresolved interpretations can still generate explicitly hypothetical questions once their actual textual source is identified. Curation records can retain completely unresolved mappings. Source-neutral experimental controls remain available as separately labeled profiles and are not represented as full ChristEye runs.

Good, Evil and Satan supply attributed discernment or adverse-process questions; they are not aliases for ELIGIBLE, BLOCKED or a person's identity. Gate states remain technical outcomes with UNRESOLVED preserved. Love, Joy, Peace, Anxious and Anger do not impose a universal clinical baseline; human goals, reported experiences and adverse effects remain context-qualified. These terms retain their spiritual meaning in ChristEye's interpretation records without asserting supernatural causation in a target system.

### Integrity migration and completion criteria

Schema 1.7 preserves the CE34 legacy profile, CE60 inventory, edition and operation records, and separately identified v1.5 runtime annotations. It adds six garden record types and a sixth draft fixture. The fifth example is a draft operation-curation fixture, not an executed 27-binding run. Runtime validation must enforce registry membership, reference closure and actual content hashes. Earlier files and receipts remain unchanged; a new export has a new identity. The schema's full interchange snapshots and the Python engine's compact run receipts are distinct serializations. The compact engine does not claim to populate every interchange field. The fourth schema example is a 60-entry curation fixture; it is not a completed empirical study.

The source adapter freezes the registry, exact source tokens and binding records into the knowledge manifest. It rechecks binding, vocabulary and token-content digests at each turn. Each used binding contributes its source anchor, original member identity, resolution path, operation and exposure records to the proposal. The original graph and all target identities remain explicit. Families never authorize interventions or confer evidence. The gate continues to use ELIGIBLE, BLOCKED and UNRESOLVED; Good and Evil are interpretive vocabulary.

Broader completion requires reviewed bindings for additional entries, source-language and translation alternatives, full-corpus anchor review where claimed, a complete interchange exporter if required, and independent outcome studies. A 60-entry inventory is not 60 validated generators.

## The seven moves

1. **Name.** Declare the whole, boundary, recipient, timescale, desired Fruit and burdens. The entry point can be a problem, component, idea, process, discipline, person, word or passage.
2. **Sow.** Apply the versioned reading method to word × dimension × layer combinations within a stored budget. Source preferences order search without establishing truth.
3. **Anchor.** Propose ordinary entities, processes, variables, typed ports and relations. Keep unresolved identities and alternative mappings explicit; a fit score cannot resolve an identity.
4. **Sift.** Apply the patent's evidence-kind, context, ancestry, independence, conflict and permission rules. Source text, formal derivation, simulation and experiment can support different claim classes. No single kind substitutes for every other kind.
5. **Weave.** Connect context-qualified expressions across layers or disciplines. A functional analogy does not transfer identity, causal effect, units or clinical efficacy.
6. **Mend.** Propose changes or measurement requests. Assess affected recipients, adverse alternatives, prerequisites and burdens. Every action-selection route passes the same eligibility gate.
7. **Harvest.** Commit predictions before the declared outcome-access phase; assess later evidence; preserve successes, failures and unresolved cases; append a successor WeightSet for future runs.

The workflow does not guarantee that every iteration improves performance. It records enough information to test whether a particular update improves held-out outcomes.

## Expression matrix and role definitions

An Expression binds a WordEntry to a context, layer and proposed referent. It can have several dimensions and typed input, output or state ports. Anchor state, claim support, health observations and predictions are separate fields.

| Dimension | Generation question | Status boundary |
| --- | --- | --- |
| D1 Material | What is it made of? | Empirical claims require appropriate identity and evidence |
| D2 Derived and related | What is derived from, associated with or produced alongside it? | Relationship and relevance must be checked separately |
| D3 Function | What role does it perform here? | Required role predicates must pass |
| D4 Information | What input, signal, instruction or retained state is involved? | Specify the carrier, recipient and measured endpoint |
| D5 Process | What verbs or transformations apply? | Proposed action and demonstrated process are distinct |
| D6 Relation | Who gives, receives, depends on or competes with whom? | Preserve participant identities and direction |
| D7 Measure | How could the proposition be distinguished from alternatives? | A proposed test is not a result |
| D8 Language | What do names, roots, aliases and naming history suggest? | Query seed for empirical mechanism claims |
| D9 Source passage | What words, roles and relationships occur in the passage? | Query seed for empirical mechanism claims |
| D10 Adverse expression | Could excess, wrong recipient or a competing process cause harm? | A harm hypothesis is distinct from observed harm |
| D11 Deep reading and Resolve | What alternate reading can be translated into a testable relationship? | Query seed for empirical mechanism claims |

D8, D9 and D11 may support a narrowly scoped statement about what a source says when properly sourced. They do not independently establish the proposed biological or physical mechanism. Their source records remain semantic cues after a later independent experiment supports a separate target proposition.

Layers include atomic, molecular, cellular, tissue or organ, organism, population or ecosystem, social or institutional, and computational or engineered. Layer names do not authorize cross-layer equivalence. Any verse word or phrase may be considered; only a finite selected set is processed in a run.

Heart means **response-forming priorities and context-dependent response selection or evaluation**. A safety threshold can be one use of a Heart-related record, but the independent authorization gate has its own rules. Roots means persistence with later functional availability. Tree means a declared branching organization; shape alone does not establish memory content.

## Deep reading and Resolve

The literal source, edition, speaker, surrounding context and negation remain available. The interpreter explores an alternate reading alongside that record and records who proposed it. The machine then seeks an ordinary target relation, process or measurement that would make the proposal testable.

1. **Interpret.** Record the alternate meaning and its source associations.
2. **Measure distance if available.** Record the metric, corpus, model and normalization. Unknown or out-of-vocabulary terms yield null distance, not a maximum score.
3. **Resolve.** Propose a target in a declared context, including the relation, mechanism question, alternatives, unresolved conditions and observable that could distinguish them.

An optional priority is `ResolveScore = distance × resolution_fit`. Both components are bounded and versioned; the product is an exploration score. Fit evaluates the proposed relation, not just the existence of a named molecule. Fit-only ranking and bounded distance bonuses are comparison policies. No distance value is supplied for the Exodus example until it has actually been computed under a recorded metric.

### Exodus example

ChristEye's interpretation of Exodus 20:18 links the trumpet to an announcement and seeing sound to making a signal observable. The generic operator is MAKE_OBSERVABLE: specified signal → proposed transduction or measurement → observable representation. Acoustic imaging is an example of a direction to investigate; sonification would instead convert data into sound.

A separately sourced biological example is visualization of gamma-H2AX foci in the DNA-damage response. This is known biological grounding, not a literal image of acoustic sound or a new cancer treatment. The question is whether a specified measurement improves a specified decision. p53-related outcomes depend on context and dynamics; the pathway is not represented as a universal single switch. The molecular facts must be in the allowed packet or obtained during a separately labeled later retrieval phase.

Spiritual interpretations remain attributed source material. They do not establish spiritual causation of cellular changes. A candidate without a measurable resolution can remain available as an unresolved interpretation rather than being discarded or silently promoted.

## ChristEye interpretation and inference operations

The optional expert-input stage can include a specialist trained in the framework's method of interpreting the bound ancient scriptural corpus. The corpus supplies the source material; the framework specifies how layered relationships are interpreted and applied. ExpertContribution retains source references, contributor identity, interpretation method and review status.

### Name decoding

A NamingRecord preserves the exact name and language, historical naming rationale where known, lexical associations, ChristEye's interpretation, and candidate properties, functions, relationships or capabilities inferred from the name. The engine may use these inferences to guide searches and propose observations, measurements or experiments. Each inference retains its interpretive provenance and evidence status, with subsequent findings recorded as supporting, narrowing or contradicting it. A name-derived inference may precede observation of the proposed capability; confirmation requires appropriate evidence.

| Example | Recorded interpretation | Separate question requiring evidence |
| --- | --- | --- |
| Stem | Root, trunk, origin and branching lineages | Which specified cells self-renew or differentiate in this context? |
| Crest | Crest → crown → king → king of hearts | Which functions belong to the identified neural crest population? |
| Astrocyte | Star-shaped name and ChristEye's inferred signaling associations | Which measured cell interactions or support functions are involved? |
| Arbitrium | Documented Latin naming rationale of decision; additional spiritual readings attributed separately | Which phage and bacterial host, signaling pathway and infection endpoint are involved? |

Neural-crest multipotency does not establish antiviral decoy production. Arbitrium research does not establish a human anger or anxiety mechanism. A decoy proposal must distinguish binding, capture, neutralization, productive infection and benefit to the intended host.

Interpretation provenance identifies ChristEye as the generator of interpretations and candidate inferences produced through ChristEye inquiry. Human contributions, review decisions and historical method development retain their actual attribution; an interpretation is not assigned to the inventor merely because he developed or operated the system. Recorded origin identifies the generating component or contributor where known, the method and source versions, and any subsequent human review.

### Association chains and composition

Each hop records its relation type: synonym, etymology, source association, metaphor or supported functional relation. Verbs, participant roles, direction and negation can also create operators. Multiple passages may bind into a ParablePattern or another typed graph template.

Search uses a versioned beam width, hop budget, emission budget, visited-state rule and stable tie-breaks. A local score plateau does not prove a global optimum. Products of hop weights in [0,1] cannot increase by extension alone, so partial paths are not rejected solely because that product falls. A run that exhausts its budget preserves its frontier and reports PARTIAL or BUDGET_EXHAUSTED.

### Adverse expressions and competing networks

The inventor's good/counterfeit vocabulary generates alternatives. The software records the intended beneficiary and other affected recipients before classifying an effect. Excess, deprivation, wrong recipient, resource competition and an opposing process are distinct hypotheses. A shared role does not make a molecule intrinsically good or harmful.

A HumanJudgment can select an interpretation, report a preference or request further evidence. It records the reviewer, rationale and uncertainty; null means abstention. Human confidence cannot satisfy a missing empirical predicate. The wheat-and-tares interpretation may suggest a discriminating observation, but it does not instruct the system to delay action despite an already established material hazard.

### Strengthening and coordinated changes

STRENGTHEN proposes a change to a specified capacity variable. Milk, Honey, Bread, Water and other roles can contribute distinct proposed mechanisms. More support is not presumed better: the proposal retains operating ranges, saturation, burdens and unintended recipients.

In engine v2.3, a source node means a node with no incoming parents in the current graph, regardless of its role name. STRENGTHEN multiplies that node's own deficit by 0.5. For a node with parents it instead multiplies its resilience coefficient by 0.5, reducing the inherited contribution without changing its own deficit. The planner and simulator share these authored assumptions; agreement between them is not independent validation. The factor 0.5 is a versioned modeling choice, not a measured biological or material law. Pin topology, parameters and code when comparing versions.

An InterventionBundle stores component candidates, ordering constraints and shared resources. Assess the bundle and its components through the same gate. Compare joint and component outcomes rather than assuming synergy. A candidate is a proposal; the machine does not itself authorize a medical intervention.

### Rooting and growth

| Framework stage | Proposed operational observation |
| --- | --- |
| Wind received | The input and its recipient are identified |
| Roots | A declared change remains after the initiating prompt or exposure ends |
| Supported growth | Performance develops under recorded support conditions |
| Fruit | The declared function is demonstrated under a specified assessment |
| Self-acting Wind | Useful output occurs without the tested prompt, while other continuing supports are recorded |

Each stage needs its own endpoint, interval, comparator and uncertainty. The sequence is a framework interpretation, not a universal developmental law. Behavioral retention does not alone identify an engram mechanism; a material retaining state does not establish human-like understanding. A temporary change can succeed when the goal is temporary.

### Heart redirection and four dimensions of benefit

The inventor describes the purpose poetically as seducing hearts to life. In the human-centered embodiment, the technical function is to support a voluntary change toward the person's chosen goal through understandable alternatives, informed choice and assessment of consequences. The broader dual purpose also includes encouraging the user's voluntary testing and refinement of target-system proposals. Target benefit and user participation remain separate endpoints.

Begin with the person's account of the situation and need. Anxiety or anger relief is one possible explanation, not a universal explanation of impulses. Record alternatives, the person's chosen support, immediate experience and later functioning separately. The inventor's principle of cultivating inward character applies first to his own conduct.

The phrase **pull from the relief, root the peace** is retained as the inventor's organizing idea. Its proposed operational meaning is to investigate what a response provides, offer participant-chosen support and assess whether benefit persists. Calm, goal-directed functioning and freedom to decline are evaluated separately. Compliance, quietness or attachment to the provider is not a success metric.

| Dimension | Question | Example measure |
| --- | --- | --- |
| Breadth | In which declared situations is the support useful? | Coverage of those situations, with failures retained |
| Length | How long does the reported benefit last? | Follow-up interval and recurrence record |
| Depth | Does the person report that the identified need was met? | Participant-defined rating plus relevant functional observations |
| Height | Does it help the person pursue their values and goals? | Progress against their chosen Fruit |

Ephesians 3:18 supplies breadth, length, height and depth as an interpretive source; width and breadth are alternative labels for one dimension. Applying these to the machine is the inventor's extension. Proverbs 31:30 and 1 Peter 3:3-4 inform his emphasis on inward character. The nurture/wisdom association with Song of Songs 4:5 is an attributed interpretation, not a biological claim or a claim of superiority of a sex.

For exploratory ranking, `SubstituteScore = Σ(weight × normalized dimension value)`, with nonnegative weights summing to one. The earlier 0.2 breadth, 0.2 length, 0.4 depth and 0.2 height example is an unvalidated preference. Store rationale and test alternatives. If a required value is unknown, the aggregate remains null; do not silently renormalize. Consent and required safety conditions are checked before ranking and cannot be outweighed by a score.

A NeedResponseRecord and FourDimensionAssessment retain the goal, consent scope, account of need, alternatives, predicted and observed outcomes, uncertainty and WeightSet. RootingAssessment records delayed assessment after prompting stops, continued support, confounds and unwanted dependence. The person can refuse, revise or withdraw; refusal ends the proposed activity. Deliberately creating distress, deception or dependency to gain influence is outside this embodiment.

The reported tobacco-to-vape substitution experience is an inventor anecdote, not a validation experiment, proof of this mechanism or a smoking-cessation recommendation. Relief and habit change are separate outcomes, and no treatment efficacy is asserted.

#### Search the heart and test the reins

The optional `christeye/heart.py` workflow implements ChristEye's interpretation of Jeremiah 17:9–10: search the heart, test the reins and judge according to the fruit. In this reading, Heart is the subject's centered response under impact, including the response to which they tend to return. References to an engram or mesh express the framework's hypothesis; this module does not measure neural storage or establish that interpretation biologically. Reins is an interpretive name for examining options, not a claim about the biological function of kidneys.

| Step | Inventor's source association | Operation in v2.6.1 |
| --- | --- | --- |
| Search the heart | chaqar; Jeremiah 17:10 | Record the person's own response, need, goal and account. Require literal affirmative consent, known nonwithdrawal and a session ID. No diagnosis is inferred. |
| Test the reins | bachan; Psalm 26:2 and Proverbs 17:3 | Assess all options, including the current habit. Preserve GENUINE, BAIT, MASKED, ATTACHING, UNSAFE, NOT_CHOSEN and UNRESOLVED verdicts. Bind passing assessments to the account and exact option contents. |
| Refine | tsaraf; Psalm 26:2 and Malachi 3:3 | Record proposed removal of harmful or unhelpful elements. Reset credit when the option changes. Require two distinct subsequent passing trials of the same structural revision for a provisional hold. |
| Speak to the heart | pathah; Hosea 2:14 | Offer currently chosen, permitted options after reassessment and complete four-dimension scoring, with recorded downsides and an explicit ability to decline. |
| According to the fruit | Jeremiah 17:10 and Hosea 2:15 | Examine delayed benefit after prompting stops together with progress toward the person's stated goal. Continued support or unknown dependence prevents a rooted classification. |

These are attributed reading associations supplied with the update, not newly verified lexical or theological conclusions. The two allurement readings distinguish immediate relief followed by decline (James 1:14–15) from a voluntary, truthful offer oriented toward the person's own goal (Hosea 2:14–15). The implementation labels refer to reported option behavior, not a person's moral worth.

**Provisional assay rules.** High relief is at least 0.5; delayed decline is below −0.05; low need coverage is below 0.4. These thresholds are unvalidated design choices. Known harm blocks an offer; known dependence or lost freedom also blocks. Safety, dependence, freedom and harm fields must be literal booleans. Normalized relief and need values must be finite numbers in [0, 1], and delayed change in [−1, 1]. Missing harm data are unresolved. A GENUINE record requires positive delayed change and need coverage of at least 0.4; low relief does not excuse a negative outcome. GENUINE means that the supplied record passes these rules, not established efficacy or causation.

**Authorization and offer identity.** `search_heart(account)` requires `consent_given=True`, `withdrawn=False` and a nonempty `session_id`. Subsequent `test_reins`, `refine`, `allure` and `judge_by_fruit` calls require a current authorization record. Account and authorization sessions must match where both are present. Offering also requires the option's own `chosen_by_participant=True` and its ID in the authorization's `chosen_options` list. Assessing a current habit does not authorize offering it. Duplicate option IDs are rejected. Changed option contents or a changed account require another assessment; incomplete ranking values are withheld. No code path invents participant choice or consent.

`decline(offer, authorization)` marks the caller-owned session withdrawn and clears chosen options. The application must own the authoritative current consent record, enforce withdrawal across copies and devices, and authenticate incoming reports. This compact Python library does not provide a secure consent service or detect a forged or stale copy supplied by a caller. `assay` and `method_audit` are offline calculations; neither grants permission to contact or act on anyone. Unknown risk remains unknown even when no downsides have yet been recorded.

**Revision and persistence.** Each refinement trial needs a distinct ID and the structural option revision derived from its ID and ordered elements. These identifiers assert traceability but do not authenticate the trial or establish independence. A trial that causes a dross removal cannot validate the revised option; two new passing trials are required. A changed safety or participant-choice record cannot be overwritten by favorable trial fields. ROOTED_PEACE requires delayed persistence, explicitly excluded dependence and continued support, and positive progress toward the participant's own goal. Nonpositive goal progress yields NO_BENEFIT; incomplete or invalid evidence yields UNRESOLVED. This is an operational label, not a diagnosis or a demonstrated neural mechanism.

**Audit and status.** `method_audit` checks supplied offer counts, verdicts and outcomes. A non-GENUINE offer fails the audit; missing records, unknown verdicts or an empty audit remain UNRESOLVED. A PASS applies only to the supplied records and cannot prove no unlogged offer occurred. Thirty-one heart-module checks pass within the full 151-check repaired release. `heart_demo.py` is explicitly synthetic and demonstrates assessment, offering, refusal and blocked retry. No human-subject data or treatment efficacy is claimed.

| Rising analogy | Heart workflow | Present status |
| --- | --- | --- |
| spoken | searched | Account recorded |
| lit | passed the reins | Provisional option classification |
| answered and holds_course | refined and holds | Two distinct matching-revision reports |
| named | ROOTED_PEACE | Goal-aligned persistence label |

This analogy does not promote an option into the Rising catalog. Heart-to-catalog registration and automatic garden use remain unimplemented. The uploaded v2.6 module sat outside its original garden freeze, which covered only its listed files. This reviewed release merges the earlier engine repairs and heart checks under a **new v2.6.1 commitment**; it does not extend the old v2.5 lock or make the known development cases independent.

### Parables and source preferences

| Source cue | Proposed graph pattern | Required limitation |
| --- | --- | --- |
| Sower | Input → receiving context → outcome | Test context effects; do not assume them |
| Mustard seed | Small initial state → later amplification | Bound the gain and adverse consequences |
| Leaven | Local process → wider propagation | Specify carrier, route and recipient |
| Wheat and tares | Competing explanations → discriminating outcome | Preserve established safety constraints |
| Talents | Use or non-use → later capacity | A hypothesis, not a universal use-it-or-lose-it law |
| Lost sheep | Search for a missing component | Multiple and joint faults remain possible |
| Wine and wineskins | Contents ↔ container compatibility | Validate actual interfaces and materials |

The inventor may assign a higher generation preference to words attributed to Jesus or to selected passages. This is recorded in the MethodProfile. It does not give a source a higher empirical evidence kind.

## Expert participation and method capture

The recorded reading method is central; live expert participation is optional. Contributors may include the inventor, an apprentice trained in his method, a biblical-language scholar, a domain specialist or an explicitly identified model. Each role addresses a different task. A degree alone does not demonstrate fidelity to this method, and spiritual standing is not a machine-verifiable qualification.

The inventor describes the depth sought as saint-level interpretation and regards identifying and training suitable interpreters as proposed proprietary know-how of We Develop Software LLC. This is his description of the desired contribution, not a verified spiritual rank or an established performance advantage. Detailed recruitment judgments and training notes can be access-controlled internal material. Sufficient operational rules and examples must still be documented for the software to run and for the claimed subject matter to be supported.

MethodProfile stores the versioned rules, source preferences, worked examples and review criteria. ExpertContribution stores contributor, role, source spans, interpretation, rationale, alternatives, uncertainty, method profile, review status and timing relative to commitment. A remembered phrase or theme can be matched to candidate passages for confirmation; knowing a verse number is unnecessary. Ambiguous matches remain ambiguous.

Capture examples of accepted and rejected readings, including why a promising association failed to resolve. Preserve the literal reading and context rather than deleting them. Apprentice agreement measures fidelity to the method; outcome tests measure utility. Neither agreement nor a credential alone establishes scientific accuracy.

A generally pretrained preacher-style model is an unsealed aid. A model trained from scratch on declared sources and annotations can be restricted in what data it was trained on, but those annotations may contain scientific knowledge or answers. Record their provenance, timing and task overlap. Fixed annotations allow deterministic replay even when the live process that produced them was human. Contributions arriving after a lock belong to a new snapshot or a labeled later assessment.

## Starter lexicon

Bread, Milk and Honey are filled across all eleven starter dimensions below; every entry is a seed for the Sow move, not a finding. Any word or phrase can supply a source-linked cue within a bounded run; the 60-entry foundation remains versioned. Entries below are candidate associations that require context-specific verification; they do not establish treatment effects.

### Bread, Milk and Honey across the eleven starter dimensions

| Dimension | Bread | Milk | Honey |
| --- | --- | --- | --- |
| D1 Material | Starch (amylose, amylopectin), gluten (gliadins, glutenins), yeast, maltose, arabinoxylan fiber, fortified folate, thiamine and iron | Caseins, whey proteins (β-lactoglobulin, α-lactalbumin, lactoferrin, immunoglobulins), lactose, milk-fat-globule membrane (MUC1), human milk oligosaccharides, calcium, potassium | Fructose, glucose, glucose oxidase (makes H₂O₂), methylglyoxal, bee defensin-1, polyphenols such as pinocembrin, low water activity, acidity |
| D2 Derived and related | Wheat germ agglutinin (a sugar-binding lectin), yeast β-glucan, ferulic acid, sourdough lactobacilli, CO₂ and ethanol from fermentation | Yogurt, cheese and kefir microbes, whey peptides, lactate (named from milk), the lactoperoxidase system | Pollen, propolis, beeswax, royal jelly (decides queen vs worker fate), melittin from bee venom, mead |
| D3 Function | Usable provision delivered to a function: substrate, building blocks, energy | Support and maintenance that sustain capacity over time | Guidance, selection, attraction, gating, stabilization |
| D4 Information | Knowledge consumed and acted on ("not by bread alone, but by every word"). In cells, nutrients are read as growth signals. To a learner, the lesson taken in and put to use | Candidate information-bearing support: separately investigate antibodies, signaling molecules and extracellular particles without assuming learned content transfer | Attractant and reward signals, receptor ligands, pheromones; a proposed communication or routing relation, to be checked against the specific organism and signal |
| D5 Process | Break (a candidate cleavage or separation operation), knead (network building by cross-links), rise (fermentation, amplification), bake (heat transformation), multiply (five loaves) | Nurse, let down (release on demand), curdle (coagulation), churn (separation), buffer (keeping a level steady, such as potassium in learning) | Gather, concentrate, convert (sucrose split into glucose and fructose), preserve, attract |
| D6 Relation | Companion (Latin com + panis: one who shares bread); astrocyte-to-neuron lactate supply; breadwinner | Mother to infant; host to helpful microbes (milk sugars feed Bifidobacteria); astrocyte to neuron | Flower and bee exchange; the hive's division of labor |
| D7 Measure | Iodine test for starch, protein assays, glucose and ATP assays, calorimetry | Ion concentration (mM K⁺), cell viability, ATP, lactate | Binding affinity (KD), receptor occupancy, selectivity ratio, peroxide assay, water activity |
| D8 Language | Old English *hlāfweard*, "loaf-keeper", became *lord*; *hlǣfdīge*, "loaf-kneader", became *lady* (who guards the provision?) | Latin *lac* (lactate, lactose); Greek *gala* (galaxy, galactose); *emulgere*, "to milk out", gave *emulsion* (keeping unlike things stably mixed); Hebrew *chalav* | Greek *meli* (mellifluous, melittin); Latin *mel*; Hebrew *devash* |
| D9 Scripture | Daily bread (Matt 6:11); bread of life (John 6:35); not by bread alone (Deut 8:3); five loaves multiplied (Matt 14:17–21); breaking of bread (Acts 2:42) | A land flowing with milk and honey (Exod 3:8): the pair itself; milk before solid food (1 Cor 3:2, Heb 5:12–14): support matched to stage | Sweeter than honey (Ps 19:10; 119:103): words as honey; honey from the lion's carcass (Judg 14:8): good drawn out of what was destroyed; Jonathan's eyes brightened (1 Sam 14:27): rapid restoration |
| D10 Shadow | "A little leaven leaveneth the whole lump" (1 Cor 5:6): a small seed spreading corruption, like misfolded-protein seeding; mold toxins; gluten in celiac disease; acrylamide from over-baking | Support that feeds the wrong thing (fertilizer that also feeds the weeds); spoilage; lactose intolerance; ion conditions outside the declared cell-specific operating range | Recipient-specific hazards requiring separate verification; lures and traps (bait that draws pests in); melittin tearing membranes; reward hijacking in addiction |
| D11 Deep reading | Provision as received knowledge; propose a declared input or resource relation | Nurture as sustained capacity; propose a support relation | Attraction or discernment as selection; propose a target-specific relation |

### The other framework words

| Word | Function (D3) | Material anchor (D1) | Language or scripture cue (D8, D9) | Shadow (D10) |
| --- | --- | --- | --- | --- |
| Soul | The specified whole under inquiry | The organism, cell, device or institution itself | "Man became a living soul" (Gen 2:7) | Loss of integrity or continuity |
| Marrow | Foundational structure or deep instruction | Bone marrow and its stem cells; DNA; source code | Latin *medulla*: medulla oblongata, adrenal medulla (core control sites); "joints and marrow" (Heb 4:12): discernment at the deepest layer | Corrupted instruction (mutation, bad code) |
| Water | Access, channel, solvent | H₂O, aquaporins, transport routes | *Hydro-*, *aqua*; living water (John 4:10–14) | Flood, drought, contamination |
| Lotus | Coordination and integration | The lotus effect: self-cleaning water-repellent leaf surfaces | Framework-specific label; source-word mapping depends on translation and context | Jammed or failed coordination |
| Tree | Branching organization with declared topology and context | A plant branch, anatomical arbor or graph, each separately identified | Tree of knowledge; vine and branches | Branching shape mistaken for evidence of memory |
| Roots | What persists and supports later use | Plant roots, root nodules, long-term memory traces | Latin *radix* (radical, radish); rooted and grounded (Eph 3:17) | Root rot; entrenched disease |
| Wind | Expressed activity, flow | Airflow, breath, ion flux, neural firing | Greek *pneuma* and Hebrew *ruach* have context-dependent wind, breath or spirit senses; an individual occurrence need not express all senses (John 3:8) | Storm; uncontrolled discharge such as a seizure |
| Soil | The receiving context | Soil microbiome, tissue environment, market | Parable of the sower (Matt 13:3–8) | Hostile or barren context |
| Flesh | Material realization | Cells, tissues, hardware | The Word made flesh (John 1:14) | Decay |
| Mesh | Typed relationships among parts | Fishing nets, extracellular matrix, networks | Nets breaking under the catch (Luke 5:6): capacity limits | Tangling, broken links |
| Template | Organization that constrains responses | DNA template strand, molds, learned models | Potter and clay (Jer 18:1–6) | A rigid or wrong template |
| Heart | Response-forming priorities and context-dependent response selection | Separately identified response mechanisms and evaluation policies | "Out of it are the issues of life" (Prov 4:23) | Hardening; failed safety |
| Fruit | The real outcome | Endpoints you can measure | "By their fruits ye shall know them" (Matt 7:16) | Bad fruit: harm passed off as benefit |

### Further cue vocabulary beyond the 60 entries

- **Salt**: preservation and ion balance; salt that loses its savor (Matt 5:13).
- **Oil**: lipids, membranes, lubrication; anointing as marking for a purpose.
- **Leaven**: amplification and fermentation in light; spreading corruption in shadow.
- **Vine and branches**: branched connection (John 15:5); ties straight into your Tree/Branch/Spine hypothesis.
- **Wine and wineskins**: transformation, and container compatibility (Mark 2:22) as a cue for delivery vehicles.
- **Fire and Stone**: possible refining and stable-structure cues. Light and Blood are already in CE60.

## Physical exemplars and board capture

Physical objects can make a question concrete. Their use mode determines what they can support; a token is not a measurement of another system. The kit has three common uses:

1. **Reference standard.** A known object serves as the positive control. A potato is the classic starch reference: iodine turns its cut surface blue-black. An unknown sample requires a controlled identification procedure and an appropriate decision rule; resemblance alone is insufficient.
2. **Analog model.** The object's behavior models the system's behavior. Yeast inflating a balloon is Leaven and Wind made visible: a small input amplified into measurable output.
3. **Sorting token.** On a tabletop board, objects and cards are placed into word zones, and one object can sit in two zones at once. The physical layout becomes the Expression Matrix for that system.

### Starter kit

| Object | Main constituents | Words it anchors | Illustrative observation or demonstration | What it teaches |
| --- | --- | --- | --- | --- |
| Potato | Starch (amylose and amylopectin), water | Bread (stored provision), Bread and an explicitly labeled storage analogy; a potato tuber is not a root | Iodine on a cut slice turns blue-black; a slice in salt water goes limp, in fresh water stays firm | Identifying starch; stored provision; Water and Salt moving across a boundary |
| Dry beans (kidney, navy, soy) | Storage proteins, starch, fiber, lectins such as phytohemagglutinin | Bread (protein provision), Honey (lectins bind sugars: recognition), Seed and Template (dormant program), Shadow | Use a prepared teaching specimen or image; do not taste experimental materials | One object plays several words; the same molecule can be Honey or Shadow depending on preparation |
| Bean plant root nodules | Rhizobia bacteria fixing nitrogen for the plant | Soil, Milk, Roots, relation | Dig up a pea or bean plant and look for pink nodules | Mutualism: support exchanged between two living systems |
| Wheat flour and dough | Gluten proteins, starch | Bread, Mesh | Rinse a dough ball under water; the starch washes out and a stretchy gluten network remains | A network (Mesh) built by kneading; separating material from structure |
| Yeast, sugar, warm water, balloon | Living yeast, sugar, CO₂ | Leaven, Wind, the Bread → Wind chain | Balloon on the bottle neck inflates; measure its circumference every 10 minutes | Amplification; expressed activity you can put a number on |
| Milk and vinegar | Casein, whey, acid | Milk (curdle, separate) | Acid makes casein curds separate from whey | Support has parts that can be separated and tested one at a time |
| Oil, water, egg yolk | Lipids, water, lecithin | Milk as emulsion (*emulgere*), Oil | Shake oil and water (they part); add yolk (they stay mixed) | A mediator keeps unlike things together |
| Honey and sugar water | Concentrated sugars, low water activity | Honey (preserve, stabilize) | Leave both out for a week; the sugar water spoils first | Stabilization as a Honey function |
| Celery stalk in colored water | Xylem vessels | Water (channel, route) | Dye climbs the stalk within hours | Routing: where a channel carries things |
| String or net | Knots and links | Mesh, Weave | Tie objects on the board together | Cross-links between expressions |

### The sorting board

Use a large mat with one zone per word (Soul in the center, Fruit at the edge) and colored tokens or sticky dots for the eleven starter dimensions. For a system under study:

1. Write each component on a card, or use the exemplar object itself.
2. Place it in every word zone it might belong to, with a dimension dot on each placement.
3. Run string between placements that are the same thing in two zones, or the same word at two layers.
4. Photograph the board. Each placement becomes an Expression record in the software, and each string becomes a CrossLink (schema below).

The board is a thinking and teaching tool. Real identification in a lab still uses real assays, and nothing from the kit is eaten or swallowed during demonstrations (iodine and raw kidney beans especially).

## Data schema and invariants

The machine-readable contract is `ChristEye_Simple_Machine_Schema_v1.9.json`, a JSON Schema 2020-12 document. It extends the earlier record model instead of replacing the patent's evidence gate. All identifiers are versioned; earlier snapshots remain immutable.

| Record family | Purpose |
| --- | --- |
| TextEdition, ManuscriptWitness, SourceLexeme, OccurrenceAnchor | Exact source identities, distinct anchor kinds and textual variants |
| TranslationAlignment, FrameworkEntry, FrameworkVocabulary, FrameworkBinding | Translation correspondence, versioned CE60 registry and operational generation bindings |
| Source, Dimension, WordEntry, Referent, Context | Ordinary identities, roles, source material and scope |
| Exemplar, Expression, Relation, Operator | Physical uses, typed ports, proposed relations and bounded generation |
| NamingRecord, InterpretationPath, ResolveRecord, ParablePattern | Name history, typed associations, interpretation and resolution |
| MethodProfile, ExpertContribution, HumanJudgment | Method fidelity, attributed expert input and unresolved judgment |
| NeedResponseRecord, FourDimensionAssessment, RootingAssessment | Voluntary response goals, four dimensions and delayed assessment |
| AdverseEffect, InterventionBundle | Affected recipients, adverse alternatives and coordinated candidates |
| KnowledgeManifest, ExecutionProfile, WeightSet | Declared sources, reproducible computation and immutable weights |
| GenerationSnapshot, CommitmentRecord, ReplayVerification | Committed generation state, receipt status and bounded replay result |
| Prediction, Assessment, YieldRecord | Forecasts, later outcomes and separate success/failure counts |
| EvidenceEnvelope, Decision, LineageLink, Event, BoardSnapshot | Evidence kinds, scoped decisions, distinct parent relations and audit state |

`SystemRecord` in the patent is represented by a system Referent and Context records. `CrossLink` maps to Relation; `Lever` maps to Candidate; `RootingCheck` maps to RootingAssessment. `EvidenceEnvelope` is an interchange wrapper for a native patent EvidenceObject, not a replacement evidence ontology.

Schema shape validation checks fields and selected state constraints. Runtime validation must additionally check reference existence, port compatibility, graph cycles, actual digest values, commitment chronology, access boundaries, evidence ancestry and the full support policy. A valid JSON object is not proof of an observation or compliance.

Required behavior includes: unresolved identities remain unresolved; semantic cues cannot become empirical supporting evidence through confidence; every required support predicate must pass; generating parents and required supporting parents are distinguished; rejected inputs and contradictions remain auditable; all candidate-selection routes use the common gate; new evidence and weights append versions; all failures and abstentions remain in denominators.

## Worked examples

### Software access example

Bread represents a proposed document provision and Water an authorized access route. An Expression has an access input port; the route has a compatible output port. If access is unknown, an Operator emits a diagnostic question distinguishing document absence, route failure and authorization mismatch. It does not disable access controls. A potato token may suggest a starch query, but that query lacks a demonstrated relation to the software goal and remains unresolved. This example is encoded as a DESIGN_EXAMPLE fixture in the schema.

### Heart response example

A person chooses a goal of responding more calmly to work interruptions. They report a need and choose which support options, if any, to investigate. The system stores alternatives, expected and observed outcomes separately. Breadth concerns the declared interruption situations; length concerns duration of benefit; depth records the person's assessment of need fulfillment; height concerns progress toward their chosen goal. A delayed assessment records continued support and functioning after prompting ends. No successful result or neural mechanism is asserted by this example.

### Garden or service transfer

Support, access and selection can organize a garden or a software service, but role similarity alone diagnoses neither. A service memory increase could reflect a leak, a bounded cache or workload; a garden outcome could have several interacting causes. Record competing explanations and controls appropriate to the actual system. A chain supplied by the author is a model assumption, not a discovered causal order.

### Molecular solar thermal storage example

The authored target is visible-light charging of norbornadiene/quadricyclane (NBD/QC), storage and later heat release. Wang et al. (2024), DOI [10.1039/d4tc03513e](https://doi.org/10.1039/d4tc03513e), already demonstrated upconversion-driven NBD/QC photoswitching in bilayer polymer films. Their particular films had an upconversion quantum yield of 1.9 ± 0.1% in air, a reported upconversion threshold of 2 W/cm² under 532 nm excitation, and a QC half-life of 3.8 hours at 25 °C. Photoswitching was demonstrated at 1 W/cm²; the threshold is not an absolute minimum for conversion. The 2 W/cm² value equals 20 kW/m² of monochromatic irradiance, not a spectrum-equivalent sunlight concentration. These published values are context for an inquiry, not machine predictions or evidence of a new generator.

| Node | Role | Label | Authored deficit |
| --- | --- | --- | ---: |
| light_in | Bread | sunlight input | 0.50 |
| transfer | Water | energy transfer channel | 0.80 |
| storage | Roots | storage persistence | 0.60 |
| release | Wind | heat output | 0.10 |
| fruit | Fruit | delivered outcome | 0.05 |
| selectivity | Honey | triplet selectivity (side → transfer) | 0.30 |
| dyes | Milk | dye stability (side → transfer) | 0.40 |
| matrix | Soil | host matrix (side → storage) | 0.30 |

The main path follows the first five rows. Its edge weights are 0.6; side edges are 0.5. The declared fault is transfer. Deficits, burdens and the graph are author inputs to a simulator. The packet marks these simulated node values available, but they are not laboratory measurements. The shadow on light_in represents possible heating and bleaching; adverse effects remain unknown to the gate.

Five recorded assistant readings use Jeremiah 32:14, Daniel 2:43, Exodus 3:2, Matthew 25:4 and Leviticus 24:2. They suggest retention, incompatible mixing, sustaining a sensitizer, separating store and channel, and continuous provision. Mark 2:22 appears in an extension-rule note, not as a sixth supplied reading. These are attributed assistant interpretations, not the inventor's reviewed MethodProfile, and remain QUERY_SEED inputs. They do not validate spiritual causation or photochemical performance.

The earlier v2.2 compiler lacked a direct channel rule and container rules. Its access proposal could point back to an upstream recipient, which the acyclic estimator blocked. Its STRENGTHEN action on a source node changed no inherited contribution. Those are software-model limitations addressed by v2.3, not failed laboratory interventions.

The v2.3 four-condition case was rerun with the supplied ESV YES2 file and repeated. The parser returned 31,103 passages; SHA-256 was `62f9c6144631d2169e9a13d556e7f7378080eab091ca5e8c872f5e79440690b5`. TARGETED scan, flow 1.0, seed 17, maximum 4,096 cues, 64 evaluations and 10 output packets were held fixed. The real stream returned 2,916 cues and evaluated 16 candidates; the shuffled stream returned 3,224 cues and evaluated 15. Zero flow scanned nothing and produced no proposals. Five assistant readings evaluated 15 candidates. All four receipt chains verified and the repeated run reproduced its artifacts.

| Proposal | Gate/selection result | Conditional gain range | Conditions |
| --- | --- | --- | --- |
| STRENGTHEN storage | PROPOSED_FOR_TEST | 0.0186–0.0861 | Real, shuffled, assistant |
| STRENGTHEN storage + SUPPLY transfer | PROPOSED_FOR_TEST | 0.0261–0.1106 | Real and shuffled |
| SUPPLY transfer | PROPOSED_FOR_TEST | 0.0150–0.0490 | Real, shuffled, assistant |
| STRENGTHEN storage + SUPPLY matrix | PROPOSED_FOR_TEST | 0.0227–0.1050 | Real-stream output |
| SUPPLY matrix alone | BELOW_THRESHOLD | 0.0082–0.0378 | Evaluated, not a qualifying single action |
| STRENGTHEN dyes alone | BELOW_THRESHOLD | 0.0013–0.0099 | Evaluated, not a qualifying single action |
| SUPPLY light_in | UNRESOLVED | Not estimated | Requires adverse-effect measurement |

These are dimensionless changes in the authored outcome score over the estimator's parameter range, not confidence intervals, conversion efficiencies, watts or experimentally predicted gains. The real and shuffled streams share the top two output proposals and their estimates, and the common single-action estimates. Lower-ranked bundles and lineage differ. The assistant condition does not emit every stream bundle. This comparison establishes executable cue participation; it does not show an advantage from passage meaning or order. Cue provenance and deterministic enumeration can affect which bundles fit the budget.

A molecularly imprinted host, an improved upconverter–switch interface and oxygen exclusion are possible human follow-up interpretations of the generic actions. The engine does not generate a particular chemical structure, identify a validated formulation or demonstrate power output. Such hypotheses require separate feasibility, prior-art and laboratory assessment. The published bilayer approach must not be represented as newly discovered by this run.

The case wrapper stores inputs and proposals, but does not pass the full scan metadata into its generation context, and its execution fingerprint excludes `cases/most_storage_case.py`. Retaining the exact corpus and rerunning this wrapper establishes reproducibility of the retained files, not complete exposure closure or proof that outside knowledge was absent. A future committed study must include the wrapper, complete scan record and environment in its dependency closure. ESV text is not reproduced in these documents; private replay inputs contain source passages and are not part of the document deliverables.

## Deterministic scoring and repeated assessment

All numerical values are associated with a policy version and a defined meaning. Weights below are illustrative. Ranking, identity resolution, evidence support and authorization remain different operations.

### Matching and fit

Lookup may distinguish exact entries, curated synonyms, sourced roots and restricted-model similarity. Record every candidate match and ambiguity rather than silently replacing a failed match with a supplied role. A NamingRecord or source preference may prioritize exploration but cannot certify a function.

The historical pilot used `F = min(cap, 0.25*m + 0.30*p + 0.20*a + 0.25*v)`. This is retained as an exploratory ranking example. It cannot establish anchor state: with a failed role predicate the other terms can still produce 0.70; with no anchor they can produce 0.80. Required identity and role checks are independent gates. Evidence-kind numbers are not interchangeable measures of scientific quality and never replace conclusion-permission sets.

### Observations and predictions

Missing health is null. A context-specific normalization may map observations into a declared range, but its direction, tolerance and clipping must be explicit. Adverse consequences are recorded separately; a negative number does not universally mean that removal is the right action.

ObservedHealth, InferredState and PredictedState remain distinct. If several expressions represent the same underlying observation, deduplicate before aggregation. With one eligible observation, `sum(F*H)/sum(F)` equals H, so that calculation cannot establish a contribution from lexical weighting.

Propagation computes a model prediction, not a new measurement. The chain walk uses observed node values and explicit unknowns rather than an additional neighborhood-smoothed score. In the pilot, even the observed node values can contain upstream effects from the simulator; they are not isolated intrinsic causal health. Dependency graphs may include cycles, alternative paths and joint failures.

### Eligibility and priority

Every candidate passes the same required context, permission, recipient, adverse-effect and authorization checks. A score does not compensate for a failed check. Unknown risk stays unknown and follows a declared measurement or abstention rule. If all actions fail, the engine emits a gap or PromotionRequirement.

One optional priority combines predicted benefit, burden, uncertainty, reach and prior independently assessed yield. Store each component. The former `(dFruit*P*R*(1-S))/(B+0.1)` formula is an exploratory policy, not an authorization rule. In particular, absence of an anchored shadow does not establish zero risk.

Bundles preserve constituent actions and interactions. A direct chain selection cannot skip the gate used by priority selection. Committing a proposal does not itself authorize execution in the real world.

### Predict assess and update

1. Record endpoint predictions, alternatives, adverse outcomes, test design and complete generation state.
2. Persist the commitment before the declared outcome-access phase.
3. Admit later observations as new EvidenceObjects with context and provenance.
4. Evaluate the declared error metric and separate beneficial, harmful, null and unresolved outcomes. Use Brier scores only for suitable probability predictions of binary outcomes.
5. Append a successor WeightSet under a recorded update rule; keep fixed-weight and held-out comparisons.
6. Stop on goal completion, no actionable path, unresolved material conditions, budget exhaustion, cancellation or awaiting evidence. Preserve the frontier on partial runs.

The pilot's documented and signed update rules are experimental alternatives. Neither is presented as a validated learning rule. For yield learning, gate acceptance, textual agreement, immediate relief and independent useful outcomes are counted separately. Shared ancestry cannot be excused by a fractional discount when independence is required. Source-author overlap alone is not equivalent to reuse of the same experiment.

## Proposed adaptive source selection and flow control

This optional controller turns the source stream into a bounded input to the existing reading method. The current inquiry graph determines what to search; later assessed outcomes determine which exploration regimes receive future work. The controller is proposed. The supplied YES2 stream branch implements a narrower co-occurrence experiment, described separately below.

### Triggers and modes

Create a RetrievalRequest from a GapRecord, a native patent PromotionRequirement, or an explicit improvement objective. Capture context, target nodes and relations, aliases, functional-role predicates, layers, neighboring relations, missing endpoints, graph digest and WeightSet version. A low measured value, an uncertain relation and a blocked action are different conditions; none alone identifies the cause.

| Mode | Entry condition | Bounded behavior |
| --- | --- | --- |
| TRICKLE | Declared continuous exploration allocation | Inspect successive passages and preserve context |
| TARGETED | A defined gap or improvement request | Rank permitted passages against graph and role features |
| STALL_SCAN | A stored number of turns without a qualifying proposal or measured progress | Expand the scan under separate reading and work caps |

Store trigger thresholds and precedence. An illustrative precedence is STALL_SCAN, then TARGETED, then TRICKLE. Material authorization failure, exhausted work or cancellation overrides selection. Retrieval may investigate why an action is blocked; it cannot make that action eligible by increasing a score.

### Sources and interpretation

StreamSource reuses Source and KnowledgeManifest. Store immutable bytes and digest, edition and rights, adapter and normalizer versions, passage ordering, segmentation-map digest and index digest where used. StreamCursor retains the next position, context, consumed spans, unfinished positions and exhaustion status. Parse EPUB in its declared publication reading order; YES2 is a separate adapter. Use verse identifiers only when supplied by structure or a versioned map. Otherwise use paragraphs or exact byte spans. Do not guess verse boundaries from appearance.

Keep source text inert: no embedded-script execution, remote-link fetching or passage instructions treated as control commands. Preserve literal wording, negation, participants and neighboring context for interpretation even if a retrieval index discards stopwords. A keyword co-occurrence model cannot by itself recover those relationships. A licensed source can remain private while an audit stores source digests and locators; authorized replay still requires access to the exact source or an adequately specified retained representation. An omitted corpus prevents full independent source replay.

One ranking embodiment uses a normalized weighted sum of lexical match, functional role, context, unresolved-need relevance and novelty relative to earlier proposals. Store each feature, minimum required feature set and the WeightSet. Unknown features stay null and can leave ranking unresolved. Stable source/position IDs break ties. Optional sampling stores the candidate pool and pseudorandom state. Ranking does not certify identity, causal direction or evidentiary support.

Apply the recorded D8/D9/D11, association, parable and other operators to selected spans. Generate hypothetical relations, bounded candidate actions, bundles or measurement requests. Preserve alternatives and route every proposed action through the common gate. The estimator uses hypothetical graph changes separately from admitted relations. A high score can justify a next investigation; it cannot turn a passage into empirical evidence. Your layered reading method remains central to the preferred ChristEye embodiment; no general-purpose language model is required.

### Work allocation and a concrete deterministic policy

Define `allocation_basis_points` as the share of **assigned candidate-evaluation slots**, from 0 through 10000. This differs from the supplied stream experiment's fraction of the corpus scanned. Store both quantities separately when needed. Record all source reading, indexing, parsing, proposal generation, evaluation and operation costs; a smaller output quota does not make a full-corpus scan free.

For assigned slots `B`, allocation `f` and remainder `r`, use:

```text
planned_stream_slots, remainder_after = divmod(B * f + r, 10000)
```

Carry the remainder by context and regime. With 20 slots, 1500 basis points and remainder zero, the stream receives three slots. A zero allocation receives none. Preserve unused quota; reassign it to ordinary generation only under a declared fallback rule. Rejected and duplicate proposals still consume their applicable proposal/operation counters. Maintain independent ceilings on bytes, passages, proposals, graph expansions and total operations.

One implementable allocation rule is:

1. At an episode boundary, compute eligible regimes from the stored trigger predicates and context class. A regime specifies mode and allocation. The example allocations 0%, 5%, 15% and 30% are test settings, not recommended optima.
2. Give under-sampled eligible regimes round-robin opportunities subject to a maximum outstanding-episode cap. Do not keep allocating to a regime indefinitely merely because it has no matured feedback. If no regime is eligible, record why and stop or await evidence.
3. After each eligible regime has the declared minimum matured cohort, choose the largest confirmed useful yield except on every Kth decision, which reserves round-robin exploration. Store K, the minimum, regime order, ties and cohort rules; K=5 and a minimum of two episodes are illustrative fixtures, not a statistical sufficiency claim.
4. Hold the chosen FlowDecision fixed for the episode. Read, interpret, deduplicate, gate and estimate within all budgets. Persist the complete snapshot before the declared outcome-access phase. An episode may end with no candidates; commit its gap, counters and stop reason instead of inventing a proposal.
5. Review later feedback only at declared policy boundaries. Append a successor FlowPolicy referencing the earlier policy and the exact StreamYield summaries used. Never change the generating decision or a locked prediction.

For a declared task/budget class, a matured cohort includes all episodes assigned under the fixed sampling rule whose common follow-up horizon has elapsed. Its score is **unique independently useful outcomes confirmed by the cutoff divided by all assigned evaluation slots** in those episodes. Include zero-output and unresolved episodes in the assigned denominator. Before the horizon, the episode is pending and its yield is null. At the horizon, absent assessments remain unresolved, with zero confirmed successes; that is a time-bounded lower-bound yield, not a declaration of failure. Report resolution coverage and follow-up duration beside yield. Late evidence creates a successor summary without erasing the earlier cutoff.

Required independence and adverse-effect checks constrain eligibility; benefit does not compensate for a failed check. Count each underlying candidate/outcome origin group once. Preserve dependent, adverse, null, unresolved and pending statuses. A declared harm rule can suspend a regime. Independent-useful credit requires qualifying empirical evidence and verified origin checks; synthetic feedback can calibrate an estimator under a separate policy but earns no independent-useful credit.

Credit the FlowPolicy and FlowDecision that generated a candidate, even if a different policy is active when the outcome arrives. Jointly generated proposals keep all source parents; one successful result does not demonstrate an independent contribution from each passage. An episode-level regime comparison evaluates that policy bundle, not a causal attribution to scripture or any individual operator. Fast control using duplicate rates, latency or gate acceptance must be labeled operational adaptation separately from outcome-based learning.

### Stream records

| Record | Binding and purpose |
| --- | --- |
| StreamSource | Source and manifest references, digest, edition, parser, segmentation, index and rights |
| StreamCursor | Reading position, context, consumed spans, frontier and exhaustion |
| RetrievalRequest | Graph digest, gap, context, roles, target relations and reading/work caps |
| ExposureEvent | Exact span, cursor versions, selection features, interpretation operators and candidate links |
| FlowPolicy | Versioned regimes, triggers, update rule, cohort definition, pending cap and safety constraints |
| FlowDecision | Choice made before generation, eligible context, prior summaries and ordered events |
| StreamEpisode | Assigned and actual work, quota/remainders, exposures, candidates, snapshot and horizon |
| StreamYield | Generating policy, cutoff, deduplicated outcome groups, provenance and cost |

FlowRegime is an embedded configuration record. Candidate references the FlowDecision and ExposureEvents. GenerationSnapshot references the stream sources, decisions and episodes in addition to its existing inputs. SourceSpan, Assessment, GapRecord, YieldRecord and LineageLink retain their earlier meanings. Native PromotionRequirement IDs are external references whose existence is checked by the runtime; the schema does not invent a second promotion engine.

An instruction packet is an existing Candidate/Prediction view identifying what to investigate, its hypothetical effect, unresolved conditions and a discriminating check. The peptide analogy is descriptive of software messaging, not a biological mechanism or a treatment instruction.

### Knowledge epochs and replay

Selecting another passage from a corpus already in the manifest stays within that declared source boundary. New source bytes, revised annotations or another edition start a successor knowledge snapshot. Open-network access is recorded and cannot be relabeled as part of the earlier restricted run. A hashed corpus may contain the answer; source restriction alone does not prove otherwise.

Replay binds source and parser/index versions, cursors and context, request, selected regime, initial policy, integer quota remainders, source exposure, hypothetical relations, candidates, ordered prior assessments and random state if used. Preserve event ingestion order. Exclude a digest's own field and receipt from its hash payload under a named canonicalization rule. Runtime validation recomputes hashes and resolves referenced content. Local hash chains establish consistency, not an independently trusted time.

Stop on goal completion, no actionable path, unresolved material conditions, source exhaustion, budget exhaustion, cancellation or awaiting evidence. A wall-clock interruption is PARTIAL and preserves its frontier. Exhausting one source does not prove there is no solution.

### Schema migration and implementation acceptance

Version 1.2 adds eight top-level stream collections. A v1.1 record is migrated into a new version with empty stream collections, null candidate flow references and empty exposure lists when no stream was used. Existing committed bytes and digests remain intact in their original version; migrated snapshots get new IDs and recomputed digests. Never backfill inferred stream activity or treat legacy corpus coverage as candidate-work allocation. Embedded fixtures are newly authored design examples, not migrated experimental commitments.

The schema permits empty candidate/prediction lists in a GenerationSnapshot so no-output runs can be committed. Shape checks do not enforce chronology, cross-record bounds, finite arithmetic, exact digests, independence or empirical truth. Runtime checks must validate every reference and version, actual cursor bounds, quota arithmetic, all work counters, deduplicated outcome counts and attribution to the generating decision. Reject NaN and infinity at input and computation. Preserve all plausible identity candidates for adjudication.

Acceptance requires: zero-flow and small-quota behavior; missing/empty/malformed sources; correct segmentation and context; explicit EOF/restart behavior; inert scripts and links; candidate and operation caps; no gate bypass; zero-candidate commitment; exact replay under fixed and adaptive policies; delayed and out-of-order feedback; repeated-origin exclusion; pending-cap and insufficient-feedback behavior; successor immutability; and regressions against all v2.1 fixes. Tests of these records are not a substitute for a real held-out yield study.

## Restricted knowledge and replay

KnowledgeManifest lists source versions, packet, lexicon, rules and model assets. ExecutionProfile fixes runtime and dependencies, arithmetic, rounding, operation order, locale, serialization, random state, tie-breaks and integer operation budgets. The ordered prior-learning history and initial WeightSet are inputs. A wall-clock interruption produces PARTIAL status rather than a claim of repeatable exhaustion.

In a restricted run, the generator receives a read-only input view and cannot access the evaluator's key, post-lock observations or undeclared tools. Actual access controls and logs must establish that boundary. The full input is preserved for audit. A typed gap record marks unmapped or rejected items; validation can still discover contradictions or missing coverage rather than making inconvenient information disappear.

The generation snapshot binds admitted inputs, rejected-input gaps, sources, code, execution profile, weights, interpretation paths, candidate content and predictions. A separate commitment receipt records when the content was committed. For a simulated benchmark, commit the full truth-generating configuration and scoring policy, not just fault names. Later evidence and updated weights never overwrite the original prediction.

A digest proves integrity of specified bytes. A replay establishes reproducibility under its tested profile. Neither alone proves absence of answers, author ignorance, a trustworthy time, isolation or a new discovery. Human annotations, dictionaries and examples may already encode an answer. Restricted model training requires a corpus and task-leakage audit in addition to a manifest.

## Historical v1 pilot results and limitations

The historical v1 Python pilot has 20 authored templates and 50 cases per template, with one planted fault in each case. Both learning-rule configurations were rerun twice; the result files matched the supplied files byte for byte in the review environment. The results below use the signed-rule configuration unless otherwise stated.

| Metric | Verified result | Denominator or scope |
| --- | --- | --- |
| Chain identifies planted fault | 95.1% | 834 cases with measured fault location |
| Correct root-directed action | 54.8% | All 1,000 cases |
| Correct root-directed action when acting | 87.8% | 624 actions; 376 measurement requests |
| Mean five-cycle change | +0.1256 | Chain method |
| Mean five-cycle change | -0.0617 | Always-supply anomaly baseline |
| Mean difference | +0.1873 | Same synthetic cases; descriptive comparison |
| Templates with positive machine change | 20 of 20 | Template means |
| Templates with negative baseline change | 14 of 20 | Template means |
| Shadow traps with priority penalty | 5.7% | Priority method |
| Shadow traps without priority penalty | 13.7% | Priority-method ablation |
| Cue records excluded from health scoring | 2,000 | Fixed D8/D9 seeds per configuration |
| Neutral role renaming | Identical results in 1,000 cases | Structure and meanings retained |

The outcome score can fall below zero; it is not strictly a 0–1 scale. The reviewed package does not contain a reproduced confidence-interval procedure for the earlier 0.17–0.21 interval, so that interval is not carried forward as a verified result.

The synthetic simulator and planner share structural assumptions. Roles and order are supplied; faults are single-location; the always-supply comparator cannot reduce an excess or request measurements. Role-name substitution tests renaming a supplied graph, not whether the reading method constructs better graphs or interventions. Each measured node has one eligible expression, so its fit weight cancels in the health average.

The pilot's unmatched-label fallback is counted as quarantined but can remain anchored and enter scoring. Direct chain actions can bypass the shadow penalty. The answer-key digest is computed before the loop but written afterward and binds only fault locations and types. There is no independently verified commitment receipt or knowledge-isolation boundary. The 2,000 fixed cues exercise exclusion from scoring, not the full evidence gate.

D11, verse composition, parable matching, expert participation, Heart assessment, full lineage checks and the intended restricted execution mode were not tested by this pilot. The new schema is a validated data contract, not an implementation of those mechanisms. The code is preserved as supplied; this document corrects the intended design rather than retroactively claiming the pilot implemented it.

### Integrity references

- Pilot key object digest: `f966d4bb08f887adde87d618c389973a09ced523cfafa64f78d77bafbd5389cc`.
- Documented-rule result object digest: `90d47b6295883c08a86541281a8090a9e3e52fa7f7cd2070c63c7d598d633e62`.
- Signed-rule result object digest: `81e155d42fd5718161ac673ad3d82a429aca3ea4b8f4a8f7072f37ea4f250412`.

These identify the pilot's serialized objects; they are not full experimental commitments or independent timestamps.

## Subsequent prototype and source stream records

These are distinct branches. Do not combine their test counts or retrofit later repairs into earlier results.

| Component or branch | Verified or inspected scope | Remaining limit |
| --- | --- | --- |
| Repaired v2.1 | Recorded 47 passing checks; cue-to-proposal demo; 1,000-case legacy simulator replay | Authored graph and cases; no adaptive source controller |
| Supplied v2 stream branch | 19 tests rerun and passed; stored source experiment inspected; code fingerprints and local receipts consistent | Earlier v2 gate/provenance/immutability code remains |
| Supplied stream simulator | Reproduced 1,000-case outputs using the committed real/shuffled suggestions | Does not rederive suggestions from the absent ESV corpus |
| Adaptive fixed-work controller | Disclosure and schema examples in v1.2 | Not implemented or empirically tested by this revision |

The v2.1 authored demo emits five first-turn packets with cues and zero with an explicitly empty cue list. This checks participation of cues in that software path, not superior idea quality. Its normalization and acyclic estimator are limited examples.

The separate source experiment uses 142 labels from the same 20 author-defined system templates and fixed author-written role-word lists. The stored counts are:

| Measure | Lexicon only | Lexicon then real stream | Lexicon then shuffled stream |
| --- | ---: | ---: | ---: |
| Correct labels out of 142 | 114 (80.28%) | 121 (85.21%) | 118 (83.10%) |
| Correct top suggestions among 25 lexicon abstentions | 0 | 7 (28%) | 4 (16%) |
| Correct role in top three among those 25 | Not applicable | 10 (40%) | 5 (20%) |
| Five-cycle simulator mean change | +0.077953 | +0.107324 | +0.091509 |
| First-cycle action rate | 30.8% | 36.1% | 35.0% |
| Cases made worse | 2.0% | 2.4% | 2.3% |

The simulated reviewer uses the answer key: it accepts a suggested role only when it equals the template-declared role and abstains otherwise. The outcome result is conditional on that idealized review. The real-stream increment over strict is +0.029371 score units, about 37.7% of the strict mean increment; it is not 37.7% more scientifically valid ideas. The real-versus-shuffled difference is +0.015815 score units. Both assisted conditions still include cases that worsened.

The lexicon-plus-stream accuracy difference is 3/142, or 2.11 percentage points. The separately reported 3.52-point difference is **stream alone** (31 versus 26 correct labels). Do not use the stream-alone interval as the interval for the combined method or the seven-versus-four rescue count. The saved stream-alone full-flow bootstrap interval spans zero. Shared templates, overlapping vocabulary, the five-setting sweep and one shuffled realization limit interpretation. These data do not isolate scripture structure, word order or the inventor's D11 method.

In this implementation, `flow` is a contiguous window fraction of the corpus, with a seeded starting position. Co-occurrence uses token sets within passages; the shuffled control redistributes retained tokens globally while preserving each passage's retained-token count, not necessarily its original word length or syntax. A larger window reads more material. This is not an equal-compute comparison of candidate allocation, and it does not test automatic performance-based flow adjustment. Its `max(1, ...)` window rule even reads a passage at zero flow; v1.2 requires an actual zero-work baseline for zero allocation. Deep scans collect associations, not empirical evidence.

The supplied branch predates v2.1 repairs: the observation gate only checks for null, manifest sources remain mutable, and the simulator supplies `independent=True` to learning. Deep-scan summaries do not retain complete passage-level exposure lineage. The tokenizer removes words including negation. These limitations belong in the integration backlog; the new stream should be ported into the repaired base and preserve literal context. No claim that all v1.2 invariants hold follows from 19 passing tests.

At the earlier v1.2 review, the ESV source was not present in the supplied archive, so its parser count and timing were not independently rerun. The v1.5 MOST case now verifies 31,103 passages from the separately supplied file; it does not retroactively rerun the older 142-label source experiment. This revision reproduces no ESV passages. Simulator replay from stored suggestions matched output digest `3b4bc085c6e1be0d5999f6c533e37082e39384cc81b1cbd83923d03b6e938a84`; its commitment digest is `50f1bd911c28c6074597d848929eed2aada7a4104c437e4cc4efe4468dfccae4`. The supplied archive SHA-256 is `7fb7ecaa7614509926bea3b46031ace030d890c71d37508cf1d9ca112db5b609`. These identify the reviewed artifacts; local receipts are not external timestamps.

### Historical supplied source word module

The later `christeye_machine_v2 (2).zip` adds `roots.py` with 31 draft entries and three optional identifiers, plus stream indexing and input-format changes. Its 20 supplied tests passed in review. The module is referenced by its test but not by the planner or KnowledgeManifest; it does not yet enforce source-bound generation. Its digest is computed once over mutable data, and the legacy finite-value and provenance issues remain. The earlier result files were unchanged and do not validate the added source-word method. That v1.3 documentation target had 34 entries. The v1.4 integrated implementation status is recorded separately below.

The review checked the existence of the three new textual occurrences, not a complete manuscript edition, every draft mapping, or a computed first-occurrence inventory. The supplied design's additional 6.9-point/50-shuffle claim has no corresponding data and analysis in the reviewed package and is not adopted as a verified result.

## Integrated engine v2.2 baseline and verification

The merged package builds on repaired v2.1. It adds an immutable CE60 inventory, identity-preserving family resolution, a pinned Genesis edition, explicit source bindings and bounded passage scanning. The supplied research archive is retained unchanged. It does not overwrite the repaired finite-value, ambiguity, immutability or provenance controls with the older source branch.

The implemented path is source passage → exact lexical occurrence → framework member and family path → authored interpretation and operation → hypothetical proposal → estimator and common gate → committed instruction packet. Proposed graph relationships remain hypotheses; prediction scores are conditional simulator quantities. No biological intervention is executed.

In the historical v2.2 baseline, the source adapter executes three authored bindings: Bread, Seed and Light. The rest of CE60 is available for curation and family lookup. Selecting an entry without an executable binding produces an unresolved gap. The older six-rule cue compiler remains available in the separately labeled source-neutral demonstration; its relationship proposal and feedback examples do not establish that every new word has an executable interpretation.

The stream implements bounded TRICKLE, TARGETED and DEEP_SCAN calls. Flow is the fraction of source passages scanned: `floor(flow × passage_count)`. Zero exposes nothing. Every scan records its start/end positions, seed, exact source digest, scanned references, passage digests, search-token digests, matched terms, result budget and deferred count. Derived search tokens retain negation, but this is lexical retrieval, not polarity understanding. Negative wording cannot itself reverse an action or authorize it. In source-bound mode, only the separately recorded operation can create a proposal. The caller selects the mode; an automatic stall-trigger policy and outcome-adaptive flow controller remain proposed. YES2 and UTF-8 TSV are supported general stream loaders; EPUB ingestion is not implemented in this revision.

The authored software example returns three packets with the source stream: SUPPLY, MEASURE_INITIATION and MAKE_OBSERVABLE. Zero flow with no direct selections returns no packets. Direct selection of those same source bindings returns three packets with zero stream flow, preserving the distinction between foundation and stream. Changing the recorded Seed interpretation and operation changes MEASURE_INITIATION to MEASURE_PERSISTENCE. This demonstrates that the reading path participates in generation; it is not a measured quality gain. All four conditions produce verifiable receipt chains.

At v2.2, the combined invariant suites passed 65 checks: 16 original engine checks, 31 repaired waterwheel checks and 18 foundation/stream checks. They include invalid numbers, ambiguous candidates, source and binding tampering, family cycles, zero flow, negation preservation, exact lexical anchors and the interpretation-change ablation. The full synthetic regression is recorded in the package separately. No source-language efficacy claim follows from either set of tests.

The complete 60-entry lexical review, richer interpretation operations, full interchange export, automatic adaptive allocation and independent useful-output testing remain open. The earlier 6.9-point/50-shuffle claim is not adopted without its raw cases and analysis.

## Previously verified engine v2.3 cycle and estimator changes

Engine v2.3 makes three changes to the v2.2 package. The gate, provenance, receipts, finite-value checks, family resolution and source-bound adapter are unchanged.

1. **Cycle-safe relations with a direct channel fallback.** A RELATION rule whose recipient already lies upstream of the proposed source would create a cycle. v2.2 emitted it and the estimator then blocked it. v2.3 records a `RELATION_WOULD_CYCLE` gap and never proposes the cyclic edge. After excluding existing edges, it emits the rule's action directly on the original source only when at least one new recipient would create a cycle and no new acyclic recipient remains. Missing recipients or existing edges alone do not trigger fallback. The fallback retains `RELATION_WOULD_CYCLE` provenance and adds no edge. This DAG restriction belongs to the current estimator; it is not a claim that real systems have no feedback. That action passes through the common gate like any other.
2. **Extension rules.** `EXTENSION_RULES`, combined as `V23_RULES`, add `open_channel` (Water → SUPPLY), `vessel_keeps_store` (vessel, jar, wineskins, sealed, earthenware → STRENGTHEN Roots) and `fit_the_vessel` (the container words and clay → SUPPLY Soil). These are assistant-authored bindings pending the inventor's review; they are not entries in the inventor's MethodProfile. `DEFAULT_RULES` retains its six definitions, but compiler and action semantics have changed. Earlier outputs require their original pinned code for exact replay; unchanged rule names alone do not guarantee identical decisions.
3. **Source-node STRENGTHEN.** Described under Strengthening and coordinated changes. The planner and simulator both apply it.

The invariant suites pass 70 checks: the 16 original engine checks, 31 waterwheel checks (one updated to the cycle-fallback contract), 18 foundation/stream checks and 5 new v2.3 checks. The new checks cover source-node STRENGTHEN, a direct Water action with no cyclic relationship, container rules targeting Roots and Soil through the gate, and an increase on a shadow node remaining UNRESOLVED.

The 1,000-case legacy regression was rerun. Gate-safety results are unchanged: no gate bypass, no unresolved selected target and no shadow trap. The adjudicated chain first-action correctness changes from 0.807 to 0.801. Its current five-cycle mean change is +0.2123, versus +0.0915 for the sign-aware baseline; the paired synthetic difference is +0.1208 with the pilot's 95% interval 0.1061–0.1360. Strict identity produces +0.0773 and acts in 30.9% of first cycles. These comparisons inherit the author-defined cases, shared assumptions and unequal baseline safeguards. The local rerun matches the supplied v2.3 output digest `4efa777d4c426f4061a24706d021f535b3a9bf304b6d7e7bb96a706611160c61`; its replay is identical and its receipts verify. Both regressions remain authored simulator results.

The v2.3 archive still reports `2.2.0` in its package version string, and several README/validation sections describe v2.2. Identify the reviewed implementation by the archive and code digests, not that string alone. This documentation update does not modify the supplied executable. The package manifest verifies its listed files; a valid manifest does not by itself commit files omitted from a particular run's execution record.

Bindings still carry the main limitation: a rule fires on single keywords, so shuffled text containing the same words produces the same operations. The next step is binding the framework's relation-sensitive interpretations as operations that depend on relations within a passage (participants, verbs, negation, container–contents relations). Then compare real text against shuffled and displaced controls on held-out, externally authored cases with matched budgets.

## Garden processes and rising candidates

The garden extension adds time, recovery, competing demands and persistence to candidate selection. It preserves the framework's source-derived interpretations as attributed generation methods. The 60-entry vocabulary is unchanged: garden names designate operators or lifecycle states, not additional vocabulary entries. The following is the **target contract retained from v1.7**; the historical v2.4 findings and current v2.5.1 review below distinguish implementations.

### Process operators

| Operator | Attributed source cue | Required behavior |
| --- | --- | --- |
| Rest | Leviticus 25:4; seventh-day rest | Consider deferral when repeated observations indicate recovery without intervention; retain uncertainty, alternative explanations and a next observation time. |
| Thorns | Matthew 13:7, 22 | Exclude or defer an action on an overloaded target using a declared stress measure and threshold; preserve measurement gaps. |
| Seasons | Psalm 1:3; Ecclesiastes 3:1 | Compare an operation's outcomes by observed phase, with declared minimum sample counts and a frozen decision policy. |
| Rocky ground | Matthew 13:5–6 | Assess whether improvement survives a specified interval and withdrawal of the initiating input; propose reinforcement when appropriate. |
| Arbiter | Job 1–2; 41:34 | Record competing adverse-process hypotheses and discriminating measurements; use the common gate to constrain affected actions. |
| Rising | Psalm 33:6; Genesis 1:3; Judges 5:20; Job 38:7; Psalm 147:4 | Maintain a scoped, evidence-linked candidate catalog, including negative and unresolved outcomes, suspension and reconsideration. |

These references identify inspiration and attributed readings. They do not establish physical, biological or moral properties of the target. “Answered from the ground” is an image for measured feedback; direction of travel does not determine truth. “Fallen” describes suspended reuse, and “pride” describes a specified calibration or contradiction failure. Neither labels a person or establishes spiritual causation.

In v2.4 the illustrative numerical rules are three increasing nonmissing health readings with increments above 0.03 for Rest; stress at least 0.8 for Thorns; mean SUPPLY benefit in a phase below half the other-phase mean, with at least three outcomes in each group, for Seasons; and a three-cycle persistence interval for Rocky ground. Seasons has a low-Fruit exception below 0.3. These are authored simulator parameters, not general constants. The Rest implementation filters missing observations before counting three readings, so they need not be consecutive cycles. A production policy must declare the allowed observation gaps.

A substituted candidate must receive its own fresh estimate, identity and eligibility checks. The final executor must refuse BLOCKED or UNRESOLVED actions even if an earlier planner approved another candidate. Measurement requests and rest decisions are explicit outcomes. Neither source relevance nor a positive score bypasses these requirements.

### Arbiter: hypotheses, pathways and observations

Record the recipient, affected action, context, time window, source observations, competing explanations and a discriminating measurement for every warning. A short benefit followed by deterioration can suggest an adverse process; it can also reflect overload, a transient shock, natural variation or another intervention. It remains an inference until the required evidence supports the specific claim. A precautionary block may be justified by uncertainty while retaining HYPOTHESIS or UNRESOLVED status.

The intended adversary map can connect warnings to diagnostic relationships, including feedback loops, resource diversion and conflicting objectives. Keep this diagnostic graph separate from the current acyclic estimator. A relationship is not causal merely because it has been drawn. The v2.4 profile is a set of node identifiers in four categories—impulse sources, suspected sources, choked and shallow—not a path-based opposing-network model.

Profile state is scoped to a case. Carrying it into another context requires an explicit transfer record and new checks; clearing a case does not erase its audit history. Inferred warnings must never overwrite `adverse_observed`. An observed status requires a linked measurement and its scope, with simulator observations explicitly marked SIMULATION.

### Rising: a scoped and revocable catalog

| State | Required record and transition |
| --- | --- |
| Spoken | Candidate identity, target, context, source bindings and versioned prediction recorded. |
| Lit | Discriminating test specified and applicable gate conditions satisfied; readiness and actual execution remain separate events. |
| Answered from the ground | Linked assessment records benefit, harm, null result or unresolved outcome. An answer is not automatically a success. |
| Holds its course | A positive assessment meets the declared persistence criterion, with continued supports, other actions and confounds retained. |
| Sings together | Qualifying assessments agree under a stated scope and an explicit provenance-based independence check. Distinct case IDs alone do not qualify. |
| Named and counted | Reuse may be considered within that scope while evidence remains current; every proposed reuse is gated again. |
| Fallen | Reuse suspended for a recorded adverse result, contradiction, calibration failure or loss of supporting scope. |
| Fallow | Candidate retained with a reason, allowed investigation budget and a specific reconsideration trigger. |
| Resurrected | A reconsideration event follows new evidence or changed context; it does not automatically restore Named status. |

A catalog identity includes the candidate or template version, target binding, context and source-binding versions. Broad role/action summaries may support retrieval but must not merge distinct interventions or their evidence. “Star” is a display name for Named status, qualified as simulation-only, empirical in a stated context, or unestablished. It is not an immutable truth, a universal answer or an exception to the gate.

Keep blocked-for-harm, insufficient-evidence, unresolved-identity, deferred-by-budget and out-of-scope candidates distinguishable in the fallow store. A bounded reconsideration schedule may reread sources, request measurements or rerank candidates; it cannot execute an unsafe action merely to explore it. Log each transition append-only. Compare predictions with their own matched outcome records before making calibration judgments; unmatched predictions and censored follow-ups are reported separately.

### Records and integration boundary

Schema 1.7 adds `ProcessPolicy`, `ProcessDecision`, `AdversaryProfile`, `CandidateCatalogEntry`, `CatalogEvent` and `FallowRecord`. They link to existing Candidate, Prediction, Assessment, RootingAssessment, AdverseEffect and LineageLink records. Schema shape checks cannot establish reference closure, actual independence, append-only history or causal validity; runtime validators must do so. The sixth example is a draft garden curation fixture, not an exported v2.4 run.

The garden pilot uses author-supplied graphs and identities. It does not call the source-bound wheel or stream to construct those graphs. Its scores therefore do not measure the added value of scripture, the framework's interpretation method, the 27 bindings or adaptive stream allocation. These remain separate experimental questions.

## Historical verified v2.4 garden and binding records

The supplied package passed **84 checks** in this review: 16 original engine checks plus 68 unittest checks (31 waterwheel, 18 foundation, 12 binding-library and 7 garden). These are software checks of their stated assertions, not 84 independent discoveries or proof that all invariants hold.

All 27 bindings emitted proposals on the authored full-library graph: 28 output packets, with MEASUREMENT_REQUIRED or PROPOSED_FOR_TEST statuses, and verified receipts. Joint and Reins returned explicit gaps. The full Hebrew edition and its two declared orders were loaded; all **206 reported Hebrew exact-identifier/order comparisons**, including reported absent base forms and their augmented alternatives, matched recomputation. Greek-only identifiers were outside this source scope. Matching occurrences do not complete scholarly lexical review or the inventor's interpretation approval.

### Garden outcomes

The complete garden replay matched the supplied parsed summary and per-case results. Twenty authored domains each contributed 28 evaluation cases after excluding case indices 0 and 1, for **560 cases per condition and 10 cycles per case**. These are development-excluded simulator cases, not an independently hidden confirmatory test. “Made worse” means final modeled Fruit is more than 0.02 below its starting value.

| Condition | Mean final Fruit | Mean change | Made worse | Difference in change versus repair shop |
| --- | --- | --- | --- | --- |
| Repair shop | 0.5445 | +0.1406 | 24.3% | — |
| Rest only | 0.5467 | +0.1427 | 23.2% | +0.0021 |
| Thorns only | 0.6201 | +0.2162 | 9.1% | +0.0756 |
| Seasons only | 0.5840 | +0.1800 | 20.4% | +0.0394 |
| Rocky ground only | 0.5566 | +0.1526 | 23.8% | +0.0120 |
| Arbiter only | 0.5637 | +0.1597 | 22.0% | +0.0191 |
| Four garden operators | 0.6498 | +0.2458 | 7.5% | +0.1052 |
| Full garden including Arbiter and rising | 0.6592 | +0.2552 | 5.5% | +0.1146 |
| Sign-aware comparator | 0.3223 | −0.0816 | 49.6% | −0.2222 |

The repair-shop versus full-garden count is **136/560 versus 31/560**, an 18.75 percentage-point decrease and approximately 77.2% relative reduction in modeled made-worse outcomes. Cases with improvement above 0.02 increased from 372/560 to 500/560. Mean action decisions fell from 8.98 to 7.90; the full garden averaged 0.64 rests and 0.93 measurement requests per case. Bundled actions can contain multiple components, so action-decision count is not a complete work or intervention budget.

The supplied case-resampling interval for the +0.1146 mean difference is 0.0999–0.1306. It ignores shared domain structure and sequential controller state. An exploratory resampling of the 20 complete domain means gives 0.0975–0.1329 (10,000 draws, seed 20261110); all 20 domain mean differences are positive. Neither interval repairs author-known dynamics, repeated development on the world or comparator differences.

### What the implementation does not yet establish

1. **Evidence typing:** `_update_profile` turns a short-gain/late-decline heuristic into `adverse_observed=True` without a separate measurement. A direct counterexample reproduced that promotion. This violates the intended separation of inference and observation; a gate can behave consistently on an incorrectly typed input.
2. **Accessible feedback:** action assessment, phase statistics and persistence checks receive exact latent `sim.fruit()` values. Only the separate learning-credit callback adds noise. The controller also receives the simulator object. “Observations only” is not an enforced access boundary in this runner.
3. **Adverse detection:** the impulse-source rule identified 14 true targets, flagged 183 other case/target pairs and missed 221 of 235 true impulse cases: precision 7.1%, recall 6.0%. The separate suspected-source rule identified 38 true targets and flagged 49 others. Outcome improvement does not validate the inferred mechanism.
4. **Rising and fallow:** the catalog records 69 active stars, 85 falls and 106 resurrections, but the planner never consults these states to choose or prohibit an action. The key groups by role/action within a domain, not full intervention identity. A direct `holds()` counterexample creates a Named entry after three case IDs without any answer records. These counts are diagnostic bookkeeping; guarded reuse, independence assessment and budgeted fallow revisitation remain to be implemented.
5. **Delayed attribution:** a three-cycle outcome includes other actions and spontaneous change. It is not an isolated causal effect of the credited action. Follow-ups still pending at the horizon are discarded on reset. The simulator queues impulse penalties serially and stops at cycle ten, leaving some later penalties outside the score. A persistence-driven action swap also retains the original prediction instead of recomputing it.
6. **Execution guard:** the garden runner counts a failed final gate check but still calls the action function. No such bypass occurred in this replay; the runner nevertheless needs fail-closed enforcement. The sign-aware comparator does not call that gate check, so its zero counter does not mean it passed the gate.
7. **Evaluation and commitment:** the same author designed the dynamics and operators. Phase statistics persist between cases within a domain. The receipt chain contains repeated operator/result rounds. It establishes local hash consistency, not that no operator existed before the first receipt, developer blindness or an external timestamp. The runner verifies only the world-code file against the world commitment; it does not enforce the full truth digest or dependency closure. This review separately recomputed the complete truth-list digest and verified the latest listed code hashes and summary receipt.
8. **Branch integration:** v2.4 supplies the 27-binding/full-edition branch but lacks the earlier cycle-fallback rules, optional Water/container extension rules and source-node STRENGTHEN behavior. The earlier 70-check branch and ESV example remain historical verified records. They are not results of the new package. The common gate and provenance files match that branch, but a merged executable still requires its own tests and result digests.

The package manifest's 138 listed file hashes match. Archive SHA-256: `e3b24b0d13a1b566b1482ce3a1ad422bd34e27263847552504d45922741b8b6f`. Garden summary object digest: `d093ed715aa53f2872b64626ed874aef2ce7bd9a152746dc5e0cc335f66e8df3`. Truth-list digest: `b2fc3ededf0d6ab6429e43e03b4b2f77ff4638e211be5ad1b883443823a0d755`. These identify the reviewed artifacts and their scope; they do not establish external priority, scientific independence or empirical efficacy.


## Firmament and dividing

The inventor names the eight-component process layer **Firmament** and its operation **dividing**. In this interpretation, waters above represent the stream of proposed ideas and waters below the target system. The software separates proposals from observations, permission from benefit estimates, and immediate change from persistence. It admits a proposed operation only through the applicable checks. Firmament is a layer name; the CE60 vocabulary remains unchanged.

The user associates the expanse with *raqia* and distinguishing with *badal*, citing Genesis 1:6–7, Genesis 1:4 and 1:14, Leviticus 10:10, and Deuteronomy 28:12. These are attributed interpretive anchors. They are separate from computed first-occurrence bindings and do not establish empirical effects.

| Division | What is distinguished | Interpretive passages | Software requirement |
| --- | --- | --- | --- |
| Good | Good from bad results | Gen 1:4; Gen 1:10; Gen 1:12 | Assess the observed response; retain uncertainty and avoid repeating a recorded adverse move. |
| Holy | Set apart from permitted use | Gen 1:6-7; Lev 10:10; Gen 2:3 | Apply explicit protected-target and rest-interval policies independently of harm evidence. |
| Peace | Sufficient completion from further intervention | Gen 2:2; Ps 46:10 | Rest when the required observed outcomes and parts meet the declared thresholds; unknown parts remain unknown. |
| Anger | Escalation from an ordinary action opportunity | Gen 4:7; Eph 4:26 | Investigate sustained decline and propose a permitted containment action; a metaphor does not diagnose a person. |
| Compassion | A declared need from an unheard need | Exod 3:7; Exod 2:6 | Attend to declared distress; obtain explicit participant authorization for human targets and rank only allowed, gated supports. |
| Birds | Delivered provision from diversion or loss | Gen 15:11; Matt 13:4; Matt 13:19 | Investigate unexpectedly short gains and consider a gated protective action before another supply. |
| Tares | A favorable report from a verified state | Matt 13:24-30; 1 Thess 5:21 | Request a direct measurement when upstream reports and downstream outcomes conflict; avoid assuming deception. |
| Heat | Persistent capacity from vulnerable improvement | Jer 17:8 | During a declared adverse interval, consider strengthening before supply; re-estimate and gate the substitute. |

Jeremiah 17:8 supplies the inventor’s Heat–Tree–Water association; the nearby Heart and Reins language supplies another interpretive connection. The suggested eighth-day symbolism is optional metadata, not a threshold, numerical reward or evidence of performance. Good, Holy, Peace and the other names do not independently corroborate an outcome.

## Historical repaired engine v2.5.1

The supplied v2.5 package adds eight process operators, four descriptive readers, measurement-feedback handlers and 59 source bindings. Its original 91 checks pass, and the 120-case developer run reproduces. It is a working research prototype; no independently authored case set was supplied. This revision repairs code, consolidates the earlier cycle/estimator branch, and records the Firmament interpretation without changing the 60-entry vocabulary.

### Repairs and enforcement

| Area | Repaired behavior |
| --- | --- |
| Execution | A failed or unresolved final gate prevents execution. Every comparison condition uses the gate. Bundles remain subject to component checks. |
| Firmament routes | Early Compassion and Anger routes, ordinary selection and substitutions undergo common process policies. Replacements receive fresh predictions. |
| Permissions | Protected targets and rest intervals are authorization constraints, separate from observed harm. Declared human targets require explicit, unwithdrawn consent and a participant-selected action on every route. Synthetic support uses a separate simulation policy. |
| Measurements | Wrong boolean types, non-finite numbers, out-of-range normalized values and unknown targets are rejected. Missing values remain unresolved. Effective feedback requires a source, unique measurement ID, case, cycle and evidence kind. These fields identify an observation; they do not independently authenticate its source. |
| Adversary evidence | Temporal and structural patterns remain suspicions. They cannot manufacture observed harm. Confirmed simulator readings retain SIMULATION status. |
| Access and repeatability | The controller receives immutable serialized observation snapshots and copies of their public fields. Latent truth stays in the evaluator. Repeated packet reads do not resample noise. This is an in-process API boundary, not an operating-system sandbox. |
| Delayed assessment | Intervening actions and missing outcomes prevent isolated delayed learning credit. Pending follow-ups are counted at the horizon. Unmeasured dependence is not assumed absent. |
| Catalog | Identities include target and graph context. A hold requires a positive answer for that case. Catalog stages are simulation diagnostics with reuse unauthorized; empirical promotion and actual planner reuse remain unimplemented. |
| Simulator | Repeated delayed harms have independent due times. An overload-backfired action does not silently confer protection or satisfy distress. Nine additional no-action cycles expose longer-term behavior. |
| Commitments | The new freeze verifies its own digest, code/source closure, policy and Python/NumPy versions. The exact parsed CSV bytes, row order and initial truth digest are committed. Nonempty result directories cannot be overwritten. Both detailed results and summary receive digests. |
| Branch consolidation | Earlier cycle rejection with gated action fallback, optional Water/container rules and source-node strengthening are restored. Old results remain attached to their original executables. |

The supplied full suite had 91 checks. The repaired package has **120 passing checks**: 16 engine checks and 104 unittest checks, including five restored cycle/estimator checks and 24 new review regressions. Four existing expectations were corrected because they allowed unsupported holds, untraceable feedback, continued-support persistence or the superseded cycle behavior. Passing these assertions is not a general safety proof. The post-freeze controller checks also pass.

### Reproduced and repaired development outcomes

Each row below concerns 120 developer-authored cases, twenty domains, and ten decision cycles. A made-worse case finishes more than 0.02 below its starting latent outcome. Authorization, observation sampling, source strengthening and delayed-harm semantics changed between releases; compare conditions within each release. These are not before/after estimates of real-system effectiveness.

| Experiment | Basic planner made worse | Full garden made worse | Full garden average change | Full garden advantage over basic |
| --- | --- | --- | --- | --- |
| Supplied v2.5, reproduced | 69/120 (57.5%) | 24/120 (20.0%) | +0.115 | +0.167 |
| Repaired v2.5.1 | 51/120 (42.5%) | 25/120 (20.8%) | +0.0914 | +0.0935 |

Within the repaired experiment, the full garden reduces the made-worse rate by 21.7 percentage points, approximately 51% relative to the basic planner. The paired case-bootstrap interval for the mean outcome advantage is 0.0661–0.1213; the twenty-domain cluster interval is 0.0704–0.1160. Both intervals are exploratory. The stronger matched-gate sign-aware comparator leaves 61/120 cases worse, has mean change −0.0913, and has 342 attempted actions rejected before execution. No executed action failed its final gate in this run.

The full garden averages 6.08 actions per case versus 8.58 for the basic planner. Thus lower intervention frequency remains a competing explanation for part of the benefit. The eight-component Firmament alone has mean change +0.0862 and leaves 24/120 cases worse; adding the earlier operators does not dominate it on every endpoint. No thresholds were tuned to maximize these repaired development results.

The no-action follow-up changes the full garden made-worse rate to 39/120 (32.5%), versus 58/120 (48.3%) for the basic planner. This follow-up includes continuing ambient dynamics as well as delayed effects; it does not isolate harm caused by an intervention. The full garden has 149 unfinished delayed credits at the primary horizon and 468 unresolved attributions, including intervening actions. Those counts are retained rather than treated as demonstrated persistence.

The adversary detector remains weak: four true impulse-target flags among 96 flags, 92 false target flags, and four detected among 53 impulse cases. Precision is 4.2%, overall recall 7.5%, and recall among the seven actually fed impulse cases is 3/7 (42.9%). This is not a validated adverse-network detector. Its suspicions can request investigation; they are not confirmed causal diagnoses.

### Source participation and remaining limits

All 59 source bindings emit in the full-library wiring demonstration, producing 63 packets with proposal or measurement-required status; receipts verify. Four bindings propose actions and 55 request measurements. Joint remains an explicit Greek-edition gap. Exact occurrence computation does not approve a lexical sense, a theological interpretation or a scientific claim. Anger, Compassion and other labels may intentionally use nonliteral source senses; those differences stay visible.

The garden comparison still starts from authored graphs and role identities. Its decisions do not use the source wheel to construct those graphs. Therefore it does not measure the additional benefit of scripture, the framework's interpretation method, source selection, or the 59 bindings. The source wheel and garden controller coexist in the package, but a unified source-to-garden discovery evaluation remains pending. Outcome-adaptive flow allocation, full interchange export, provenance-qualified empirical catalog reuse and budgeted fallow retrieval remain pending. The four readers describe runs; they do not change decisions.

The original archive and freeze are preserved unchanged in the package history. The v2.5.1 commitment is a new post-review release commitment, not a claim that repaired code preceded the earlier cases. Its known-development-case digest explicitly identifies the cases already seen. A future independent study needs fresh hidden cases and a separate preregistration before access.

New executable commitment: `797ecf4a9ceb9071173082162c60922d9e92a59952cb26ed458ddfb70d68db41`. The original v2.5 archive SHA-256 is `66c12f1fc389b4e854281118865d2281b8c1b03d7b173eaee025d80e6752e9fc`.

## Current merged release v2.6.1

This release adds and hardens the optional heart workflow while retaining the v2.5.1 repaired garden implementation. There are **151 passing checks**: 16 engine checks, 104 existing repaired-module checks and 31 heart checks. The original v2.5 and v2.6 supplied archives and the reviewed v2.5.1 package are retained for reproducibility. The new commitment is `980dbcd2934c859381458aa254385034a91c3379761e198162944004d812e5e6`. Old result records retain their original release labels. A current garden regression reproduces the repaired condition results; the new heart module is not used by that planner and is not credited with a performance gain.

A successful software regression or a synthetic example does not validate a human intervention, demonstrate spiritual or biological causation, or establish the source-reading method's added value. Source-to-garden generation, adaptive flow, independent empirical catalog reuse and the heart-to-Rising connection remain pending.

## Validation and implementation priorities

The supplied name-prediction harness is a dry-run scaffold. It prints prediction hashes before loading a key but does not persist a complete prediction artifact or independent receipt. Its `reader` field is not used to stratify analysis; its comparisons do not implement the paired D11 increment test or a reader comparison. Its permutation result concerns its specified lexical classifier and role rubric, not unknown scientific discovery. Real-data use requires the protocol corrections in the updated validation document.

The v2.5.1 repair consolidates the cycle/estimator branch and corrects the reviewed execution and evidence-handling faults. Next prioritize independent hidden cases, adversary precision and delayed-outcome design. Guarded catalog reuse, fallow retrieval, the unified source-to-garden path and automatic flow allocation require implementation and separate evaluation before comparative claims. Compare names, descriptive synonyms and neutral identifiers under equal information budgets; compare D11 with literal/source cues, fit-only ranking and matched random cues. Record prior familiarity and keep apprentice training cases separate from evaluation cases.

Expert contribution can be evaluated for fidelity and utility separately. Several readers per comparison group are needed to support a group-level claim; one inventor-versus-one-scholar result concerns those people and cases. A positive difference is bounded by its test; a nonsignificant result does not demonstrate equivalence. Heart outcome studies remain proposed and separate from software or lexical dry runs.

## Patent integration and disclosure scope

The integrated draft preserves evidence-kind immutability, required-parent permissions, bidirectional canonicalization and provenance. It adds layered generation, interpretation, Heart and expert-input embodiments, generation snapshots, replay specifications and corrected pilot reporting. Illustrative claim concepts require counsel review; more features or a new source vocabulary do not establish novelty or eligibility.

The full word-system design records the framework's method more broadly than the independent computing claims. Detailed interpreter-selection notes may remain internal, but any claimed mechanism needs sufficient disclosed operation and examples. No confidentiality or copyright label substitutes for that requirement. Factual results and relevant prior art remain preserved. No filing or external publication is performed by this update.

## Source references

- [Open Scriptures Hebrew Bible project](https://github.com/openscriptures/morphhb) and [lexical annotation description](https://hb.openscriptures.org/HomeFiles/Oshb.html). Credit the Open Scriptures Hebrew Bible Project for lemma/morphology annotations under CC BY 4.0; WLC text is public domain. Exact release and bytes must be pinned for a run.
- [OSHB Genesis XML](https://raw.githubusercontent.com/openscriptures/morphhb/master/wlc/Gen.xml), reviewed for Genesis 1:3, 1:11, 2:7, 2:23 and 3:19. The v2.2 package pins the downloaded bytes by SHA-256; the moving branch URL is only a source locator.
- [Institute for New Testament Textual Research](https://www.uni-muenster.de/INTF/en/institut/) for the distinction between manuscript witnesses and reconstructed editions.

- [W3C EPUB 3.3](https://www.w3.org/TR/epub-33/) for source structure and reading order.
- [Jiang et al. 2023 Active Retrieval Augmented Generation](https://aclanthology.org/2023.emnlp-main.495/) and [Howson et al. 2023 Delayed Feedback in Generalised Linear Bandits Revisited](https://proceedings.mlr.press/v206/howson23b.html) are comparison sources, not a completed novelty search.

- Ephesians 3:18; Proverbs 31:30; 1 Peter 3:3-4; Song of Songs 4:5; Exodus 20:18. Record translation and source span in each actual run.
- Beaty and Johnson, SemDis, DOI [10.3758/s13428-020-01453-w](https://doi.org/10.3758/s13428-020-01453-w). Semantic-distance creativity assessment is prior published work.
- Rogakou et al., DNA-damage foci, DOI [10.1083/jcb.146.5.905](https://doi.org/10.1083/jcb.146.5.905).
- Purvis et al., p53 dynamics, DOI [10.1126/science.1218351](https://doi.org/10.1126/science.1218351).
- Erez et al., arbitrium, DOI [10.1038/nature21049](https://doi.org/10.1038/nature21049).
- Baggiolini et al., neural crest multipotency in mice, DOI [10.1016/j.stem.2015.02.017](https://doi.org/10.1016/j.stem.2015.02.017).
- Zhang et al., cellular membrane nanosponges, DOI [10.1021/acs.nanolett.0c02278](https://doi.org/10.1021/acs.nanolett.0c02278). This does not establish neural-crest-derived decoys.
- [W3C PROV](https://www.w3.org/TR/prov-overview/), [AutoTRIZ](https://arxiv.org/abs/2403.13002), and [Bazel hermeticity](https://bazel.build/basics/hermeticity) are relevant comparison sources, not a completed patent search.

- [Triplet–triplet annihilation upconversion driving NBD–QC switching in the solid state, J. Mater. Chem. C 2024](https://pubs.rsc.org/en/content/articlehtml/2024/tc/d4tc03513e), source of the bottleneck values in the solar thermal example.

## Revision record

Version 1.9 merges the heart workflow from the uploaded v1.8 design into the maintained repaired documents. It aligns all four documents with engine v2.6.1, adds current authorization and revision-bound assessment requirements, and preserves the earlier Firmament and repair records.

Version 1.8 adds the Firmament interpretation and 59-binding coverage, records the v2.5 critique and v2.5.1 repairs, and retains all earlier development records under their original identities. Schema 1.8 expands the process-policy enum and adds observation, feedback, execution and authorization records. No independent discovery or clinical result is asserted.

Version 1.7 integrates the supplied garden update as six operator/lifecycle contracts, adds schema records and claim concepts 69–72, and verifies the v2.4 package (84 checks, 27 bindings, 206 Hebrew identifier/order comparisons and exact parsed garden replay). It preserves the earlier cycle/estimator and ESV results under their own code identities. Audit findings and pending branch consolidation are explicit; no independent efficacy claim follows.

Version 1.6 merges the 27-row binding catalog, edition-order closure, augmented-identifier review and operation-registry contract from the separately supplied v1.5 binding update. It retains the v1.5 cycle rules, source-node strengthening, ESV example, regression results and limitations. The 17 Genesis occurrences were recomputed successfully; 77-check and full-edition reports remain attributed pending their executable artifacts. Schema 1.6 has 70 record definitions and five examples. Three incoming claim concepts are retained as 66–68, preserving existing 64–65.

Version 1.5 adds engine v2.3: cycle-safe relations with a direct channel fallback, assistant-authored extension rules for Water, Roots and Soil, and source-node STRENGTHEN semantics. It adds the molecular solar thermal storage worked example with real-stream, shuffled-stream, zero-flow and attributed-reading conditions. The real and shuffled streams shared their two leading proposals and estimates, and the document records that limitation. The 70 checks, 1,000-case regression and ESV four-condition replay were verified. No independent discovery, source-language effect or laboratory performance is established. The schema retains 69 record definitions; patent claim concepts 64–65 describe cycle handling and topology-dependent estimation for review.

Version 1.4 adopts CE60 with Light at entry 60 and Bread/Seed core, preserves family identities, merges a bounded source adapter and stream into repaired engine v2.2, adds a reproducible interpretation ablation, and separates implemented controls from proposed adaptive allocation. Patent claim concepts 60–63 and schema records are aligned.

Version 1.3 makes the scriptural source-word foundation required for the ChristEye source-bound profile, adopts Bone, Breath and Seed for a 34-entry registry, separates lexemes, first-occurrence computations, interpretive anchors and manuscript attestations, specifies translation alignment and binding integrity, and adds source-foundation verification and contribution studies. The original development results remain version-specific. This revision updates documentation and schema; it does not merge or modify the supplied engine branches.

Version 1.2 adds adaptive source selection, fixed-work flow allocation, generation-policy attribution, pending-outcome handling, source epochs and replay records. It records the supplied YES2 experiment separately from v2.1, preserves the earlier pilot, adds schema migration and acceptance criteria, and separates controller, corpus and reading-method tests. No filing, implementation of the proposed controller or external study is performed by this documentation revision.

Version 1.1 captures the central depth-of-reading method, optional expert participation and interpreter-selection note; expands the Heart mechanism; integrates D11 and Tree consistently; separates ranking from identity and support; specifies commitment and replay limits; corrects the pilot summary; and aligns record names with the schema. It incorporates the useful mechanisms in the separately supplied Claude v1.0 draft while retaining the reviewed lineage rules and factual development history. Pending tests remain pending, and dry-run outputs remain separate from evidence of efficacy.


## 20 Heart to heart inquiry and retained experience

Revision 1.10 with experimental engine additions in v2.7. The garden benchmark and its results remain the reviewed v2.6.1 results. This section adds an executable integration demonstration, not independent validation.

The subject's Heart is the declared mechanism that shapes its responses. ChristEye's inquiry Heart holds the goal, constraints and assessed proposals. The two interact through identified receiving and response ports. For a molecule, organism or process, a role must resolve to an ordinary mechanism, intervention interface or measurable endpoint; the name alone establishes neither understanding nor healing.

| Part | Operational meaning | Record or check |
| --- | --- | --- |
| Tree | Retained experiences and their original observations | Content-addressed experience records; failures retained |
| Winds | Available behaviors and expressed responses | Registered candidate actions and measured outputs |
| Inquiry Heart | Purpose, boundaries and provisional commitments | Goal, policy version, observation and graph identity |
| Subject Heart | Response-forming mechanism in the focus system | Subject and context identity, mechanism and port contract |
| Eyes | Receiving interface and access to relevant observations | Observation snapshot; missing and unverified inputs remain unresolved |
| Mouth | Words or typed instructions expressed by either side | Inquiry proposals and subject reports kept distinct |
| Mesh | Connections consulted during an inquiry | Bounded traversal with cycle protection; links remain declared models |
| Source stream | Identified ancient-source readings supplying proposal operations | Binding, anchor, interpretation and operation ancestry |
| Fruit | Measured endpoint change and subsequent retention | Units, direction, baseline, follow-up and unresolved causal attribution |
| Covenant | Purpose and limits preserved across interactions | Current authorization and the common execution gate |

Garden is the organizing metaphor for growth, feedback and seasons. Ark is an optional metaphor for preserving the covenant and record. Neither adds an unimplemented mechanism or establishes patentability. Eyes and Mouth are interface roles in this embodiment, not additions to the frozen 60-entry inventory.

### 20.1 Receiving expression and returning the subject response

`heart_to_heart` compiles source-bound cues into a bounded candidate pool, records Eyes observations, evaluates candidates, consults the declared mesh and emits a Mouth draft. A draft may contain an explanation, a measurement question or a typed instruction. It is not an actuator. The caller must execute an instruction through `execute_guarded` using current observations and authorization.

The subject-side `FocusContract` identifies its response-forming mechanism, receiving port, response port, endpoint, units, preferred direction and retention interval. `FocusHeart.receive` records a delivery receipt. Delivery does not establish that the subject understood an input. `listen` accepts identified observations; `speak` returns a structured report of endpoint change and provisional retention. Molecular and biological adapters have not been built or validated. Human-directed use remains voluntary and cannot claim to install beliefs.

The reading operations are reviewed interpretations: Ephesians 1:18 motivates attention; Romans 10:9–10 distinguishes belief or commitment from expression; Luke 6:45 links retained state to expression; Proverbs 4:23 motivates guarding; Proverbs 18:13 motivates observation before answering. KJV renders Ephesians 1:18 with understanding, while other editions use heart. These are reference-level interpretation records, not newly verified Greek first-occurrence bindings for each listed verse. Section 21 closes the Joint edition gap; it does not automatically verify these separate interpretive mappings.

Adjectives such as wise, tender, hardened or divided can generate questions about calibration, responsiveness or conflicting priorities. They do not diagnose people, create observations, or establish biological states. Additional adjective-to-operation bindings remain proposed until their measurable predicates and alternatives are specified.

### 20.2 Storing returned words and growing across interactions

An experience retains the sent proposal, execution receipt, original subject report, returned words, context and generation ancestry. Repeated storage of identical content deduplicates to the same experience identity. Reingested output is QUERY_SEED only. The machine does not count its own words, repeated reports or retrieved memories as independent confirmation.

Retrieval requires the same current contract in this implementation. It can occupy one of the existing eight candidate slots, where the proposed instruction is assessed again against fresh observations and the common gate. This permits experience to shape a future inquiry without authorizing automatic replay. The raw returned words and measured values are preserved separately from the interpretation.

Subject growth and machine learning are distinct. Subject growth is an endpoint change or persistent response measured under a declared contract. Machine learning changes future proposal allocation or retrieval. The compact adapter's retention check requires at least two consecutive unprompted observations spanning the declared interval; this is an unvalidated operational rule, not a scientific definition of understanding. Causal attribution remains unresolved without a discriminating comparison.

A tabletop embodiment can use beans, chocolate chips or other distinguishable tokens linked to experience cards. Positions or cards identify subject, context, instruction, observation and status. A token alone cannot encode arbitrary returned text or demonstrate an effect. Physical representation does not itself establish novelty or resolve software eligibility.

### 20.3 Adaptive candidate allocation

`AdaptiveFlow` allocates a fixed candidate budget across ordinary and source-derived proposals. It explores specified fractions until each has the minimum number of assessed episodes, then selects the highest observed mean reward with deterministic ties. The illustrative reward is endpoint change minus normalized burden minus one for reported harm. Pending outcomes remain pending; missing, invalid or confounded reports receive no reward. Feedback is bound to its allocation version and provenance record. Episode association is not causal credit or independent support.

This is an executable allocator and can supply `heart_to_heart` with source and ordinary slots. It is not yet integrated with a production passage cursor or the full garden controller. Outcome-adaptive improvement, nonstationary exploration, qualified catalog reuse and fallow reuse remain unvalidated. A fixed evaluation cap can leave some slots unused; report actual workload as well as caps.

### 20.4 What the new demonstration establishes

`heart_to_heart_demo.py` executes four conditions on one authored software graph: ordinary rules, source bindings, neutral labels with unchanged operations, and a fixed permutation of binding targets. Source-derived proposals now reach the execution gate, change the chosen action in this fixture, receive simulated outcomes and enter experience memory. The neutral and permuted conditions produce the same chosen action as the source condition. This example does not show a scripture-specific advantage. Its simulator has no realistic retention decay; subsequent unchanged reads verify record handling only.

The existing 120-case garden benchmark still receives authored graphs and does not call this new bridge. The decisive independent source-reading comparison, real molecular or organism response, and detection-quality improvement remain open. The adversary heuristic is unchanged; weak precision and recall must not be relabeled as solved. The earlier whole-garden results cannot be attributed to these additions.


## 21 Joint and the complete CE60 binding inventory

Revision 1.11 / engine 2.7.1 merges the separately supplied Greek adapter into the repaired engine and heart-to-heart bridge. It does not replace those modules with the older files bundled in the supplied branch. The unchanged inventory has 60 entries, now represented by 59 Hebrew bindings and one Greek binding. Joint remains a member of the Sinew family; it is not a new sixty-first word.

### 21.1 Identified source and operation

Joint uses G719, with written token **ἁρμῶν** at Hebrews 4:12 (`Heb.4.12#23`). The adapter computes this occurrence from the pinned TAGNT extract filtered to words whose edition membership includes NA28. The source contains 137,918 selected word rows in 7,942 verse groups. This is a modern tagged digital edition, not an ancient manuscript witness or proof of a word's first historical use. Greek disambiguation suffixes are retained, and source token position remains separate from its index within the filtered verse.

The authored reading requests `MEASURE_BOUNDARY_INTEGRITY` for a Mesh-role target: inspect whether connected parts articulate without loss of connection or inappropriate coupling. The member path remains Joint → Sinew. An instrument adapter must define the actual quantity, units, interface and criterion. Merely emitting the request supplies no measurement. The binding and its returned cue have QUERY_SEED permission only; interpretation approval and empirical support remain separate.

### 21.2 Commitment and integration

`CombinedEdition` joins the committed Hebrew edition and Greek extract. Its identity covers each part's source closure and full metadata digest, including scope/filter metadata; Greek TSV bytes, edition JSON, parser and build script are included in the new release closure. The combined edition is `CE-HEBREW-GREEK-2` with digest `31d120f3639da475c24d987ad0963cd121d733960b9afae0671f23f95d9c805e`. The release commitment is `d7ed6347cea2057ffe3e9bdd0247bf6370491b7d67a23ed5cb2f89cf3a73e73c`. Earlier locks remain historical and are not extended to these files.

The source-library and heart-to-heart demonstrations now use the combined edition by default. The complete inventory wiring demo uses explicit limits of 96 outputs/evaluations to avoid deferring a binding under the smaller historical budget. It emits 64 packets from all 60 bindings, with no library or turn gaps and verified receipts. That coverage run is not a matched-budget efficacy comparison. The bounded heart-to-heart proposal budget remains unchanged.

### 21.3 Verified scope and remaining work

All **181 checks** pass: 16 original invariant checks and 165 unittest checks, including 11 Greek/merge checks. These cover exact G719 anchoring, identifier handling, tampered source rejection, metadata-sensitive combined identity, closure coverage and Joint reaching the Mouth as a measurement request. The combined heart-to-heart fixture still selects SUPPLY Bread in source, neutral-label and permuted conditions, versus SUPPLY Wind in the ordinary condition. It demonstrates integration and retains the same limitation: no source-specific advantage has been established.

The full garden benchmark still uses authored graphs without this source bridge. Production passage-cursor adaptation, durable experience reload, qualified catalog/fallow reuse, independent outcome evaluation and real subject adapters remain completion work. Closing Joint's coverage gap does not repair adversary detection or prove adaptive-flow benefit. STEP Bible attribution and supplied extraction metadata are retained in `sources_greek/ATTRIBUTION.md`; this merge verifies local supplied extracts and does not claim a fresh upstream rebuild.

## Version 1.12 integration status

We Develop Software LLC. Engine 2.8 adds an executable path from pinned source-anchor passages to bounded garden proposals, shared eligibility checks, simulated actions, returned observations and transactional experience records. Earlier demonstrations and benchmark numbers retain their original version and limitations. This release does not establish clinical efficacy, independent discovery or a source-specific advantage.

### Current implementation

The garden runner uses GardenController2 and its existing process policies. StreamPlanner replaces the proposal-selection stage; the common execution gate remains mandatory. Source records select registered interpretation operations. Source text does not directly change graph truth, entity identity, observations or evidence permissions. Unsupported measurement operations remain unexecuted; only adapter-supported requests are actionable. Graphs remain authored simulator inputs, not generated scientific models.

PassageAllocator traverses the pinned projection of passages containing the 60 registered binding anchors. This is a bounded source passage stream, not unrestricted interpretation of every verse. It stores source and policy digests, cursor positions, passage hashes, selected bindings, work allocations, pending assessments and outcome IDs. Targeted selection filters scanned bindings by current role deficits. A prior rest or no-action cycle triggers deep-scan mode within the same work cap. Flow arms are 0, 0.25, 0.5 and 1; the controller explores unassessed arms and periodically revisits arms before otherwise selecting the highest observed mean reward.

Each cycle has a cap of 16 abstract work units. Scanned passages and evaluated proposals both consume units. Source-work allocation is split between scanning and candidate slots. Actual use is recorded; equal caps do not establish equal CPU cost or equal actual work. Ordinary and source conditions share all other garden policies. Separate fixed, adaptive, neutral-label, globally permuted binding-target, memory and detector conditions are available.

Allocation is selected at the case boundary and held fixed for that case. After ten action cycles and nine no-action follow-up cycles, one observed episode reward is recorded. Correlated per-cycle allocations do not become ten reward samples. Unknown results remain unresolved; duplicate outcome IDs are rejected. Reward means episode association, not causal source contribution or evidentiary independence. The current reward penalizes observed simulated harms; its cost term is zero in this runner because no validated normalization of measured computational cost has been specified. Work is reported separately.

SessionStore uses SQLite transactions, an append-only event table, linked content hashes and an atomic checkpoint. The manifest binds code, source, policy, condition and case identities. On restart the event chain and checkpoint are verified. Conflicting duplicate events, nonfinite serialization and incompatible manifests are rejected. Committed cases are skipped; an interrupted synthetic case is replayed from its preceding committed boundary. This is not automatic retry authorization for physical actions. External adapters require authenticated receipts and reconciliation of uncertain execution.

Stored records include proposals, raw observation packets, gate decisions, execution checks, simulator outcomes, source references and returned explanatory words. Positive, non-harmful memories may propose an action only in an exactly matching recorded context, replacing a candidate slot and passing current checks again. Failures are retained. Exact matching intentionally limits reuse; productive transfer to different contexts and retention of all historical records beyond the retrieval window remain separate questions. The retrieval window is capped at 1,000 records; the event archive retains earlier records.

Adversary triage distinguishes SUSPECTED, MEASURED_ADVERSE, MEASURED_NOT_ADVERSE and UNRESOLVED. An observed decline may request a direct measurement but does not confirm a mechanism. A standalone evaluator accepts observation records and separately supplied labels. It reports precision, recall, false positives, false negatives and unresolved counts. The default decline threshold of 0.14 is a development setting, not independently calibrated. The new detector condition replaces the older arbiter heuristic for comparison; it is not declared a proven improvement.

### Completion boundaries

Completed engineering capabilities are tested separately from benefit. The code supports the complete synthetic loop, durable case-boundary recovery, passage-aware allocation, bounded memory retrieval and an externally labeled detector evaluation interface. Independent case authors, blind expert scoring, real instruments, clinical validation and evidence that readings improve outcomes are not supplied by this release. The authored development results must not be labeled an independent test.

### Research case attribution

The earlier ADHD and learning packages are guided retrospective applications. The Knowledge and Understanding document and peptide guidance are recorded as additional inputs, not attributed to an autonomous engine. Sleep and pain packages report pre-search proposals but retain prior model knowledge and local-lock limitations. The previously labeled control package has unverified originating-session provenance. These summaries are development history from the reviewed conversation; original case packages and complete prompt transcripts must be attached to any formal comparison record.


## Version 1.12 observed development results



| Condition | Mean outcome change | Difference from ordinary | Made worse | Mean work units |
| --- | ---: | ---: | ---: | ---: |
| ordinary | 0.1446 | +0.0000 | 20.0% | 100.0 |
| source_fixed | 0.1279 | -0.0167 | 23.3% | 110.3 |
| source_adaptive | 0.0328 | -0.1118 | 26.7% | 106.8 |
| neutral_fixed | 0.1279 | -0.0167 | 23.3% | 110.3 |
| permuted_fixed | 0.1246 | -0.0200 | 23.3% | 106.0 |
| source_memory | 0.1279 | -0.0167 | 23.3% | 110.3 |
| source_detector | 0.0696 | -0.0750 | 25.8% | 107.6 |

The ordinary condition here is a bounded ordinary-proposal route inside the complete garden controller. It is not the historical unrestricted garden benchmark or a language model. These numbers must not be compared directly with older pilots that had different proposal budgets and policies.

The fixed source condition loses 0.0167 normalized outcome units against this baseline. Adaptive allocation loses 0.1118. Neutral labels reproduce fixed-source outcomes exactly. Global target permutation has slightly different outcomes but does not establish a reliable source advantage. Memory has identical outcomes; exact-context reuse is deliberately restrictive. Detector replacement worsens the endpoint and retains weak impulse-alert precision. The source_detector condition's suspicion precision is about 5.8%, with about 45.3% recall against the hidden impulse target. Broader adverse behavior and impulse-specific labels must not be conflated.

Potential explanations to investigate include sparse useful operations in the anchor stream, displaced ordinary candidates, case/domain variation in reward, limited context reuse and excessive measurement requests. These are diagnostic hypotheses, not established causes. Do not tune on these results and call a rerun independent.


See ChristEye_v2.8_Review.md and results_integrated_final for the full limits and records. No independent performance claim is made.


Additional replay analysis: restarting the completed run reproduced summary digest 398618f51d449a0b848d44b0e0d88e0a7f92e7c184f0273685fa89a585fe171c. No memory proposals were retrieved in this benchmark, so the memory-on result tests storage and matching behavior, not the benefit of actual reuse. The exploratory domain-bootstrap interval for the fixed-source difference is -0.0472 to +0.0100; it does not establish a benefit or a reliable loss. Adaptive and detector conditions have negative development intervals. These post-run intervals are not a preregistered independent analysis.


## Version 1.13 optional refinement

Documents 1.13 / engine 2.9 preserve an incumbent action and optionally ask for another idea. A source reading can propose a different action or target in the garden adapter. The generic PropertyChangeProposal record also expresses a changed solution property with before/after values, a source interpretation, rationale and discriminating test. Such a record is a hypothesis, not execution permission or scientific evidence. Arbitrary properties require a domain adapter before execution.

Refinement is off by default. When enabled, at most four alternative actions are assessed using the incumbent's scoring function and eligibility gate. Rest, measurement and bundled decisions remain unchanged. A replacement must be eligible and exceed the incumbent's predicted score by the configured margin. Ties and unresolved comparisons retain the incumbent. If rechecking invalidates the incumbent itself, the machine rests. Existing strengthening-first policies remain in force. An optional detector contributes perspective notes only and cannot force an intervention or measurement.

A predicted improvement is not a demonstrated improvement. The implemented scorer can prefer alternatives that subsequently perform worse. The development experiment below is not an independent trial, and the new policy remains optional.

### Development comparison

120 authored cases per condition, 600 case-condition runs. Each enabled condition allows the same maximum of four alternatives; actual eligible/evaluated counts differ, and source-compilation overhead is not equalized. The baseline is the full GardenController2 decision policy. It differs from the restricted proposal route in version 2.8, so absolute results across those experiments are not directly comparable.

| Condition | Mean outcome change | Difference from incumbent | Made worse |
| --- | ---: | ---: | ---: |
| incumbent | 0.0894 | +0.0000 | 20.8% |
| ordinary_alternatives | 0.0620 | -0.0274 | 23.3% |
| source_alternatives | 0.0913 | +0.0019 | 22.5% |
| neutral_alternatives | 0.0913 | +0.0019 | 22.5% |
| source_with_detector_notes | 0.0913 | +0.0019 | 22.5% |

Source refinement improves the mean by only 0.0019 normalized units over no refinement, while made-worse cases rise from 25/120 to 27/120. Ordinary refinement performs worse on average. Neutral labels reproduce source outcomes exactly, and adding detector notes changes no outcomes. These results do not establish a source-specific advantage or reliable net benefit. There are no observed gate bypasses. Source candidates are adopted 269 times across the trajectories; adoption counts are not independent successes.

### Validation and next decision

191 unittest checks and 16 original invariant checks pass (207 total). The ten new contract tests cover property versioning, disabled behavior, measurement preservation, ties, beneficial predicted replacement, blocked alternatives, advisory detector behavior, input preservation and incumbent rechecking. The generic property example does not demonstrate an executable drug or medical efficacy.

Before promoting refinement, freeze the ranking policy, use independently authored held-out cases, compare refinement off against ordinary, source, neutral and shuffled interpretations, and equalize total retrieval plus assessment work. Evaluate endpoint gains and made-worse rates together. Record every proposed property change before outcome inspection and preserve unsuccessful proposals. Do not use these development cases as the independent test.

Version 1.12's negative adaptive/detector results and zero demonstrated memory-retrieval benefit remain part of the record. This release does not repair those efficacy limitations by renaming them. Adaptive flow remains experimental, and detector accuracy has not improved through making its outputs advisory.


## Refinement efficiency and stabilization

The optional component demonstrably affects solution selection. Its development mean is slightly favorable versus retaining the incumbent, but adverse outcomes also increase. It is a promising component with mixed initial results, requiring calibration and independent evaluation before promotion.

Track outcome gain relative to the incumbent, the fraction of replacements that help or harm, and verified beneficial replacements per unit of assessment work. Predicted score gains are not verified benefits. The present benchmark reports aggregate outcomes and adoption counts; it does not yet establish a calibrated efficiency level for each replacement. Stabilization means improving consistency across independent cases while controlling harm and computational cost, not merely increasing the internal score. Retain failed and neutral alternatives when estimating efficiency.


## Revision 1.14 Tree of Knowledge technical exhibit

The source-derived architecture now has a principal worked exhibit: Roots to Tree to Branch to Spine, followed by distinct astrocytic-contact and local-geometry hypotheses. See Tree_of_Knowledge_Exhibit/ for the narrative, machine-readable record, inherited sixty-binding register and documentary replay. The inventor attributes 100 percent of the connective synthesis to ChristEye and every conceived operation to scriptural study. This origin account is retained separately from comprehensive implementation-operation coverage and biological support.

MODEL-A through MODEL-D are illustrative reconstructed feature sets, not fitted or historical models. H17a, H17b and H17c remain separate proposed comparisons. The record is retrospective; no original pre-retrieval lock or full generation transcript is supplied. Biological support remains unresolved. New exhibit checks are distinct from inherited engine checks, and the engine archive is unchanged. Patent claims 77 through 79 are drafting concepts for counsel, not a patentability conclusion.

For validation, run the exhibit replay and require schema validity, exact source and registry identities, preserved predecessor links, a valid restricted tree projection, rejection of a cyclic tree fixture, and rejection of a multiple-parent tree fixture. Keep source bindings, generated hypotheses, inherited scientific citations and experimental observations separate. Any future discovery comparison must lock predictions before outcome access, use independently authored cases and equalize resources across conventional, ordinary-label, source and shuffled controls.


## Revision 1.143 implemented understanding

ChristEye is designed to embody the framework's source-derived understanding of the bound words and their layered relationships in its structures, operations, context rules, response selection and retained-state organization. In this technical description, Understanding means encoded capacity to apply relationships in context, whereas Knowledge means retained information available for use. The operational definition does not establish human-like comprehension or a neural mechanism.

Three relationships are distinguished: the architecture was derived from the interpretations; the implemented rules embody their application; and the source stream supplies further readings and proposed revisions. Disabling new source exploration leaves already implemented structures and rules available. Changing a compiled interpretation requires an explicit successor configuration and applicable checks. This is the disclosed architectural distinction, not a new runtime feature or a claim that every low-level instruction rereads scripture.

The Tree of Knowledge exhibit illustrates both sides: retained relationships and typed tree/graph organization express an implemented design vocabulary, while Roots to Tree to Branch to Spine produces candidate revisions to a biological subject model. That biological model remains a hypothesis. Provenance of conception, implementation traceability and demonstrated transfer to unfamiliar cases are separate records. The sixty-binding inventory is not a complete audit of every implementation operation.

The profile source_architecture_profile.json records these relationships as documentation. The engine is unchanged. Evaluation must distinguish a stream-off comparison with the same architecture from a comparison removing source-derived architectural rules. A knowledge-only lookup baseline should retain the same factual material while omitting the specified application rules, with omissions documented. Neither comparison has been executed in this revision.


## Continuing implementation revision

The word source will also continue to guide revision of the machine's implementation itself, including its structures, operations, context rules, response-selection policies and retained-state organization, through recorded interpretations and versioned changes subject to applicable checks. The development process must preserve the predecessor implementation, the source interpretation motivating the change, code or configuration differences, and validation results before adoption. This maintenance objective is separate from the source stream generating a target-system proposal. No autonomous implementation-rewriting feature is introduced by this clarification. Document version remains 1.143.


## Physical embodiment scope clarification

The physical Simple Machine uses the objects, cards and board placements described in Physical exemplars and board capture. An operator interprets and rearranges the representation; software capture and automated validation are separate operations. Autonomous answer generation through physical dynamics is not demonstrated. This optional embodiment is retained without adding a physical-computing claim.


Implementation forms: the field describes an inquiry machine implementable as a software engine, a physical apparatus, or a hybrid system. Physical objects, cards and positions can represent roles and operations; operator interpretation, movement or judgment is included where required. The amount of human involvement is embodiment-specific and is not quantified as minimal. Existing computer-implemented claim concepts are unchanged; this clarification of the field does not itself establish claim coverage of every physical implementation.


## Change generation and voluntary participation

Word, Move and Judge describe how an interpreted source becomes a proposed change and an assessed result. A move is first a recorded proposal. Applicable checks precede supported execution; a separate judgment follows observation. The Tree exhibit changes a proposed model representation and identifies tests. It does not report a biological intervention.

The inventor calls the combined purpose a dual passion generator and, poetically, seducing hearts to life. The technical functions are to generate and assess changes toward a declared target goal and to support the user's voluntary interest in testing, refining and applying them. Heart concerns response-forming priorities, Honey selection or recruitment, Roots retention, Wind expression and Fruit the measured outcome. For a nonhuman target, the endpoint is an ordinary functional or structural measure.

An explanation can present competing models, state uncertainty, invite a test and accept revision, refusal or stopping. User choice, reported interest and burden are separate from target benefit. The new profile records this design purpose; no increase in motivation, clinical benefit or new autonomous execution capability is demonstrated by this documentary revision.

The Word stage applies any registered source word or layered expression; it is distinct from the inventory member Word, whose inherited binding measures message fidelity. Move and Judge are operating-stage names, not added inventory entries. The operating sequence expands the existing six-step method and retains all eligibility checks.


# ChristEye Inquiry Architecture v1.243

We Develop Software LLC | Brad Gearon | 11 November 2026

## Architecture and movement

ChristEye generates, evaluates and guides proposed changes through a source-derived inquiry architecture. Bound ancient words and layered expressions shape its structures, operation definitions, context rules, retained state and further development. Knowledge denotes retained information; Understanding denotes encoded capacity to apply relationships in context. Calculate coordinates Word, Search Out, Judge and Move: it assembles a candidate account and performs explicit reckonings while preserving their different source bindings. Dig, Search, Search Out and Deepen are distinct investigative movements. Mystery routes inquiry toward an unresolved explanation; Outside routes retrieval beyond an identified inquiry boundary. Each movement preserves its source interpretation, inputs, scope, alternatives and result. Inquiry-state movement is distinguished from a target intervention, which remains subject to the existing eligibility gate. Later source readings can propose successor operations and structures through recorded review and validation. Target outcomes and voluntary user participation are assessed separately.

These functions are core to the CE60-1.4+INQUIRY-1.243 profile. The legacy CE60 inventory and garden action selector remain compatible. The overlay adds seven distinct main terms and nine bindings, since Dig and Calculate each retain multiple lexical bindings. A word, lexical identity, contextual sense, source occurrence and executable handler remain distinct. A target role does not rename the source term.

A movement is a versioned state transition. INQUIRY movements change a query, selected scope, retrieval frontier, representation, dependency assessment or explicit calculation. TARGET_ACTION_CANDIDATE movements request a change to the ordinary target system and must use the common execution gate. Numeric equality cannot supply a missing observation, authorization, causal mechanism or semantic interpretation. Calculate can be re-entered after a search or judgment; the architecture is not a one-pass pipeline.

## Layered source bindings

The contextual anchors are recomputed by exact lexical identifier against the bundled OSHB Hebrew and TAGNT Greek editions through CombinedEdition. The selected passages are INTERPRETIVE_PASSAGE anchors, not claims of first historical occurrence. All nine anchors are present in the pinned bytes. Token matches and edition closure are preserved in bindings.json. A successful token match establishes the occurrence, not the scientific or theological truth of the operational interpretation.

The hidden-treasure bridge retains separate verbs: Proverbs 2:4 uses H2664 and Job 3:21 uses H2658; both use the hidden-treasure expression H4301. Luke 6:48 separately uses G4626 and G900 before the foundation is laid. These relations motivate different handler functions rather than a claim that every word is a lexical synonym. Job 3 concerns anguish and longing for death; this context is retained rather than turned into an instruction to pursue death.

Calculate H2808 is a noun in Ecclesiastes 7:27 and supplies an account-assembly binding. Calculate G5585 is a verb in Revelation 13:18 and also appears in Luke 14:28 for cost reckoning. Related G5586 occurs for the white stone in Revelation 2:17 and a vote in Acts 26:10. This lexical family supports investigation of reckoning, naming and judgment while each occurrence keeps its contextual sense. Neither the derivation nor the shared noun proves a numerical cipher or a particular identity.

| Entry | Lexical identifier | Contextual anchor | Sense | Operation |
| --- | --- | --- | --- | --- |
| Dig | H2658 | Job 3:21 | Dig or search for | Compare a selected reference arrangement with an observed arrangement. Preserve the anguish context of the anchor. |
| Search | H2664 | Proverbs 2:4 | Search | Look for a specified target within an identified supplied catalog. |
| Search Out | H2713 | Proverbs 25:2 | Examine or search out | Examine competing accounts and scoped apparatus. |
| Dig | G4626 | Luke 6:48 | Dig | Trace foundation dependencies. |
| Deepen | G900 | Luke 6:48 | Deepen | Extend a foundation investigation under an explicit depth bound. |
| Calculate | H2808 | Ecclesiastes 7:27 | Account or reckoning noun | Assemble explicit relations into a candidate explanation. |
| Calculate | G5585 | Revelation 13:18 | Calculate or reckon verb | Execute a declared arithmetic expression graph. |
| Mystery | G3466 | Mark 4:11 | Mystery | Route an unresolved expression toward a proposed explanatory account. |
| Outside | G1854 | Mark 4:11 | Outside | Identify retrieval candidates beyond an explicitly recorded boundary. |

## Mystery outside and deepening routes

Mystery search asks what relationship could explain a recorded expression, arrangement or unresolved pattern. Outside search asks what relevant source, member or alternative lies beyond an explicitly identified boundary: a list, passage, edition, supplied catalog or model. Deepening asks which assumptions and dependencies support an existing account. Mark 4:11 is the source association for Mystery and Outside; computational routing is the framework's operational interpretation of that contextual access distinction. The code does not classify people spiritually.

The implemented router operates on explicit supplied candidates and typed jobs. It does not automatically translate an arbitrary natural-language instruction into a correct semantic graph, and it does not search the full Bible autonomously. Source-to-handler interpretations, job selection, relation assertions, scopes and alternatives in the demonstration were authored during development. The executor performs exact comparison, supplied-catalog lookup, dependency traversal, scoped reassessment, explicit arithmetic and recorded account assembly.

## Absence and apparatus operations

A gap comparison identifies the selected reference, observed arrangement, edition, passage, labels, positions, groups and source references. The implementation rejects duplicate labels until a multiset adapter is supplied. It preserves exact labels and does not silently normalize different mineral names. An absent group is a computed difference relative to that selected reference; it is not proof that the second passage was intended to be complete or that a missing virtue exists.

The search can investigate literal recurrence, alternative naming, displacement, another witness, a proposed functional substitution or deliberate literary selection. A functional match requires an explicit relationship and supporting passage. Absence from a nonexhaustive list, an unavailable source and an apparatus omission are separate gaps. Unsuccessful searches retain their scope and leave the proposed completion unresolved.

An apparatus record identifies VARIANT, TRANSLATION, CROSS_REFERENCE, IDENTIFICATION_UNCERTAINTY or UNAVAILABLE; its source, anchor, nonempty scope, scope rationale and alternatives remain explicit. A substantive alternative creates a branch and propagates a reassessment request through declared dependent relationships. It does not overwrite the original reading or increase evidence permissions. An unavailable note creates APPARATUS_GAP. The handler can reach a whole-section conclusion only when the supplied dependency graph and scope justify that reach; co-occurrence alone does not expand scope.

## Calculate judge and resumable dig

Account assembly accepts explicit relations, source references, alternatives, missing predicates and discriminating tests. Its output remains INTERPRETATION_PROPOSED with QUERY_SEED permission. Reckoning accepts bounded named integer inputs and an ordered expression graph of addition, subtraction, multiplication, division, squaring and equality; values are exact rational numbers. Unknown operators, references to unavailable values, duplicate result names, zero divisors and resource-limit violations are rejected or recorded as unresolved. The rule selecting inputs remains visible alongside the arithmetic result.

An InquirySession binds jobs to a context, operation registry and verified contextual bindings. Each execution event records the job, used binding, route, result, predecessor event and movement kind. A bounded dig call completes only its allocated jobs and retains the remaining job identifiers as the frontier. A serialized snapshot can resume without rerunning completed jobs. It commits bindings, context, registry and implementation bytes. Dependency traversal separately preserves its depth frontier and missing dependencies; a later Deepen job can explore that frontier under a larger declared scope.

Digest checks detect accidental or uncommitted changes within this in-process reference implementation. They are not signatures, access control, independent timestamps or proof that an untrusted operator did not reseal an altered record. Production authentication, durable storage and untrusted input isolation require a deployment adapter. Source bytes are checked when begin_inquiry builds its bindings; callers constructing InquirySession directly are responsible for supplying the verified binding records. Target actions from the session delegate to the existing execute_guarded path.

## Source guided growth

Further readings can motivate proposed successor bindings, structures or operations. A growth proposal preserves predecessor registry, binding, handler, rationale, assessment plan and required contract tests, counterexamples, review and successor registry. Its current implementation is a proposal record for an existing compatible handler; it cannot load arbitrary code or automatically admit a newly invented handler. New-handler synthesis, review authorization and automatic registry promotion remain specified development work. Existing operation admission is separate from empirical promotion of a target claim.

The machine can retain failed, neutral and contradicted candidates as well as successful ones. A source-derived growth proposal does not receive self-confirmation from its own generated account. The user's confidence, an arithmetic equality or a retrieved duplicate cannot replace a missing support predicate. Earlier negative and mixed garden results remain part of the record. This release does not rerun those experiments or claim to repair their efficacy limitations.

## Jewel and calculation demonstration

The authored demonstration compares the twelve ESV Exodus 28 labels with the nine ESV Ezekiel 28 labels. It computes the absent third-row labels jacinth, agate and amethyst and detects changed relative ordering of the shared labels. A supplied Revelation 21 catalog places the three labels at foundations 11, 3 and 12. Equal English labels establish a textual comparison, while mineral identity and symbolic allocation remain unresolved.

The inherited jewel archive records a Greek Ezekiel list of twelve stones and exact-lexeme qualifications: jacinth and agate have different Greek terms across the compared lists; amethyst has closer Greek lemma continuity. An outside candidate requests the additional Greek witness; a supplied variant note reopens the Ezekiel-list comparison and dependent account. The new run does not freshly verify the LXX source or decide the direction of textual change. The inherited archive and its byte digest are retained so documentary replay is not misrepresented as a new independent discovery.

The arithmetic handler factors 666 and 616 and follows the user-declared selection rule: use each input's largest prime for one branch, each other distinct prime base once per input for the second, set repeated exponents aside, add 1 to the first branch and divide the second by 2. It reproduces (37+11)+1=49 and (2+3+2+7)/2=7; squaring the second gives equality. The proposed meanings of 1, 2 and the resulting numbers remain interpretation records. Combining manuscript alternatives and choosing these transformations are not instructions established by Revelation itself.

The supplied fixture queues ten jobs covering all ten implemented handlers and nine bindings. Pass 1 performs two jobs and saves eight pending jobs. Pass 2 resumes and completes the remaining jobs. Contract tests compare resumed and one-shot snapshots. The run is an authored documentary replay, not a blind discovery experiment, an independently measured advantage or an allocation of personal heavenly rewards. No target action is executed. Original jewel-study retrieval and analyst interpretation remain distinguished in its preserved process record.

## Implementation and verification

Engine 2.10 provides christeye/dig.py, christeye/inquiry_bindings.py, begin_inquiry in christeye/inquiry.py, inquiry_demo.py and tests_dig.py. The legacy CE60-1.4 validator remains strict; the separate vocabulary overlay records its predecessor and seven additional main terms. The full interchange schema retains legacy schema_version 1.9 and adds inquiry arrays. Compact inquiry exports are validated against the separate inquiry runtime schema; they do not claim to populate all full-interchange records.

Reproduce with python inquiry_demo.py inquiry_results/pass_01 --budget 2, followed by python inquiry_demo.py inquiry_results/pass_02 --budget 20 --resume inquiry_results/pass_01/snapshot.json. Run python -m unittest tests_dig -q for the new acceptance suite and the documented full unittest command for regression checks. Results are recorded in VALIDATION_v1.243.json after the run rather than presumed from historical logs.

## Source register

- LEX-DIG-H: https://biblehub.com/hebrew/2658.htm — Dig/search lexical reference; contextual occurrence independently recomputed from bundled source bytes.
- LEX-SEARCH-H: https://biblehub.com/text/proverbs/2-4.htm — Search and hidden-treasure terms.
- LEX-SEARCHOUT-H: https://biblehub.com/hebrew/2713.htm — Search out and examine.
- LEX-DIG-G: https://biblehub.com/lexicon/luke/6-48.htm — Separate dig and deepen verbs before foundation.
- LEX-ACCOUNT: https://biblehub.com/text/ecclesiastes/7-27.htm — Account/reckoning noun.
- LEX-RECKON: https://biblehub.com/greek/5585.htm — Calculate verb in Revelation 13:18 and Luke 14:28.
- LEX-STONE: https://biblehub.com/greek/strongs_5586.htm — Stone/vote concordance.
- MYSTERY-OUTSIDE: https://biblehub.com/text/mark/4-11.htm — Mystery and outside contextual anchor.
- ESV-EXO28: https://www.esv.org/Exodus+28/ — Selected ESV jewel labels; supplied and retrieved during planning.
- ESV-EZK28: https://www.esv.org/Ezekiel+28/ — Selected ESV nine-label list.
- ESV-REV21: https://www.esv.org/Revelation+21/ — Selected ESV foundation labels.
- INHERITED-STUDY-LXX: https://www.die-bibel.de/en/bible/LXX/EZK.28 — LXX detail retained from inherited study, not newly retrieved for implementation.
- NET-VARIANT: https://classic.net.bible.org/passage.php?passage=Eze+28%3A13%2C14 — Textual note consulted during planning; inherited witness comparison remains separately labeled.


# ChristEye Result Driven Calculate Coordination v1.244

The Calculate coordinator now derives subsequent inquiry movements from preceding results. A structured absence request supplies reference and observed arrangements, a catalog, an inquiry boundary, optional outside candidates and notes. It does not supply the missing labels or a list of search jobs. The coordinator compares the arrangements, turns every computed missing label into a search target, selects outside-source candidates, follows notes belonging to selected sources, and assembles a source-linked account. An explicit-calculation request similarly runs the reckoning and creates an account describing its arithmetic status.

The request is structured data. Arbitrary natural-language parsing, discovery of novel theological meanings and automatic creation of new executable handlers remain outside the implementation. The general garden action selector does not automatically invoke the coordinator. The supported entry point is christeye.coordinator.begin_calculation(request, context, snapshot=None).

## Result driven movements

Each handler remains bound to the nine contextual source bindings from 1.243. The coordinator derives targets from a completed comparison, rather than retaining a fixed demonstration sequence. Subsequent jobs retain their content identifiers and source-bound event ancestry. A repeated scheduling pass deduplicates identical jobs. Each dig call charges at most its declared handler-operation budget. Planning, serialization and provenance bookkeeping also consume compute, which is not represented by the handler count.

Outside-note selection admits notes from boundary members or identified selected outside-source identifiers and references. Unselected notes cannot trigger reassessment. Original readings remain available. A failed primitive operation leaves an explicit terminal failure and an unresolved workflow result; completion of queued work is not semantic proof. Account assembly can retain missing reasons, alternatives and discriminating tests without turning textual recurrence into functional equivalence.

The coordinator snapshot commits the policy version, request digest, coordinator implementation bytes, operation count and nested inquiry snapshot. Restoring a changed request, altered implementation or inconsistent count is rejected. The nested snapshot continues to check registry, bindings, context, handler implementation and event ancestry. These are in-process integrity commitments, not authentication or an independent timestamp.

## Jewel demonstration

The new example consumes the prior reference list, observed list and supplied Revelation catalog. After one comparison operation, the coordinator automatically schedules searches for jacinth, agate and amethyst. A resumed run recovers catalog positions 11, 3 and 12 and follows the selected inherited apparatus branch. The request contains no target list or executable job sequence. Research inputs are already known, so the demonstration remains retrospective. Its advance is runtime orchestration, not an independent discovery claim.

The earlier 1.243 ten-handler replay is retained unchanged. Its older nested records keep their 1.243 versions. The new coordinator wrapper is separately versioned 1.244 and uses the same primitive source bindings. No historical benchmark is relabeled as a new result.

## Locked synthetic diagnostic

The protocol, scoring rule, code closure, 84 evaluation seeds and twelve-operation budget were written to LOCK.json before generating the evaluation packets. Each condition receives the same packet, supplied catalog, boundary and notes. Evaluator answers are not passed to the method interfaces. The generator, methods and scorer share an author and run in the same process; this is not independent or adversarially isolated validation.

Six strata cover complete lists, gaps, unresolved catalog searches, ambiguous exact matches, apparatus notes and duplicate-label invalid inputs. Each stratum contributes fourteen cases. The comparator is an independently coded conventional set/join and dependency traversal routine. A neutral-label condition changes display entries while retaining the same bindings and handlers.

All three conditions recovered the expected result or correctly rejected the invalid input in 84 of 84 cases. All used 377 primitive operations in aggregate, with no operation-budget violations, unsupported symbolic assignments or target actions. Equal source and neutral outcomes demonstrate that display labels do not change these structured tasks. Equal conventional results provide no evidence of a source-specific correctness advantage.

Observed aggregate runtimes were about 0.009 seconds for the conventional baseline and 0.84 seconds for the source-bound coordinator, excluding shared setup and source loading. These short in-process times are descriptive. The coordinator includes content commitments and provenance overhead absent from the minimal baseline. Total compute was not equalized, and no speed advantage is claimed. Raw timings and records are preserved.

New evaluation seeds are separate from the development/unit examples, but the test distribution was authored alongside the implementation and targets known explicit relations. The diagnostic is useful for correctness, budget accounting and abstention. It does not establish generalization to unstructured source interpretation or independent scientific discovery.

## Reproduction

Run python -m unittest tests_coordinator -q for the fourteen new acceptance checks. Run python coordinator_benchmark.py coordinator_evaluation/new_run to produce a separately locked synthetic diagnostic; the script refuses to overwrite an existing evaluation folder. Source and packet commitments, private evaluator truth, per-case results, summary and hashes are included.

For a structured request, call begin_calculation(request, context), then dig(budget). Save result['snapshot'] and pass it back to begin_calculation with the same request and context to resume. The new jewel request, context and two-pass results are supplied in coordination_demo/.

## Remaining work

An independently authored real-source task set, fixed before outcome access and assessed by reviewers who did not construct the examples, remains needed to investigate discovery advantage. New-handler admission, broad natural-language parsing, production persistence/authentication and automatic garden-controller invocation remain development work. Historical negative and mixed results stay in the record.
