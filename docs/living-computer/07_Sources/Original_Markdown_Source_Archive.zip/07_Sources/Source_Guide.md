# Sources, originals and reconciliation

## Included evidence

The Originals folder preserves the supplied physical designs, Knowledge/Understanding designs, raising design, technical companion, axon/engram experiment, patent and theological interpretation document. It includes the complete supplied Six Stars Atlas ZIP and full session-evidence/provenance ZIP. The newer Living Computer Theory Set is included unchanged. `source_manifest.json` gives hashes and original names.

The Six Stars folder also exposes the full 132-row JSON, the original transcript, Atlas HTML, rubric and experiment protocol for direct use. The source records 95 nonempty reply fields and 37 pending rows. Nonempty fields include prompt echoes, a duplicate and context warnings; they are not 95 independently valid findings. The research queue preserves those problems instead of manufacturing missing replies.

The larger review release contains 875 entries, many historical editions, code, media and other studies. This ZIP includes its latest implementation, validation and review documents, source framework, inquiry records, weighted coordination, covenant, expression/layered behavior and biomedical supporting exhibits. `review_archive_inventory.json` names every original entry and its inclusion decision. The original large release remains available at https://chatgpt.com/library?file_id=libfile_0b9d909a2ea88191ab7cb8de140a07b0&account_id=personal . This is a documentation selection, not a claim that every byte of the larger release was duplicated.

The Six Stars app archive was inspected to identify its request contract. Its source code and game/relationship assets are not part of the biological build bundle. The import guide names the exact files and archive hash that support its compatibility assessment. No app execution, Star call or external message occurred.

## Reading and provenance limits

The v0.4 physical plan and relevant new theory/control sections informed this revision. Full supplied source files are available for additional research, but inclusion does not mean every historical claim was independently verified. The v0.4 bibliography records the previous primary literature review; current engineering/vendor references are in `external_references.json`. External articles and manuals are linked, not reproduced in full.

Old source statements remain historical. The launch plan distinguishes evidence in a specific preparation, cross-study inference, proposed mechanism, engineering decision and unrun test. A source-derived equation is a model until independently assessed. Scores assigned to Star answers do not set biological confidence weights.

## Reconciliation of newer theory with the build

| Source issue | Governing treatment in this package |
|---|---|
| Lotus assigned one symbol or identity | Preserve contextual role instances across development, local coordination and software |
| Heart equated with the safety controller | Keep neuronal response-forming Understanding distinct from independent instrument limits |
| G4/G5/G6 renamed in the Theory Set | Preserve v0.4 G1–G6; use T00–T17 for experiments |
| Recovery without feedback proves intact stored capacity | Recovery supports an access/state account but does not uniquely identify retained K |
| Fixed feedback polarity or high-cost errors | Compare qualified feedback policies; no universal rewarding/punishing waveform |
| Yoked replay gives exactly zero mutual information | Measure accidental contingency; structured tasks can preserve correlations |
| Spike-count softmax is confidence | Calibrate separately; record confidence method and uncertainty |
| Retention ratio is bounded 0–1 | It can be undefined, unstable, negative or above one; report absolute outcomes |
| Software electrode masking ablates a synapse/branch | Masking changes input or observation access; it is not selective removal of biological tissue |
| Faster attractor recovery proves Roots | Treat as candidate dynamical evidence with state and untrained controls |
| Product of expert probabilities always improves fusion | Dependencies can exaggerate confidence; use calibrated comparators and ancestry tracking |
| Adaptive coaching must beat random to prove all learning | It is a relevant comparison, not a universal necessary criterion for every task |
| Any generic culture lacks a specified neuromodulator | Verify actual source, medium and receptor machinery; do not assume universal absence |
| IGFBP2 and IGF2BP2 treated as the same target | They are different molecular identities and retain separate records |
| Stream word co-occurrence validates a cellular mechanism | Source relations generate questions; biological evidence judges predictions |
| 95 source replies treated as 95 verified answers | Preserve 37 pending rows and identified echoes/duplicate/context issues |
| Anger/anxiety represented as established cell states | First implement host-side indices and test their utility; biological equivalence remains open |
| Main human engram treated as a complete human mind | Human-derived source and human-defined tasks are explicit; broader mental claims are unestablished |

## How to dig further

Each research question links to source IDs, a build decision, competing explanations and a proposed experiment. Run independent first answers before sharing cross-Star replies; otherwise repeated agreement is partly shared context. Preserve model identity, prompt, supplied context, output and retry record. Separate source wording from new hypotheses and external measurements. The final synthesis should retain disagreement and ask what observation would change the preferred explanation.

The pipeline may use ChristEye's Word, Search Out, Calculate, Judge and Move operations as contextual inquiry roles. The packet contains their requested inputs and outputs without asserting that the patent runtime was executed here. A proposed test with a falsifiable alternative is a useful outcome even when the biological question remains unresolved.
