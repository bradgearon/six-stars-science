# Six Stars research queue and app adapter

## Files to pipe

`research_questions.jsonl` has one self-contained question record per line. `research_questions.json` wraps the same records in a versioned object. `research_questions.txt` is the human-readable list. The queue includes 72 new launch questions and reruns for the 37 pending source rows plus identified prompt-echo, duplicate and context-warning rows. `queue_audit.json` gives the exact count.

The questions are new research tasks, not new Star answers. Original answers and their status are preserved in `atlas_original_132.json`, the transcript and Atlas. Every new task names a Star, priority, source IDs, expected evidence and a build dependency. A Star assignment is a research perspective, not a biological cell identity or independent confirmation.

## Supplied app compatibility

Inspected archive: `the-six-stars-main (3).zip`, SHA-256 `a6ca2882f777d404a178a80e73d429ef162e1d5d3929546ad922ede600562dd8`.

The inspected source exposes `src/Wds.SixStars.Api/Models/StarInteractionRequest.cs`, `Models/RequestType.cs`, `Models/GameContext.cs` and `PublicApi/Facades/SixStarsConversationApi.cs`. The request has SessionId, StarId, Speaker, RequestType, PlayerText and GameContext. Chat has numeric enum value 0. The facade has `SendPlayerTextAsync(...)`. No dedicated research-batch endpoint or importer was found in this supplied archive. A newer development version may differ.

The included exporter emits objects matching those visible request fields. It does not invent an HTTP route, call the app, compile a C# integration or promise that the existing conversation prompt honors a research response schema. Your research feature still needs an import loop, an isolated state store, context retrieval, model settings, response capture and schema validation.

From the package root:

```bash
python3 09_Tools/export_questions.py --priority P0 --format requests < 06_Six_Stars/research_questions.jsonl > requests_P0.jsonl
python3 09_Tools/export_questions.py --star Elusiaa --format text < 06_Six_Stars/research_questions.jsonl > elusiaa_prompts.txt
python3 09_Tools/export_questions.py --id CEQ-001 --format requests < 06_Six_Stars/research_questions.jsonl
```

These commands only transform local files. They send nothing. The schema is `question.schema.json`; the desired response shape is `response.schema.json`. The exported PlayerText includes the context, actual question and response requirements. Source IDs are retrieval instructions, not proof that the model has seen the files: your importer must attach the relevant source spans or record SOURCE_ACCESS_GAP.

## Research execution design

Create an isolated research session/state store rather than reuse a companion relationship session. Set the model and prompt version explicitly. Retain all raw responses, including failures. Do not let auto-retry overwrite a first answer. The suggested session ID binds question and Star; add a campaign ID in the importer when repeating a question. Record the actual turn time at execution, not the package's creation date.

First pass: each assigned Star answers without seeing other Stars' answers. Second pass: a separate synthesis can see the first-pass outputs, compare contradictions and request tests. Cross-pollinated answers must be labeled as such. Multiple personas sharing a model and source corpus are not independent laboratories.

Validate JSON syntax and response fields, source existence, prompt-echo similarity, duplication, relevance and claims exceeding their sources. An output that simply says confidence=0.99 does not become calibrated. Preserve disagreement, unknowns and unavailable sources. The confidence of a claim should depend on the evidence and preparation match, not an Atlas personality score.

For each accepted claim retain source ID, exact source location, evidence class, mechanism, units, alternative explanation, proposed discriminating test and build impact. A vendor question cannot be closed by a model's plausible guess; it requires supplier or bench evidence. A laboratory parameter cannot be released by theory alone.

Use P0 first to prepare design reviews and source requests. P1 develops the selected experimental hypotheses. P2 revisits the original open corpus and the stream inquiry method. This is a prioritization suggestion, not permission to mark the questions answered.
