# Biological materials, Soil and analytical support

## Material strategy

Use qualified human iPSC-derived cells for the requested human substrate. Keep the regional identity explicit. A spinal motor-neuron/astrocyte reference has a direct maturation precedent, but does not demonstrate general learning. A richer spinal excitatory/inhibitory network is a separately qualified candidate. A cortical reference is an optional comparative preparation, not silently renamed as spinal. Brainstem tissue, spinal cord and dendritic spines are different meanings that can coexist in the theory.

Functional Marrow denotes source and developmental constraints. Literal marrow is not a ready neural population. If marrow-donor origin is important, record it as a source requirement and commission a documented reprogramming and neural-differentiation route. Do not add raw marrow cells to the learner or relabel marrow macrophages as resident microglia.

The initial purchase candidates are human spinal motor neurons and spinal astrocytes, for example BrainXell BX-0100 and BX-0650, subject to supplier confirmation for the chosen MEA. The product pages describe these cell categories and supplied supplements; they do not establish compatibility with this custom task or chip. [EXT-06, EXT-07]

| Material record | Use | Release evidence | Initial disposition |
|---|---|---|---|
| BIO-C-REF | Motor-neuron plus regional astrocyte interface reference | Source lot, neuronal and regional identity, usable electrical interface | First receiving/maturation pilot |
| BIO-C-DIV | Defined spinal excitatory/inhibitory community plus astrocytes | Intended subtype identities, functional inhibition, repeatable task responses | Candidate after the reference interface works |
| BIO-O | Separately raised observer | Same initial preparation as C; independent training and qualification | Separate cartridge, separate history |
| BIO-S | Support-policy community | Same initial preparation where possible; candidate action discrimination | Later separate cartridge |
| BIO-B | Teaching recipient | Independent preparation with frozen initial characterization | Dedicated teaching comparison |
| BIO-G | Local astrocytes in each cartridge | Identity, support-related function and observation compatibility | Required locally; an electronic support module cannot replace them |
| BIO-P | Bank and progenitor source | Identity, stability, developmental history and expansion controls | Separate production service |
| BIO-X | OPCs, microglia-like or peripheral support cells | Distinct lineage and functional question | Deferred one addition at a time |

Do not establish separate lineages called accuracy cells, anxiety cells or anger cells. A module's trained role is an outcome of exposure and validation. Its lineage and training history are separate records.

## Receiving and production contract

Require source identity, consent/use permissions, lot and passage history where applicable, viability method, post-thaw yield, regional specification, expected subtype composition, contamination release, residual undifferentiated-cell assessment, shipping conditions and a complete method revision. A quoted cell number is not a live attached cell count. Record received, viable delivered, attached and later surviving populations separately.

Identity panels should be selected by the culture lead rather than inferred from a single marker. Candidate motor-neuron evidence includes MNX1/HB9, ISL1/2 and stage-appropriate CHAT; V2a candidates include VSX2/CHX10 with neuronal and regional evidence. GABAergic/glycinergic candidates need transmitter machinery and a measured inhibitory effect at their maturity. Astrocyte panels can include ALDH1L1, SOX9, S100B and appropriate GFAP with regional and functional evidence. HOXB4 alone is insufficient to establish the intended regional subtype.

Source expansion, differentiation, co-culture maturation and task training remain distinct operations. Qualified developmental methods may use dual-SMAD, retinoic-acid or SHH-pathway stages, but a list of those reagents is not a combined method. A production partner supplies its actual controlled recipe. The package does not invent concentrations, incubation durations or substitutions for an unselected cell/MEA pair.

## Soil qualification and material accounting

The selected cell supplier and platform must agree on one complete medium and one adhesion/matrix configuration. Candidate matrix families include PDL/PLO with laminin and separately evaluated alternatives. Candidate basal media include BrainPhys-class formulations, but the base, supplements and stage-specific factors are one versioned composition. Do not stack N2, SM1, B27-type or proprietary kits without reconciling their contents.

For each formulation, record component identity, supplier, lot, stock and final units, preparation owner, stability, storage, assay interference and the culture stage. BDNF/GDNF, ascorbate and cAMP-related support are preparation-dependent; their presence does not encode a memory. Developmental morphogens are not routine maintenance additions unless the selected method calls for them.

| Soil component | Measurement | Reason to keep it separate |
|---|---|---|
| Adhesion/ECM | Attachment, spatial distribution, signal coupling, coating blank | More coverage can change electrode access |
| Ions and buffer | Qualified composition, local pH/osmolality | Excitability change can masquerade as learning |
| Energy substrates | Glucose/lactate or other validated assays with volume and time | Concentration is not metabolic flux or memory content |
| Gas/thermal environment | Calibrated observation near the culture | Incubator display is not necessarily cell-boundary state |
| Trophic support | Method version, stage, receptor/functional context when investigated | Effects can be broad rather than task-selective |
| Service and exchange | Delivered/removed volume, time, mixing and recovery | Service is an exposure and possible hidden task cue |
| Local astrocyte community | Coverage, morphology, functional support measures | Remote electronic advice does not supply local cellular machinery |

The mass-balance estimate over an interval is net uptake = input amount − output amount − change in compartment amount, with abiotic loss and sampling corrections. State units and uncertainty. Use blank medium/material controls for adsorption, evaporation and degradation. Normalize to an explicitly measured cell or protein denominator only if that denominator is appropriate and available.

## Raising and releasing each community

G1 releases the source. G2 demonstrates developed structure and viable intended composition. G3 demonstrates usable input/output timing and stable observation. Perform these gates independently for C, O, S and B; matching source banks do not imply matching circuits. The observation window and tolerances are set after a qualification pilot, then frozen before learning comparisons.

Measure attachment, neurite distribution, loss, clustering, synaptic organization and intended population survival. Use matched sacrificial preparations for destructive assays. A culture need not be perfectly stationary; maturation drift must be characterized well enough to distinguish it from the learning effect. Reject an interface with unusable artifacts or inseparable cue families even if its spontaneous firing rate looks high.

Cell counts use the plated area, not just the active electrode area. State whether density refers to total well area, patterned island or active sensing region. The current MaxOne reference active region and electrode design must be checked for the purchased chip generation. Scaling another paper's cells per plate by a guessed area is not a release method.

## Assay tiers and sample preservation

Tier 1 runs with every task: raw electrical data, actual stimulus delivery, validity masks, local support observations, source/medium identity and behavior. Tier 2 adds registered imaging: cell location, morphology and selected calcium/reporter measurements. Tier 3 investigates a specific mechanism using a qualified laboratory assay and targeted comparisons.

Astrocytic calcium is an observation of intracellular dynamics, not a direct readout of remembered content. Activity labeling, NFIA-related recruitment, IGFBP2-related stabilization and Ank2-related persistence are distinct candidate mechanisms from distinct studies. Preserve the distinction between IGFBP2 and IGF2BP2. No manipulation of either is specified as a universal recall command.

Collect conditioned-medium samples only under an approved sampling plan with parent identity, volume, time, replacement and disturbance logged. The first experiment does not cross-feed recipients or claim that a sample contains extracted Understanding. Electrical, optical, molecular and behavioral records answer different questions; none automatically substitutes for the others.

## Capacity and purchasing worksheet

For each population, required viable cells = released target per preparation × planned preparations / measured handling yield, plus explicitly justified qualification and assay reserves. Because target and yield are not yet known, `materials_plan.json` keeps them null and blocks a final order. Assay-only preparations, failed receiving lots, untrained controls and attrition must be included. A vial is not one biological replicate, and multiple fields of view are not independent preparations.

Choose operational coverage so routine support is available during weekends and equipment failures. Life support is independent of accuracy, affect-inspired priority or research budget allocation. Retirement follows the culture lead's predeclared criteria and preserves failure data.
