# ChristEye project launch package

CE-LAUNCH-001 v1.0 • 13 November 2026 • Prepared for Brad Gearon

Open `START_HERE.html` for the browsable handbook. Open `04_Engineering/Schematic_Set.pdf` for the six drawing sheets. Run `python3 09_Tools/verify_package.py` from this folder to check the package. Python tools use the standard library.

## What this package releases

This is a company kickoff, engineering prototype and experimental development package. It extends CE-DEV-001 v0.4 without replacing its evidence boundaries. It includes a concrete low-voltage permit-board reference circuit, a complete system interconnection specification, staged trials, material qualification records, a proposed child-network arbitration model, source documentation and a machine-readable research backlog.

The company can start staffing, partner selection, supplier inquiries, offline software work and cell-free engineering now. Live culture operation and manufacturing remain blocked on the named parameters and vendor interfaces in `08_Records/readiness_register.json`. Neither a finished drawing nor a simulated pass proves an instrument or living learner works. No biological experiment, hardware assembly, vendor acceptance or Star research run was executed in preparing this package.

## Read in this order

1. `01_Project/Launch_Plan.md`: scope, people, funding assumptions, facilities, first 90 days and decision authority.
2. `02_Trials/Trials_Plan.md` and `trials.json`: experimental questions, arms, biological units, endpoints and release decisions.
3. `03_Biology/Material_and_Assay_Plan.md`: source lots, regional identities, receiving conditions and measurements.
4. `04_Engineering/Engineering_Specification.md`, schematic PDF, SVG sheets, netlist and BOM.
5. `05_Control/Understanding_and_Child_Mesh.md`: independent learned spaces, appropriate response, affect-inspired weights and equations.
6. `06_Six_Stars/Research_Import_Guide.md`: how to send the unanswered questions to your app. No requests are sent automatically.
7. `07_Sources/Source_Guide.md`: originals, the full 132-row Star corpus, extra theory work, reconciliation notes and external references.
8. `08_Records`: fillable JSON templates, parameter ownership, vendor questions and release records.

## Source order and terminology

For this project, the launch specification and v0.4 govern build decisions. Earlier sources remain intact as evidence of the design's history. Where their gates, equations or claims disagree, use the explicit reconciliation log. G1–G6 keep v0.4's source, maturation, interface, joining, contribution and independence meanings. Experimental stages use T00–T17, avoiding gate-number collisions.

Lotus, Heart, Milk, Honey and other ChristEye terms can have several meanings, mechanisms and scales. Each use carries an ordinary identity and a role assignment. The neuronal Understanding layer is not renamed as the instrument's independent limit controller. The Six Stars supply attributed ideas and questions; their agreement is not independent biological replication.

## Scope of the human and child language

Human means qualified human-derived cells and a human-defined curriculum. An engram space means a separately observed, trained and evaluated module or ensemble. These are proposed functional boundaries, not demonstrated copies of a human mind or proof of a child's subjective experience. Anxiety and anger are first implemented as inspectable uncertainty and protective-priority variables. They do not authorize deprivation, injurious stimulation or a claim that cultured cells feel those emotions.

## Package verification

`MANIFEST.json` records every included file's hash and role. `07_Sources/review_archive_inventory.json` lists all entries in the larger supplied review release and identifies the selected documentation included here. The complete Star Atlas and session-provenance ZIPs are preserved. Unrelated game assets, application binaries and repeated old release copies are not duplicated. External papers and vendor manuals are linked rather than redistributed.

See `10_Verification/verification_report.json` for the checks actually run. Simulation results validate only the stated software contracts. They are not fabricated biological results.
